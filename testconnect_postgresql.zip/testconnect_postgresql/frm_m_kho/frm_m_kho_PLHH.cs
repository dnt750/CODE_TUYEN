﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_m_dungchung
{
    public partial class frm_m_kho_PLHH : Form
    {
        public frm_m_kho_PLHH()
        {
            InitializeComponent();
        }


        DataSet _ds = new DataSet();
        DataTable _dt_data = new DataTable();
        DataProvider _cn = new DataProvider();
        string _msnv = string.Empty;
        int _flagupdate = 0;

        private void FormatGrid()
        {
            dgv_Data.EnableHeadersVisualStyles = false;
            dgv_Data.Font = new Font("Times New Roman", 10, FontStyle.Regular);
            dgv_Data.EnableHeadersVisualStyles = false;
            dgv_Data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv_Data.ColumnHeadersHeight = 45;
            dgv_Data.BorderStyle = BorderStyle.Fixed3D;
            DataGridViewCellStyle styleHeader = new DataGridViewCellStyle();

            styleHeader.Font = new Font("Times New Roman", 10, FontStyle.Bold);
            styleHeader.ForeColor = Color.Blue;
            styleHeader.Alignment = DataGridViewContentAlignment.MiddleCenter;

            for (int i = 0; i < dgv_Data.Columns.Count; i++)
            {
                dgv_Data.Columns[i].HeaderCell.Style = styleHeader;
                // dgv_Data.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

        }
        private void createGrid()
        {

            dgv_Data.Rows.Clear();
            dgv_Data.Columns.Clear();
            dgv_Data.DataSource = null;

            DataGridViewCheckBoxColumn colCheck = new DataGridViewCheckBoxColumn();
            colCheck.Name = "check";
            dgv_Data.Columns.Add(colCheck);
            dgv_Data.Columns[0].HeaderText = "Check";
            dgv_Data.Columns[0].Width = 48;
    
            dgv_Data.Columns.Add("c_loai", "Loại master");
            dgv_Data.Columns[1].Width = 190;
            dgv_Data.Columns[1].ReadOnly = true;
            dgv_Data.Columns[1].DataPropertyName = "c_loai";
            dgv_Data.Columns[1].DefaultCellStyle.BackColor = Color.LightGray;


            dgv_Data.Columns.Add("C_ITEM", "Nội dung");
            dgv_Data.Columns[2].Width = 220;
            dgv_Data.Columns[2].ReadOnly = true;
            dgv_Data.Columns[2].DataPropertyName = "C_ITEM";
            dgv_Data.Columns[2].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_type", "Loại master");
            dgv_Data.Columns[3].Width = 85;
            dgv_Data.Columns[3].ReadOnly = true;
            dgv_Data.Columns[3].Visible = false;
            dgv_Data.Columns[3].DataPropertyName = "c_type";
            dgv_Data.Columns[3].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("C_USER", "Người cập nhật");
            dgv_Data.Columns[4].Width = 125;
            dgv_Data.Columns[4].ReadOnly = true;
            dgv_Data.Columns[4].DataPropertyName = "C_USER";
            dgv_Data.Columns[4].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("DT_DATE", "Ngày cập nhật");
            dgv_Data.Columns[5].Width = 160;
            dgv_Data.Columns[5].ReadOnly = true;
            dgv_Data.Columns[5].DataPropertyName = "DT_DATE";
            dgv_Data.Columns[5].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_ma", "Mã");
            dgv_Data.Columns[6].Width = 85;
            dgv_Data.Columns[6].ReadOnly = true;
            dgv_Data.Columns[6].Visible = false;
            dgv_Data.Columns[6].DataPropertyName = "c_ma";
            dgv_Data.Columns[6].DefaultCellStyle.BackColor = Color.LightGray;

            FormatGrid();

        }

        private void Loaddata()
        {
            string _sql = string.Empty;

            _sql = "SELECT DISTINCT M.C_TYPE || ':' ||M1.C_KNRNIY c_loai , upper(M.C_ITEM) C_ITEM , "
                  + "  M.C_TYPE as C_TYPE,  c_ma    "  //, row_number() over (order by C_KNRKBN2 asc) as row_num 
                  + "     FROM M_COMMON M INNER JOIN M_UNYKNR M1 "
                  + " ON M.C_TYPE=M1.C_KNRKBN2  "
                  + "order by C_TYPE, c_ma ";
            _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                _dt_data = _ds.Tables[0];

            }
            else
            {
                _dt_data = _ds.Tables[0];
            }

            _sql = string.Empty;
            //SELECT distinct  M1.C_KNRKBN2 || ':' || M1.C_KNRNIY as c_loai, C_KNRKBN2
            //FROM M_UNYKNR M1  left join  m_common m2  on m1.c_knrkbn2 = m2.c_type
            //ORDER BY C_KNRKBN2
            _sql = " SELECT distinct  M1.C_KNRKBN2 || ':' || M1.C_KNRNIY as c_loai, C_KNRKBN2 "
                + " FROM M_UNYKNR M1  left join  m_common m2  on m1.c_knrkbn2 = m2.c_type "
                + "ORDER BY C_KNRKBN2 ";         

            DataSet _ds1 = new DataSet();
            _ds1 = _cn.Get_ds_CommandSQL(_sql);
            if (_ds1.Tables[0].Rows.Count > 0)
            {
             
                DataRow row = _ds1.Tables[0].NewRow();
                _ds1.Tables[0].Rows.InsertAt(row, 0);
                cmb_loai.DataSource = _ds1.Tables[0];
                cmb_loai.DisplayMember = "c_loai";
                cmb_loai.ValueMember = "C_KNRKBN2";

            }
         
        }
        private void Loadcombox_loai_TK()
        {
            string _sql = string.Empty;
            _sql = " SELECT distinct  M1.C_KNRKBN2 || ':' || M1.C_KNRNIY as c_loai, C_KNRKBN2 "
              + " FROM M_UNYKNR M1  left join  m_common m2  on m1.c_knrkbn2 = m2.c_type "
              + "ORDER BY C_KNRKBN2 ";

            DataSet _ds1 = new DataSet();
            _ds1 = _cn.Get_ds_CommandSQL(_sql);
            if (_ds1.Tables[0].Rows.Count > 0)
            {

                DataRow row = _ds1.Tables[0].NewRow();
                _ds1.Tables[0].Rows.InsertAt(row, 0);
                cmb_loai_TK.DataSource = _ds1.Tables[0];
                cmb_loai_TK.DisplayMember = "c_loai";
                cmb_loai_TK.ValueMember = "C_KNRKBN2";

            }
        }

        private void Loadcombox_TK()
        {
            Loadcombox_loai_TK();
       
        }
       
        private void frm_m_kho_Load(object sender, EventArgs e)
        {
            createGrid();
            Loaddata();
            Loadcombox_TK();         
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        string _c_type_B = string.Empty;
        string _c_ma_B = string.Empty;
        string _c_item_B = string.Empty;
        string _c_type_E = string.Empty;
        string _c_item_E = string.Empty;

        private void dgv_Data_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && e.ColumnIndex != -1)
            {
                _flagupdate = 1;

                if (dgv_Data.Rows[e.RowIndex].Cells["c_type"].Value != string.Empty)
                {

                    _c_type_B = dgv_Data.Rows[e.RowIndex].Cells["c_type"].Value.ToString();
                    _c_ma_B = dgv_Data.Rows[e.RowIndex].Cells["c_ma"].Value.ToString();
                    cmb_loai.Text = dgv_Data.Rows[e.RowIndex].Cells["c_loai"].Value.ToString();

                }

                if (dgv_Data.Rows[e.RowIndex].Cells["c_item"].Value != string.Empty)
                {

                    _c_item_B = dgv_Data.Rows[e.RowIndex].Cells["c_item"].Value.ToString().Trim();
                    txt_noidung.Text = _c_item_B;
                }
            }


        }
        private void btn_Save_Click(object sender, EventArgs e)
        {
            string _c_loaimaster= string.Empty;
            string _c_type = string.Empty;
            string _c_noidung= string.Empty;
            int _stt = 0;
            int _stt_new = 0;
            string _c_ma= string.Empty;
            string _row_id = string.Empty;
            int _kq = 0;

            DataSet _ds_stt = new DataSet();
            if (cmb_loai.Text == "" || cmb_loai.Text == string.Empty)
            {
                MessageBox.Show("Vui lòng chọn loại master!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                _c_loaimaster = cmb_loai.Text;
                string[] a = _c_loaimaster.Split(':');
                if (a[0] != string.Empty)
                {
                    _c_type = a[0].ToString();
                }
            }

            if (txt_noidung.Text == "" || txt_noidung.Text == string.Empty)
            {
                MessageBox.Show("Chưa nhập nội dung!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
                _c_noidung = txt_noidung.Text.Trim();

            }

            string _sql = string.Empty;
            _sql = "     SELECT max(to_number(c_ma, '9999999')) FROM m_common "
                + "where c_type = '" + _c_type + "' ";
            _ds_stt = _cn.Get_ds_CommandSQL(_sql);
            if (_ds_stt.Tables[0].Rows.Count > 0)
            {
                _stt = Convert.ToInt32(_ds_stt.Tables[0].Rows[0][0].ToString());
            }

            if (_flagupdate == 0)
            {
                DataRow[] dr_check = _dt_data.Select("c_type  = '" + _c_type + "' and  ( c_item = '" + _c_noidung + "'  or   c_item = '" + _c_noidung.ToUpper() + "') ");
                if (dr_check.Length > 0)
                {

                    MessageBox.Show("Dữ liệu đã có rồi", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    //insert new
                    _stt_new = _stt + 1;
                    _c_ma = string.Format("{0:000}", _stt_new);

                    if (_c_type == "01")
                    {
                        _sql = string.Empty;
                        _sql = " insert into m_common (c_type, c_ma, c_item, c_user, dt_date) "
                            + " values('" + _c_type + "','" + _c_ma + "', '" + _c_noidung.ToUpper() + "' ,  '" + _msnv + "' ,  CURRENT_TIMESTAMP ) ";
                        _kq = _cn.Execute_Nonquery(_sql);
                    }
                    else
                    {
                        _sql = string.Empty;
                        _sql = " insert into m_common (c_type, c_ma, c_item, c_user, dt_date) "
                            + " values('" + _c_type + "','" + _c_ma + "', '" + _c_noidung + "' ,  '" + _msnv + "' ,  CURRENT_TIMESTAMP ) ";
                        _kq = _cn.Execute_Nonquery(_sql);
                    }
                }
            }
            else
            {
                //update
                if (_c_type_B == _c_type)
                {
                    DataRow[] dr_check = _dt_data.Select("c_type  = '" + _c_type_B + "' and   c_ma = '" + _c_ma_B + "' ");
                    if (dr_check.Length > 0)
                    {
                        if (_c_noidung != _c_item_B || _c_noidung.ToUpper() != _c_item_B)
                        {
                            if (_c_type == "01")
                            {
                                _sql = string.Empty;
                                _sql = " UPDATE m_common  "
                                    + " set  c_item = '" + _c_noidung.ToUpper() + "' , c_user = '" + _msnv + "', dt_date = CURRENT_TIMESTAMP"
                                + " where c_type  = '" + _c_type_B + "' and c_ma = '" + _c_ma_B + "'  ";
                                _kq = _cn.Execute_Nonquery(_sql);
                            }
                            else
                            {
                                _sql = string.Empty;
                                _sql = " UPDATE m_common  "
                                    + " set  c_item = '" + _c_noidung + "' , c_user = '" + _msnv + "', dt_date = CURRENT_TIMESTAMP"
                                + " where c_type  = '" + _c_type_B + "' and c_ma = '" + _c_ma_B + "'  ";
                                _kq = _cn.Execute_Nonquery(_sql);
                            }

                        }
                    }
                }

            }     

            if (_kq == 1)
            {              
                Clear_input();
                MessageBox.Show("Lưu dữ liệu thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Loadcombox_TK();
                Loaddata();
             
            }
          
        }

        private void TimKiem()
        {
            string _loai = string.Empty;
            string _noidung = string.Empty;
            string _ma = string.Empty;
            DataSet _ds_search = new DataSet();
            string _sql = string.Empty;
            if (cmb_loai_TK.Text == "" || cmb_loai_TK.Text == string.Empty)
            {
                MessageBox.Show("Vui lòng chọn loại master!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);            
                return;
            }
            else
            {
                _loai = cmb_loai_TK.Text;      
            }

            _sql = "SELECT DISTINCT M.C_TYPE || ':' ||M1.C_KNRNIY c_loai,  M.C_ITEM , "
                    + " M.C_TYPE as C_TYPE,  M.C_USER, TO_CHAR(M.DT_DATE,'yyyy/MM/dd hh24:mi:ss') DT_DATE ,  c_ma   "
            //        + " row_number() over (order by C_KNRKBN2 asc) as row_num "
                    +"     FROM M_COMMON M INNER JOIN M_UNYKNR M1 "
                    +" ON M.C_TYPE=M1.C_KNRKBN2   where 1 = 1 and "
                    + " M.C_TYPE || ':' ||M1.C_KNRNIY =  '" + _loai + "' "
                    + " order by C_TYPE, c_ma";

            _ds_search = _cn.Get_ds_CommandSQL(_sql);

            if (_ds_search.Tables[0].Rows.Count > 0)
            {
                dgv_Data.AutoGenerateColumns = false;
                dgv_Data.DataSource = _ds_search.Tables[0];
                txt_sodong.Text = _ds_search.Tables[0].Rows.Count.ToString();

            }
            else
            {
                dgv_Data.DataSource = _ds_search.Tables[0];
                txt_sodong.Text = string.Empty;
                MessageBox.Show("Không có dữ liệu.!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);             
                return;
            }

        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            TimKiem();
        }

        private void Clear_input()
        {
            cmb_loai_TK.SelectedIndex = -1;
            cmb_loai.SelectedIndex = -1;
            txt_noidung.Text = string.Empty;
            txt_sodong.Text = string.Empty;
            dgv_Data.DataSource = null;
        
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            Clear_input();
        }

        private void dgv_Data_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int _cot = e.ColumnIndex;
            if (dgv_Data.RowCount > 0)
            {
                dgv_Data.CurrentCell = dgv_Data.Rows[0].Cells[1];
                if (_cot == 0)
                {
                    bool kq = dgv_Data.Rows[0].Cells[0].Value == null ? false : Convert.ToBoolean(dgv_Data.Rows[0].Cells[0].Value.ToString());
                    for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                    {
                        dgv_Data.Rows[i].Cells[_cot].Value = !kq;
                    }
                }
            }         
        }
        private void DeleteData()
        {
            int _kq = 0;
            int count_kq = 0;

            string _c_type = string.Empty;
            string _c_ma = string.Empty;

            string _sql = string.Empty;

            if (dgv_Data.Rows.Count > 0)
            {
                int dem = 0;
                for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                {
                    //kiem tra neu co 1 dong dc check thi xoa
                    if (Convert.ToBoolean(dgv_Data.Rows[i].Cells[0].Value) == true)// lay vi tri cua dong dang check
                    {

                        dem++;
                        continue;
                    }

                }
                if (dem == 0)
                {
                    MessageBox.Show("Bạn chưa chọn dòng cần xóa", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (MessageBox.Show("Bạn Có Muốn Xóa Không", "Thông Báo!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                    {
                        if (dgv_Data.Rows[i].Cells["check"].Value != null)
                        {
                            if (dgv_Data.Rows[i].Cells["check"].Value.ToString() == "True" || dgv_Data.Rows[i].Cells["check"].Value.ToString() == "1")
                            {

                                _c_type = dgv_Data.Rows[i].Cells["c_type"].Value.ToString();
                                _c_ma = dgv_Data.Rows[i].Cells["c_ma"].Value.ToString();

                                _sql = "delete from  m_common  WHERE c_type =  '" + _c_type + "'  and c_ma =  '" + _c_ma + "' ";
                               _kq = _cn.Execute_Nonquery(_sql);
                                if (_kq == 1)
                                {
                                    count_kq = count_kq + 1;
                                }
                             
                            }
                        }

                    }
                }

            }

            else
            {
                MessageBox.Show("Không có dữ liệu để xóa", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            if (count_kq > 0)
            {
                Clear_input();
                Loadcombox_TK();   
                Loaddata();
                
                MessageBox.Show("Đã xóa thành công.", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Xóa dữ liệu bị lỗi.", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            DeleteData();
        }
        private static void ExportExcel(System.Data.DataTable _dtT)
        {
            SaveFileDialog sFD = new SaveFileDialog();
            sFD.FileName = "";
            sFD.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";

            sFD.ShowDialog();
            if (sFD.FileName == "")
                return;
            System.IO.File.Copy(System.Windows.Forms.Application.StartupPath + "\\Export_excel.xlsx", sFD.FileName, true);
            Excel.Application _app = new Excel.Application();
            Excel.Workbook _wb = _app.Workbooks.Open(sFD.FileName, 0, false, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true);


            Excel.Sheets sheets = _wb.Worksheets;
            Excel.Worksheet _ws = (Excel.Worksheet)sheets.get_Item(1);
            object[,] arr = new object[_dtT.Rows.Count + 1, _dtT.Columns.Count];
         //Loại master, Nội dung, Loại master, Người cập nhật, Ngày cập nhật
            string[] _arrHeader = { "Loại master"
                                                , "Nội dung"
                                                , "Loại master"      
                                                     , "Người cập nhật"   
                                                          , "Ngày cập nhật"   
                                                };
            //lay ten cua cot
            for (int i = 0; i < _arrHeader.Length; i++)
            {
                arr[0, i] = _arrHeader.GetValue(i);
                Excel.Range rng_tieude = (Excel.Range)_ws.Cells[1, i + 1];
                rng_tieude.Font.Bold = true;
                rng_tieude.Font.Size = 12;
            }
            //do du lieu 
            for (int r = 0; r < _dtT.Rows.Count; r++)
            {
                DataRow dr = _dtT.Rows[r];
                for (int c = 0; c < _dtT.Columns.Count; c++)
                {
                    if (c == 2)
                    {
                        arr[r + 1, c] = "'" + dr[c].ToString();

                    }
                    else
                    {
                        arr[r + 1, c] = dr[c].ToString();
                    }   

                    //arr[r + 1, c] = dr[c];
                    //if (c == 2)
                    //{
                    //    Excel.Range rng_data = (Excel.Range)_app.Cells[r + 1, 2];
                    //    rng_data.EntireColumn.NumberFormat = "@";
                    //}

                }
            }

            Excel.Range c1 = (Excel.Range)_ws.Cells[1, 1];
            Excel.Range c2 = (Excel.Range)_ws.Cells[1 + _dtT.Rows.Count - 1 + 1, _dtT.Columns.Count];

            Excel.Range range = _ws.get_Range(c1, c2);
            range.Value = arr;
            _app.Columns.AutoFit();
            _app.DisplayAlerts = false;
            _wb.Close(true, Missing.Value, Missing.Value);
            _app.Quit();
            releaseObject(_ws);
            releaseObject(_wb);
            releaseObject(_app);
            _ws = null;
            _wb = null;
            _app = null;
        }

        private static void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        private void btn_Excel_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv_Data.RowCount <= 0)
                {
                    MessageBox.Show("Không có dữ liệu để xuất Excel.!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    System.Data.DataTable _dtExcel = new System.Data.DataTable();
                    _dtExcel = (DataTable)dgv_Data.DataSource;
                    _dtExcel.Columns.Remove("c_ma");
                    _dtExcel.AcceptChanges();
                    if (MessageBox.Show("Bạn Có Muốn Xuất Ra Excel Không ???", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        this.Cursor = Cursors.WaitCursor;
                        ExportExcel(_dtExcel);
                        this.Cursor = Cursors.Default;
                        MessageBox.Show("Xuất Excel thành công.!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
      





    }
}
