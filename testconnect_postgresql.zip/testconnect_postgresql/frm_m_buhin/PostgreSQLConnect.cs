﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Npgsql;
using System.Windows.Forms;
using System.Xml;

    public class DataProvider
    {
        protected NpgsqlCommand _cmd;
        protected NpgsqlDataAdapter _adap;
        protected DataSet _ds;
        //https://qiita.com/mimitaro/items/fde451da2f722fe12072

        public static string GetXMLconn()
        {
            string xmlConStr = "";
            //
            string XMLconnect =Application.StartupPath + @"\" + "ConnectionString.xml";

            // Get the Connection String from the XML file.
            XmlTextReader textReader = new XmlTextReader(XMLconnect);
          
            DataSet Tbl_table = new DataSet();
            Tbl_table.ReadXml(textReader);
            xmlConStr = Tbl_table.Tables[0].Rows[0][0].ToString();        
            return xmlConStr;

            //https://www.sqlines.com/postgresql/npgsql_cs_result_sets
        }
    
        NpgsqlConnection connection = new NpgsqlConnection(GetXMLconn());
          //_dt = new DataTable();
          //  cmd_str = "SELECT * FROM test";
          //  cmd = new NpgsqlCommand(cmd_str, conn);
          //  da = new NpgsqlDataAdapter(cmd);
          //  da.Fill(dt);

        public  DataSet Get_ds_CommandSQL(string _strSQL)
        {

            _cmd = new NpgsqlCommand();
            _adap = new NpgsqlDataAdapter();           
            _ds = new DataSet();
            try
            {
              
                connection.Open();
                _cmd.Connection = connection;
                _cmd.CommandText = _strSQL;
                _cmd.CommandType = CommandType.Text;

                _cmd.ExecuteNonQuery();
                _adap.SelectCommand = _cmd;
                _ds.Clear();
                _adap.Fill(_ds);
                connection.Close();
                _cmd.Dispose();
                _adap.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _ds;
        }
        
        public  DataTable Get_dt_CommandSQL(string _strSQL)
        {

            _cmd = new NpgsqlCommand();
            _adap = new NpgsqlDataAdapter();           
            DataTable _dt = new DataTable();
            try
            {              
                connection.Open();
                _cmd.Connection = connection;
                _cmd.CommandText = _strSQL;
                _cmd.CommandType = CommandType.Text;
                _cmd.ExecuteNonQuery();
                _adap.SelectCommand = _cmd;              
                _adap.Fill(_dt);
                connection.Close();
                _cmd.Dispose();
                _adap.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _dt;
        }

   

        //public static int UpdateUser(string UserId, string Password, out string ErrorMessage)
        //{
        //    int result = 0;
        //    ErrorMessage = null;

        //    NpgsqlConnectionStringBuilder sb = new NpgsqlConnectionStringBuilder();
        //    sb.Host = "localhost";
        //    sb.Port = 5432;
        //    sb.Username = "postgres";
        //    sb.Password = "23112001";
        //    sb.Database = "demo2";

        //    using (NpgsqlConnection conn = new NpgsqlConnection(sb.ToString()))
        //    {
        //        conn.Open();

        //        string dml = "insert into tbl_users (username, password) values (:USER, :PW)";

        //        using (NpgsqlCommand cmd = new NpgsqlCommand(dml, conn))
        //        {
        //            cmd.Parameters.AddWithValue("USER", UserId);
        //            cmd.Parameters.AddWithValue("PW", Password);

        //            try
        //            {
        //                result = cmd.ExecuteNonQuery();
        //            }
        //            catch (Exception ex)
        //            {
        //                ErrorMessage = ex.Message;
        //            }
        //        }
        //    }

        //    return result;
      
//private DataSet  FetchAll(NpgsqlConnection _connection, object cursorVal)
//{
//    try
//    {
//        DataSet actualData = new DataSet();

//        string strSql = "fetch all from \"" + cursorVal + "\";";
//        NpgsqlCommand cmd = new NpgsqlCommand(strSql, _connection);
//        NpgsqlDataAdapter ada = new NpgsqlDataAdapter(cmd);
//        ada.Fill(actualData);

//        return actualData;

//    }
//    catch (Exception Exp)
//    {
//        throw new Exception(Exp.Message);
//    }
//}
//        conn.Open();
//NpgsqlTransaction tran = conn.BeginTransaction();

//NpgsqlCommand command = new NpgsqlCommand("select show_cities(@ref)", conn);
//command.CommandType = CommandType.Text;
//NpgsqlParameter p = new NpgsqlParameter();
//p.ParameterName = "@ref";
//p.NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Refcursor;
//p.Direction = ParameterDirection.InputOutput;
//p.Value = "ref";
//command.Parameters.Add(p);
//command.ExecuteNonQuery();

//command.CommandText = "fetch all in \"ref\"";
//command.CommandType = CommandType.Text;

//NpgsqlDataReader dr = command.ExecuteReader();
//while (dr.Read())
//{
//    // do what you want with data, convert this to json or...
//    Console.WriteLine(dr[0]);
//}
//dr.Close();

//tran.Commit();
//conn.Close();
        public System.Data.DataTable GetData_Proc(string _storename)
        {

            _cmd = new NpgsqlCommand();
            _adap = new NpgsqlDataAdapter();
            System.Data.DataTable _dt = new System.Data.DataTable();

            try
            {
                connection.Open();
                _cmd.Connection = connection;
                NpgsqlTransaction tran = connection.BeginTransaction();
                _cmd.CommandType = CommandType.StoredProcedure;           
                _cmd.CommandType = CommandType.Text;
                _cmd = new NpgsqlCommand(_storename, connection);

      //          NpgsqlCommand cmd = new NpgsqlCommand(_storename, connection);

            //    NpgsqlParameter p_userid =
            //    _cmd.Parameters.Add("p_userid", NpgsqlTypes.NpgsqlDbType.Varchar);
            //    p_userid.Direction = ParameterDirection.Input;
            // //   p_userid.Value = this.textBox1.Text;

            //    NpgsqlParameter p_passwod =
            //    _cmd.Parameters.Add("p_password", NpgsqlTypes.NpgsqlDbType.Varchar);
            //    p_passwod.Direction = ParameterDirection.Input;
            ////    p_passwod.Value = this.textBox2.Text;

                //NpgsqlParameter v_usertext =
                //_cmd.Parameters.Add("v_usertext", NpgsqlTypes.NpgsqlDbType.Varchar);
                //v_usertext.Direction = ParameterDirection.Output;

                //NpgsqlParameter v_status =
                //_cmd.Parameters.Add("v_status", NpgsqlTypes.NpgsqlDbType.Varchar);
             //   v_status.Direction = ParameterDirection.Output;
             
                    _cmd.ExecuteNonQuery();
                    //_cmd.CommandText = "fetch all in \"vref\"";
                    //_cmd.CommandType = CommandType.Text;
                    _adap.SelectCommand = _cmd;
                    _adap.Fill(_dt);


                    tran.Commit();
                    connection.Close();
                    _cmd.Dispose();
                    _adap.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _dt;
        }

        //public int Execute_Nonquery(string _sql, string[] _arrparameter, string[] _arrvalue)
        //{
        //    int kq;

        //    _connOra = _conn.Connect();
        //    _cmd = new OracleCommand();
        //    _cmd.Connection = _connOra;
        //    _cmd.CommandText = _sql;

        //    _cmd = new NpgsqlCommand(_sql, connection);
        //    for (int i = 0; i <= _arrparameter.Length - 1; i++)
        //    {
        //        _cmd.Parameters.AddWithValue(_arrparameter[i], _arrvalue[i]);
        //    }
        //    _cmd.Parameters.Add(new OracleParameter("kq", OracleType.Number)).Direction = ParameterDirection.Output;
        //    _cmd.ExecuteNonQuery();
          
        //    _conn.Disconnect();
        //    return kq;

        //}


        public int Execute_Nonquery(string _sql  ) //, string[] _arrparameter, string[] _arrvalue )
        {
            int _kq;
            _cmd = new NpgsqlCommand();
            _adap = new NpgsqlDataAdapter();
            System.Data.DataTable _dt = new System.Data.DataTable();
         
            try
            {
                connection.Open();
                _cmd.Connection = connection;
               NpgsqlTransaction tran = connection.BeginTransaction();

                //_cmd = new NpgsqlCommand(_sql, connection);
            
          //      _cmd.CommandType = CommandType.StoredProcedure;

                //for (int i = 0; i <= _arrparameter.Length - 1; i++)
                //{
                //    _cmd.Parameters.AddWithValue(_arrparameter[i], _arrvalue[i]);
                //}
               
                _cmd = new NpgsqlCommand(_sql, connection);

                //NpgsqlCommand komut2 = new NpgsqlCommand("insert into kategoriler (yazarid,yazarad) values (@p1,@p2)", bglnti);
                //komut2.Parameters.AddWithValue("@p1", int.Parse(textBox1.Text));
                //komut2.Parameters.AddWithValue("@p2", textBox2.Text);

                //_cmd.Parameters.AddWithValue(":p_msnv", _msnv);
                //_cmd.Parameters.AddWithValue(":p_hoten", _hoten);
                //_kq = (int)_cmd.ExecuteScalar();
                //_cmd.Parameters.Add(new NpgsqlParameter(":p_msnv", NpgsqlTypes.NpgsqlDbType.Varchar));
                //_cmd.Parameters[":p_msnv"].Value = _msnv;
                //_cmd.Parameters.Add(new NpgsqlParameter(":p_hoten", NpgsqlTypes.NpgsqlDbType.Varchar));
                //_cmd.Parameters[":p_hoten"].Value = _hoten;
          
           //     _kq = _cmd.ExecuteNonQuery();
            //    _cmd.Parameters.Add(new NpgsqlParameter("kq", NpgsqlTypes.NpgsqlDbType.Integer)).Direction = ParameterDirection.Output;

         //       _kq = Convert.ToInt16(_cmd.Parameters["kq"].Value);

                 _cmd.ExecuteNonQuery();
               _kq = 1;
                tran.Commit();
                connection.Close();
                _cmd.Dispose();
                _adap.Dispose();


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _kq;


        }
        //public int Execute_Nonquery(string _storename, string[] _arrparameter, string[] _arrvalue)
        //{
        //    int _kq;
        //         _cmd = new NpgsqlCommand();
        //    _adap = new NpgsqlDataAdapter();
        //    System.Data.DataTable _dt = new System.Data.DataTable();

        //    try
        //    {
        //        connection.Open();
        //        _cmd.Connection = connection;
        //        NpgsqlTransaction tran = connection.BeginTransaction();
        //        _cmd = new NpgsqlCommand(_storename, connection);
        //    //    _cmd.CommandText = _storename;
        //        _cmd.CommandType = CommandType.StoredProcedure;
           
        //        for (int i = 0; i <= _arrparameter.Length - 1; i++)
        //        {
        //            _cmd.Parameters.AddWithValue(_arrparameter[i], _arrvalue[i]);
        //        }
           
        //        _cmd.Parameters.Add(new NpgsqlParameter("kq", NpgsqlTypes.NpgsqlDbType.Integer)).Direction = ParameterDirection.Output;
               
        //        _cmd.ExecuteNonQuery();
        //        tran.Commit();
        //        //_adap.SelectCommand = _cmd;
        //        //_adap.Fill(_dt);
        //        ////int? testID = null;
        //        ////if (cmd.Parameters["@TestID"].Value != DBNull.Value)
        //        ////{
        //        ////    testID = Convert.ToInt32(cmd.Parameters["@TestID"].Value);
        //        ////}
        //            _kq = Convert.ToInt16(_cmd.Parameters["kq"].Value);

        //        connection.Close();
        //        _cmd.Dispose();
        //        _adap.Dispose();


        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return _kq;


        //    //_conn = connect.Connect();
        //    //_cmd = new OracleCommand();
        //    //_cmd.Connection = _conn;
        //    //_cmd.CommandText = _Store_name;
        //    //_cmd.CommandType = CommandType.StoredProcedure;
        //    //for (int i = 0; i <= _arrparameter.Length - 1; i++)
        //    //{
        //    //    _cmd.Parameters.AddWithValue(_arrparameter[i], _arrvalue[i]);
        //    //}
        //    //_cmd.Parameters.Add(new OracleParameter("kq", OracleType.Number)).Direction = ParameterDirection.Output;
        //    //_cmd.ExecuteNonQuery();
        //    //_kq = Convert.ToInt16(_cmd.Parameters["kq"].Value);
        //    //connect.Disconnect();
        //    //return _kq;
        //}

//https://medium.com/@karthicksrinivasan.s42/simplifying-postgresql-function-calls-in-c-with-pg2csharp-26fb1d3afd02
        //////public System.Data.DataTable GetData_Proc(string _storename)
        //////{

        //////    _cmd = new NpgsqlCommand();
        //////    _adap = new NpgsqlDataAdapter();
        //////    System.Data.DataTable _dt = new System.Data.DataTable();
       
        //////    try
        //////    {
        //////       //https://stackoverflow.com/questions/32862416/how-can-i-get-cursor-data-with-calling-stored-procedure-in-npgsql
        //////        connection.Open();
        //////        _cmd.Connection = connection;
        //////        // Start a transaction as it is required to work with result sets (cursors) in PostgreSQL
        //////        NpgsqlTransaction tran = connection.BeginTransaction();
        //////        _cmd.CommandType = CommandType.Text;
        //////        _cmd = new NpgsqlCommand(_storename, connection);
        //////        //_cmd.ExecuteNonQuery();           
        //////        //_adap.SelectCommand = _cmd;              
        //////        //_adap.Fill(_dt);

        //////        NpgsqlDataAdapter da = null;
        //////        da = new NpgsqlDataAdapter(_cmd);
        //////        da.Fill(_dt);

        //////        //using (var command = new NpgsqlCommand("your_stored_procedure", connection))
        //////        //{
        //////        //    command.CommandType = System.Data.CommandType.StoredProcedure;

        //////        //    // ストアドプロシージャのパラメータを設定
        //////        //    // 例: command.Parameters.AddWithValue("param1", value);

        //////        //    command.ExecuteNonQuery();
        //////        //}


        //////  //      _cmd.CommandType = CommandType.Text;
        //////  //      _cmd.CommandText = _storename;
        //////  //      _cmd.CommandType = CommandType.StoredProcedure;
        //////  //      //_cmd.Parameters.Clear();
        //////  ////  _cmd.Parameters.Add(new NpgsqlParameter("vref", NpgsqlTypes.NpgsqlDbType.Refcursor)).Direction = ParameterDirection.Output;
        //////  //   NpgsqlDataReader dr = _cmd.ExecuteReader();
        //////  //   while (dr.Read())
        //////  //       Console.Write("{0}\t{1} \n", dr[0], dr[1]);
        //////      //NpgsqlParameter p = new NpgsqlParameter();
        //////      //p.ParameterName = "@vref";
        //////      //p.NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Refcursor;
        //////      //p.Direction = ParameterDirection.InputOutput;
        //////      //p.Value = "vref";
        //////      //  _cmd.ExecuteNonQuery();
        //////      //  _cmd.CommandText = "fetch all in \"<unnamed portal 1>\"";
        //////       // _cmd.CommandText = "fetch all in \"<unnamed portal 1>\"";
              
        //////        //     ExecuteNonQueryAsync
        //////        //_adap.SelectCommand = _cmd;
        //////        //_ds.Clear();
        //////        //_adap.Fill(_dt);             
        //////        tran.Commit();
        //////        connection.Close();
        //////        _cmd.Dispose();
        //////        _adap.Dispose();
        //////    }
        //////    catch (Exception ex)
        //////    {
        //////        throw ex;
        //////    }
        //////    return _dt;
        
        //////}

        public System.Data.DataTable GetData_Proc2(string _storename)
        {

            _cmd = new NpgsqlCommand();
            _adap = new NpgsqlDataAdapter();
            System.Data.DataTable _dt = new System.Data.DataTable();

            try
            {
                //https://stackoverflow.com/questions/32862416/how-can-i-get-cursor-data-with-calling-stored-procedure-in-npgsql
                connection.Open();
                _cmd.Connection = connection;
                // Start a transaction as it is required to work with result sets (cursors) in PostgreSQL
                NpgsqlTransaction tran = connection.BeginTransaction();
                _cmd.CommandType = CommandType.Text;
                _cmd.CommandText = _storename;
                _cmd.CommandType = CommandType.StoredProcedure;
                _cmd.Parameters.Clear();
              
                _adap.SelectCommand = _cmd;
                _ds.Clear();
                _adap.Fill(_dt);
                tran.Commit();
                connection.Close();
                _cmd.Dispose();
                _adap.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _dt;

        }
        //public System.Data.DataTable Execute_Proc_parameter(string _strSQL, string[] _arrparameter, string[] _arrvalue)
        //{
        //    _cmd = new NpgsqlCommand();
        //    _adap = new NpgsqlDataAdapter();
        // //   _ds = new DataSet();

        //    System.Data.DataTable _dt = new System.Data.DataTable();
        //    try
        //    {

        //        connection.Open();
        //        _cmd.Connection = connection;
        //        _cmd.CommandText = _strSQL;
        //        _cmd.CommandType = CommandType.Text;
        //        for (int i = 0; i <= _arrparameter.Length - 1; i++)
        //        {
        //            //_cmd.Parameters.Add(new OracleParameter("" + _arrparameter[i].ToString() + "", OracleType.VarChar)).Value = _arrvalue[i].ToString();//.add.AddWithValue(_arrparameter[i], _arrvalue[i]);
        //            _cmd.Parameters.AddWithValue(_arrparameter[i], _arrvalue[i]);
        //        }
        //        _cmd.Parameters.Add(new NpgsqlParameter("data", n.Cursor)).Direction = ParameterDirection.Output;
        //        _cmd.ExecuteNonQuery();
        //        _adap.SelectCommand = _cmd;
        //        _ds.Clear();
        //        _adap.Fill(_ds);
        //        connection.Close();
        //        _cmd.Dispose();
        //        _adap.Dispose();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return _dt;

        //    _conn = connect.Connect();
        //    _cmd = new OracleCommand();
        //    _adap = new OracleDataAdapter();

        //    _cmd.Connection = _conn;

        //    _cmd.CommandText = _storename;
        //    _cmd.CommandType = CommandType.StoredProcedure;
        //    _cmd.Parameters.Clear();

        //    for (int i = 0; i <= _arrparameter.Length - 1; i++)
        //    {
        //        //_cmd.Parameters.Add(new OracleParameter("" + _arrparameter[i].ToString() + "", OracleType.VarChar)).Value = _arrvalue[i].ToString();//.add.AddWithValue(_arrparameter[i], _arrvalue[i]);
        //        _cmd.Parameters.AddWithValue(_arrparameter[i], _arrvalue[i]);
        //    }
        //    _cmd.Parameters.Add(new OracleParameter("data", OracleType.Cursor)).Direction = ParameterDirection.Output;

        //    _cmd.ExecuteNonQuery();
        //    _adap.SelectCommand = _cmd;
        //    _adap.Fill(_dt);
        //    connect.Disconnect();
        //    return _dt;
        //}

        //public static DataSet GetData_CommandProc(string _nameProc)
        //{
        //    _OraCnn = new OracleConnection(clsCommon.OraConnectString);
        //    _OraCmd = new OracleCommand();
        //    _OraDa = new OracleDataAdapter();
        //    _ds = new DataSet();
        //    _OraCnn.Open();
        //    try
        //    {
        //        _OraCmd.Connection = _OraCnn;
        //        _OraCmd.CommandText = _nameProc;
        //        _OraCmd.CommandType = CommandType.StoredProcedure;
        //        _OraCmd.Parameters.Clear();
        //        _OraCmd.Parameters.Add(new OracleParameter("data", OracleType.Cursor)).Direction = ParameterDirection.Output;
        //        _OraCmd.ExecuteNonQuery();
        //        _OraDa.SelectCommand = _OraCmd;
        //        _ds.Clear();
        //        _OraDa.Fill(_ds);
        //        _OraCnn.Close();
        //        _OraCmd.Dispose();
        //        _OraDa.Dispose();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return _ds;
        //}

        //public System.Data.DataTable Execute_Proc(string _Store_name)
        //{
        //    System.Data.DataTable _dt = new System.Data.DataTable();
        
        //    _cmd = new NpgsqlCommand();
        //    _adap = new NpgsqlDataReader();
        //    connection.Open();
        //    //_cmd.CommandText = _Store_name;
        //    //_cmd.CommandType = CommandType.StoredProcedure;
        //    //_cmd.Parameters.Add(new OracleParameter("data", OracleType.Cursor)).Direction = ParameterDirection.Output;
        //    _cmd.ExecuteNonQuery();
        //    _adap.SelectCommand = _cmd;
        //    _adap.Fill(_dt);
        //    connection.Dispose();
         
        //    return _dt;


        //}

        //public static void CapNhat_data(string str_)
        //{
        //    try
        //    {
        //        OracleConnection ketnoi = new OracleConnection(connstring);
        //        ketnoi.Open();
        //        OracleTransaction oratr = ketnoi.BeginTransaction();
        //        OracleCommand command = new OracleCommand(str_, ketnoi);
        //        // OracleCommand _timeout = new OracleCommand();
        //        command.Connection = ketnoi;
        //        command.CommandText = str_;
        //        command.Transaction = oratr;
        //        command.CommandType = CommandType.Text;
        //        command.ExecuteNonQuery();
        //        command.Dispose();
        //        oratr.Commit();
        //        ketnoi.Close();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        //public System.Data.DataTable Execute_Proc_parameter(string _storename, string[] _arrparameter, string[] _arrvalue)
        //{
        //    System.Data.DataTable _dt = new System.Data.DataTable();
        //    _conn = connect.Connect();
        //    _cmd = new OracleCommand();
        //    _adap = new OracleDataAdapter();

        //    _cmd.Connection = _conn;

        //    _cmd.CommandText = _storename;
        //    _cmd.CommandType = CommandType.StoredProcedure;
        //    _cmd.Parameters.Clear();

        //    for (int i = 0; i <= _arrparameter.Length - 1; i++)
        //    {
        //        //_cmd.Parameters.Add(new OracleParameter("" + _arrparameter[i].ToString() + "", OracleType.VarChar)).Value = _arrvalue[i].ToString();//.add.AddWithValue(_arrparameter[i], _arrvalue[i]);
        //        _cmd.Parameters.AddWithValue(_arrparameter[i], _arrvalue[i]);
        //    }
        //    _cmd.Parameters.Add(new OracleParameter("data",OracleType.Cursor)).Direction = ParameterDirection.Output;

        //    _cmd.ExecuteNonQuery();
        //    _adap.SelectCommand = _cmd;
        //    _adap.Fill(_dt);
        //    connect.Disconnect();
        //    return _dt;
        //}

        //public System.Data.DataTable Execute_Proc_2(string _storename, string _arrparameter, string _arrvalue)
        //{
        //    System.Data.DataTable _dt = new System.Data.DataTable();
        //    _conn = connect.Connect();
        //    _cmd = new OracleCommand();
        //    _adap = new OracleDataAdapter();

        //    _cmd.Connection = _conn;

        //    _cmd.CommandText = _storename;
        //    _cmd.CommandType = CommandType.StoredProcedure;
        //    _cmd.Parameters.Clear();

        //    //for (int i = 0; i <= _arrparameter.Length - 1; i++)
        //    //{
           
        //    //    _cmd.Parameters.AddWithValue(_arrparameter[0], _arrvalue[0]);
        //    //}

        //    _cmd.Parameters.AddWithValue(_arrparameter, _arrvalue);

        //    _cmd.Parameters.Add(new OracleParameter("data", OracleType.Cursor)).Direction = ParameterDirection.Output;

        //    _cmd.ExecuteNonQuery();
        //    _adap.SelectCommand = _cmd;
        //    _adap.Fill(_dt);
        //    connect.Disconnect();
        //    return _dt;
        //}

    

       

        ////ham tra ve 1 bang dung storeprocedure
        //public System.Data.DataTable Excute_Proc(string _Store_name)
        //{

        //    System.Data.DataTable _dt = new System.Data.DataTable();
        //    _conn = connect.Connect();
        //    _cmd = new OracleCommand();
        //    _adap = new OracleDataAdapter();

        //    //khai bao thuoc tinh
        //    _cmd.Connection = _conn;
        //    _cmd.CommandText = _Store_name;
        //    _cmd.CommandType = CommandType.StoredProcedure;
        //    _cmd.Parameters.Add(new OracleParameter("data", OracleType.Cursor)).Direction = ParameterDirection.Output;
        //    _cmd.ExecuteNonQuery();
        //    _adap.SelectCommand = _cmd;
        //    _adap.Fill(_dt); // do ket qua tu cau lenh sql vao table
        //    connect.Disconnect();
        //    return _dt;

        //}

        //public int checkExisted(string _storename, string[] _arrparameter, string[] _arrvalue)
        //{

        //    // System.Data.DataTable dt = new System.Data.DataTable();

        //    int kq = 0;
           
        //    _conn = connect.Connect();
        //    _cmd = new OracleCommand();
        //    _cmd.Connection = _conn;

        //    _cmd.CommandText = _storename;
        //    _cmd.CommandType = CommandType.StoredProcedure;
        //    for (int i = 0; i <= _arrparameter.Length - 1; i++)
        //    {
        //        _cmd.Parameters.AddWithValue(_arrparameter[i], _arrvalue[i]);
        //    }
        //    _cmd.Parameters.Add(new OracleParameter("kq", OracleType.Number)).Direction = ParameterDirection.Output;
        //    _cmd.ExecuteNonQuery();
        //    kq = Convert.ToInt16(_cmd.Parameters["kq"].Value);


        //    connect.Disconnect();
        //    return kq;

        //}



        ////ghi log chuong trinh
        //public void Execute_ProcHis(string _Store_name, string msnv, string ipmachine, string details)
        //{

        //    _conn = connect.Connect();

        //    _cmd = new OracleCommand();
        //    _adap = new OracleDataAdapter();
        //    _cmd.Connection = _conn;
        //    _cmd.CommandText = _Store_name;
        //    _cmd.CommandType = CommandType.StoredProcedure;

        //    _cmd.Parameters.Add(new OracleParameter("MSNV", OracleType.VarChar)).Value = msnv;
        //    _cmd.Parameters.Add(new OracleParameter("IP", OracleType.VarChar)).Value = ipmachine;
        //    _cmd.Parameters.Add(new OracleParameter("NOIDUNG", OracleType.VarChar)).Value = details;

        //    _cmd.ExecuteNonQuery();

        //    connect.Disconnect();

        //}
   
    }
