﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_m_buhin
{
    public partial class frm_m_buhin : Form
    {
        public frm_m_buhin()
        {
            InitializeComponent();
        }
        DataProvider _cn = new DataProvider();
        DataSet _ds = new DataSet();
        DataTable _dt_data = new DataTable();

        DataSet _ds_kho = new DataSet();
        DataSet _ds_loaihh = new DataSet();
        DataSet _ds_dvt = new DataSet();
        DataSet _ds_ncc = new DataSet();

        string _const_type_kho = "01";
        string _const_type_loaihh = "02";
        string _const_type_dvt = "03";
        int _flagupdate = 0;
        string _msnv = string.Empty;

        private void FormatGrid()
        {
            dgv_Data.EnableHeadersVisualStyles = false;
            dgv_Data.Font = new Font("Times New Roman", 10, FontStyle.Regular);
            dgv_Data.EnableHeadersVisualStyles = false;
            dgv_Data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv_Data.ColumnHeadersHeight = 45;
            dgv_Data.BorderStyle = BorderStyle.Fixed3D;
            DataGridViewCellStyle styleHeader = new DataGridViewCellStyle();

            styleHeader.Font = new Font("Times New Roman", 10, FontStyle.Bold);
            styleHeader.ForeColor = Color.Blue;
            styleHeader.Alignment = DataGridViewContentAlignment.MiddleCenter;

            for (int i = 0; i < dgv_Data.Columns.Count; i++)
            {
                dgv_Data.Columns[i].HeaderCell.Style = styleHeader;
                // dgv_Data.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

        }

        private void createGrid()
        {

            dgv_Data.Rows.Clear();
            dgv_Data.Columns.Clear();
            dgv_Data.DataSource = null;

            DataGridViewCheckBoxColumn colCheck = new DataGridViewCheckBoxColumn();
            colCheck.Name = "check";
            dgv_Data.Columns.Add(colCheck);
            dgv_Data.Columns[0].HeaderText = "Check";
            dgv_Data.Columns[0].Width = 48;
            //c_item_kho, c_item_loaihh, c_mahh, c_tenhh, c_dvt, c_mancc, c_tenncc, c_note, c_msnv, d_date
            //c_type_kho, c_ma1, c_type_loaihh, c_ma2 
            dgv_Data.Columns.Add("c_item_kho", "Kho");
            dgv_Data.Columns[1].Width = 50;
            dgv_Data.Columns[1].ReadOnly = true;
            dgv_Data.Columns[1].DataPropertyName = "c_item_kho";
            dgv_Data.Columns[1].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_item_loaihh", "Loại hàng hóa");
            dgv_Data.Columns[2].Width = 130;
            dgv_Data.Columns[2].ReadOnly = true;
            dgv_Data.Columns[2].DataPropertyName = "c_item_loaihh";
            dgv_Data.Columns[2].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_mahh", "MãHH");
            dgv_Data.Columns[3].Width = 85;
            dgv_Data.Columns[3].ReadOnly = true;
            dgv_Data.Columns[3].DataPropertyName = "c_mahh";
            dgv_Data.Columns[3].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_tenhh", "TênHH");
            dgv_Data.Columns[4].Width = 250;
            dgv_Data.Columns[4].ReadOnly = true;
            dgv_Data.Columns[4].DataPropertyName = "c_tenhh";
            dgv_Data.Columns[4].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_dvt", "ĐVT");
            dgv_Data.Columns[5].Width = 50;
            dgv_Data.Columns[5].ReadOnly = true;
            dgv_Data.Columns[5].DataPropertyName = "c_dvt";
            dgv_Data.Columns[5].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_mancc", "Mã NCC");
            dgv_Data.Columns[6].Width = 85;
            dgv_Data.Columns[6].ReadOnly = true;
            dgv_Data.Columns[6].DataPropertyName = "c_mancc";
            dgv_Data.Columns[6].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_tenncc", "Tên NCC");
            dgv_Data.Columns[7].Width = 150;
            dgv_Data.Columns[7].ReadOnly = true;
            dgv_Data.Columns[7].DataPropertyName = "c_tenncc";
            dgv_Data.Columns[7].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_note", "Ghi chú");
            dgv_Data.Columns[8].Width = 160;
            dgv_Data.Columns[8].ReadOnly = true;
            dgv_Data.Columns[8].DataPropertyName = "c_note";
            dgv_Data.Columns[8].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_msnv", "Người nhập");
            dgv_Data.Columns[9].Width = 100;
            dgv_Data.Columns[9].ReadOnly = true;
            dgv_Data.Columns[9].DataPropertyName = "c_msnv";
            dgv_Data.Columns[9].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("d_date", "Ngày nhập");
            dgv_Data.Columns[10].Width = 160;
            dgv_Data.Columns[10].ReadOnly = true;
            dgv_Data.Columns[10].DataPropertyName = "d_date";
            dgv_Data.Columns[10].DefaultCellStyle.BackColor = Color.LightGray;


            dgv_Data.Columns.Add("c_type_kho", "c_type_kho");
            dgv_Data.Columns[11].Width = 50;
            dgv_Data.Columns[11].ReadOnly = true;
            dgv_Data.Columns[11].DataPropertyName = "c_type_kho";
            dgv_Data.Columns[11].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[11].Visible = false;

            dgv_Data.Columns.Add("c_ma1", "c_ma1");
            dgv_Data.Columns[12].Width = 50;
            dgv_Data.Columns[12].ReadOnly = true;
            dgv_Data.Columns[12].DataPropertyName = "c_ma1";
            dgv_Data.Columns[12].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[12].Visible = false;


            dgv_Data.Columns.Add("c_type_loaihh", "c_type_loaihh");
            dgv_Data.Columns[13].Width = 50;
            dgv_Data.Columns[13].ReadOnly = true;
            dgv_Data.Columns[13].DataPropertyName = "c_type_loaihh";
            dgv_Data.Columns[13].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[13].Visible = false;

            dgv_Data.Columns.Add("c_ma2", "c_ma2");
            dgv_Data.Columns[14].Width = 50;
            dgv_Data.Columns[14].ReadOnly = true;
            dgv_Data.Columns[14].DataPropertyName = "c_ma2";
            dgv_Data.Columns[14].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[14].Visible = false;


            dgv_Data.Columns.Add("c_loai_ma", "c_loai_ma");
            dgv_Data.Columns[15].Width = 50;
            dgv_Data.Columns[15].ReadOnly = true;
            dgv_Data.Columns[15].DataPropertyName = "c_loai_ma";
            dgv_Data.Columns[15].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[15].Visible = false;

            dgv_Data.Columns.Add("c_loaihh_ma", "c_loaihh_ma");
            dgv_Data.Columns[16].Width = 50;
            dgv_Data.Columns[16].ReadOnly = true;
            dgv_Data.Columns[16].DataPropertyName = "c_loaihh_ma";
            dgv_Data.Columns[16].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[16].Visible = false;

            FormatGrid();

        }


        private void Combobox_Kho_TK()
        {
            //cmb_kho_TK
            string _sql = string.Empty;
            //        SELECT distinct c_type_kho || ':' || m2.c_item c_kho,c_type_kho,  c_ma1 
            //FROM m_hanghoa m1  left join m_common m2
            // on m1.c_type_kho = m2.c_type and m1.c_ma1 = m2.c_ma ORDER BY c_kho
            _sql = "    SELECT distinct c_type_kho || ':' || m2.c_item c_kho, c_type_kho|| ':' ||c_ma1 c_kho_ma, c_type_kho,  c_ma1 "
                + " FROM m_hanghoa m1  left join m_common m2 "
              + " on m1.c_type_kho = m2.c_type and m1.c_ma1 = m2.c_ma   "
              + " ORDER BY c_kho ";

            DataSet _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds.Tables[0].NewRow();
                _ds.Tables[0].Rows.InsertAt(row, 0);
                cmb_kho_TK.DataSource = _ds.Tables[0];
                cmb_kho_TK.DisplayMember = "c_kho";
                cmb_kho_TK.ValueMember = "c_kho_ma";
            }
        }

        private void Combobox_LoaiHH_TK()
        {
            string _sql = string.Empty;
            //distinct c_type_loaihh || ':' || m2.c_item c_item_loaihh, c_type_loaihh  || ':' || c_ma2 c_loai_ma,  c_type_loaihh, c_ma2 
            //FROM m_hanghoa m1  left join m_common m2
            //on m1.c_type_loaihh = m2.c_type and m1.c_ma2 = m2.c_ma
            //ORDER BY c_item_loaihh

            _sql = "    SELECT distinct c_type_loaihh || ':' || m2.c_item c_item_loaihh, c_type_loaihh  || ':' || c_ma2 c_loai_ma,  c_type_loaihh, c_ma2 "
                + " FROM m_hanghoa m1  left join m_common m2 "
              + " on m1.c_type_loaihh = m2.c_type and m1.c_ma2 = m2.c_ma    "
              + " ORDER BY c_item_loaihh";

            DataSet _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds.Tables[0].NewRow();
                _ds.Tables[0].Rows.InsertAt(row, 0);
                cmb_loaihh_TK.DataSource = _ds.Tables[0];
                cmb_loaihh_TK.DisplayMember = "c_item_loaihh";
                cmb_loaihh_TK.ValueMember = "c_loai_ma";
            }

        }

        private void Combobox_MaHH_TK()
        {
            string _sql = string.Empty;
            //      SELECT distinct  c_mahh
            //FROM m_hanghoa order by c_mahh
            _sql = "   SELECT distinct  c_mahh "
                + "FROM m_hanghoa order by c_mahh ";

            DataSet _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds.Tables[0].NewRow();
                _ds.Tables[0].Rows.InsertAt(row, 0);
                cmb_mahh_TK.DataSource = _ds.Tables[0];
                cmb_mahh_TK.DisplayMember = "c_mahh";
                cmb_mahh_TK.ValueMember = "c_mahh";
            }

        }

        private void Combobox_TenHH_TK()
        {
            string _mahh = string.Empty;

            if (cmb_mahh_TK.Text != "")
            {
                _mahh = cmb_mahh_TK.SelectedValue.ToString();
            }
            else
            {
                _mahh = cmb_mahh_TK.Text;
            }

            string _sql = string.Empty;
            _sql = string.Empty;
            _sql = "SELECT distinct c_tenhh,  c_mahh  FROM m_hanghoa   where 1=1 and ";
            _sql = _sql + "c_mahh like '" + _mahh + "%' ";
            _sql = _sql + "order by c_tenhh ";

            DataSet ds1 = new DataSet();
            ds1 = _cn.Get_ds_CommandSQL(_sql);
            if (ds1.Tables[0].Rows.Count > 0)
            {

                DataRow row = ds1.Tables[0].NewRow();
                ds1.Tables[0].Rows.InsertAt(row, 0);
                cmb_tenhh_TK.DataSource = ds1.Tables[0];
                cmb_tenhh_TK.DisplayMember = "c_tenhh";
                cmb_tenhh_TK.ValueMember = "c_mahh";
            }


        }


        private void Combobox_NCC_TK()
        {
            string _sql = string.Empty;
            //      SELECT distinct  c_mahh
            //FROM m_hanghoa order by c_mahh
            _sql = "   SELECT distinct  c_mancc, c_tenncc "
                + "FROM m_ncc order by c_tenncc ";

            DataSet _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds.Tables[0].NewRow();
                _ds.Tables[0].Rows.InsertAt(row, 0);
                cmb_ncc_TK.DataSource = _ds.Tables[0];
                cmb_ncc_TK.DisplayMember = "c_tenncc";
                cmb_ncc_TK.ValueMember = "c_mancc";
            }

        }
        private void cmb_mahh_TK_SelectedIndexChanged(object sender, EventArgs e)
        {
            Combobox_TenHH_TK();
        }

        private void Loadcombox_TK()
        {
            Combobox_Kho_TK();
            Combobox_LoaiHH_TK();
            Combobox_MaHH_TK();
            Combobox_TenHH_TK();
            Combobox_NCC_TK();

        }


        private void Loaddata()
        {
            //SELECT m2.c_item c_item_kho,m3.c_item c_item_loaihh,  c_mahh, c_tenhh, c_dvt, m4.c_mancc c_mancc,
            //m4.c_tenncc c_tenncc, c_note,
            //TO_char(m1.d_date, 'YYYY/MM/DD HH24:MI:ss') d_date,
            //c_type_kho, c_ma1, c_type_loaihh, c_ma2,m1.c_msnv
            //    FROM m_hanghoa m1  left join m_common m2
            //    on m1.c_type_kho = m2.c_type and m1.c_ma1 = m2.c_ma
            //    left join m_common m3
            //    on m1.c_type_loaihh = m3.c_type and m1.c_ma2 = m3.c_ma
            //    left join m_ncc m4 on 	m1.c_mancc = m4.c_mancc
            //    order by c_mahh, m2.c_item,m3.c_item
            //    ;
            //c_item_kho, c_item_loaihh, c_mahh, c_tenhh, c_dvt, c_mancc, c_tenncc, c_note, c_msnv, d_date
            //c_type_kho, c_ma1, c_type_loaihh, c_ma2 
            string _sql = string.Empty;
            _sql = "SELECT m2.c_item c_item_kho,m3.c_item c_item_loaihh,  c_mahh, c_tenhh, c_dvt, m4.c_mancc c_mancc, "
                    + "  m4.c_tenncc c_tenncc, c_note, "
                    + " m1.c_msnv  c_msnv, TO_char(m1.d_date, 'YYYY/MM/DD HH24:MI:ss') d_date ,"
                     + " c_type_kho, c_ma1, c_type_loaihh, c_ma2 "
                    + "  FROM m_hanghoa m1  left join m_common m2 "
                    + "  on m1.c_type_kho = m2.c_type and m1.c_ma1 = m2.c_ma "
                    + "  left join m_common m3 "
                    + "   on m1.c_type_loaihh = m3.c_type and m1.c_ma2 = m3.c_ma "
                    + "    left join m_ncc m4 on 	m1.c_mancc = m4.c_mancc "
                 + " order by c_mahh, m2.c_item,m3.c_item ";
            _ds = new DataSet();

            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                _dt_data = _ds.Tables[0];

            }
            else
            {
                _dt_data = _ds.Tables[0];
            }

        }
      

        private void Loadcombox()
        {
            //cmb_kho
            string _sql = string.Empty;
            _sql = " SELECT distinct c_item, c_type || ':' || c_ma as c_kho, c_ma, c_type FROM m_common "
              + " where c_type =   '" + _const_type_kho + "'  "
              + "ORDER BY c_item ";


            _ds_kho = _cn.Get_ds_CommandSQL(_sql);
            if (_ds_kho.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds_kho.Tables[0].NewRow();
                _ds_kho.Tables[0].Rows.InsertAt(row, 0);
                cmb_kho.DataSource = _ds_kho.Tables[0];
                cmb_kho.DisplayMember = "c_item";
                cmb_kho.ValueMember = "c_kho";
            }

            //cmb_loaihh
            _sql = string.Empty;
            _sql = " SELECT distinct c_item, c_type || ':' || c_ma as c_loaihh, c_ma, c_type FROM m_common "
              + " where c_type =   '" + _const_type_loaihh + "'  "
              + "ORDER BY c_item ";

      
            _ds_loaihh = _cn.Get_ds_CommandSQL(_sql);
            if (_ds_loaihh.Tables[0].Rows.Count > 0)
            {

                DataRow row = _ds_loaihh.Tables[0].NewRow();
                _ds_loaihh.Tables[0].Rows.InsertAt(row, 0);
                cmb_loaihh.DataSource = _ds_loaihh.Tables[0];
                cmb_loaihh.DisplayMember = "c_item";
                cmb_loaihh.ValueMember = "c_loaihh";
            }

            //cmb_dvt
            _sql = string.Empty;
            _sql = " SELECT distinct c_item, c_type || ':' || c_ma as c_dvt, c_ma, c_type FROM m_common "
              + " where c_type =   '" + _const_type_dvt + "'  "
              + "ORDER BY c_item ";

         //   DataSet _ds3 = new DataSet();
            _ds_dvt = _cn.Get_ds_CommandSQL(_sql);
            if (_ds_dvt.Tables[0].Rows.Count > 0)
            {

                DataRow row = _ds_dvt.Tables[0].NewRow();
                _ds_dvt.Tables[0].Rows.InsertAt(row, 0);
                cmb_dvt.DataSource = _ds_dvt.Tables[0];
                cmb_dvt.DisplayMember = "c_item";
                cmb_dvt.ValueMember = "c_dvt";
            }

            //cmb_ncc
            _sql = string.Empty;
            _sql = "  SELECT  c_tenncc, c_mancc FROM m_ncc "
              + " order by c_tenncc  ";

      //      DataSet _ds4 = new DataSet();
            _ds_ncc = _cn.Get_ds_CommandSQL(_sql);
            if (_ds_ncc.Tables[0].Rows.Count > 0)
            {

                DataRow row = _ds_ncc.Tables[0].NewRow();
                _ds_ncc.Tables[0].Rows.InsertAt(row, 0);
                cmb_ncc.DataSource = _ds_ncc.Tables[0];
                cmb_ncc.DisplayMember = "c_tenncc";
                cmb_ncc.ValueMember = "c_mancc";
            }
        }

        private void frm_m_buhin_Load(object sender, EventArgs e)
        {
            createGrid();
            Loadcombox();
            Loadcombox_TK();
            Loaddata();
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TimKiem()
        {
            string _kho = string.Empty;
            string _loaihh = string.Empty;
            string _mahh = string.Empty;
            string _tenhh = string.Empty;
            string _mancc = string.Empty;
            string _sql = string.Empty;
            if (cmb_kho_TK.Text != "")
            {
                _kho = cmb_kho_TK.SelectedValue.ToString();
            }
            else
            {
                _kho = cmb_kho_TK.Text;
            }

            if (cmb_loaihh_TK.Text != "")
            {
                _loaihh = cmb_loaihh_TK.SelectedValue.ToString();
            }
            else
            {
                _loaihh = cmb_loaihh_TK.Text;
            }


            if (cmb_mahh_TK.Text != "")
            {
                _mahh = cmb_mahh_TK.SelectedValue.ToString();
            }
            else
            {
                _mahh = cmb_mahh_TK.Text;
            }

            if (cmb_tenhh_TK.Text != "")
            {
                _tenhh = cmb_tenhh_TK.Text;
            }
            else
            {
                _tenhh = cmb_tenhh_TK.Text;
            }

            if (cmb_ncc_TK.Text != "")
            {
                _mancc = cmb_ncc_TK.SelectedValue.ToString();
            }
            else
            {
                _mancc = cmb_ncc_TK.Text;
            }
            _sql = "SELECT m2.c_item c_item_kho, m3.c_item c_item_loaihh,  c_mahh, c_tenhh, c_dvt, m4.c_mancc c_mancc, "
                  + "  m4.c_tenncc c_tenncc, c_note, "
                  + " m1.c_msnv  c_msnv, TO_char(m1.d_date, 'YYYY/MM/DD HH24:MI:ss') d_date ,"
                   + " c_type_kho, c_ma1, c_type_loaihh, c_ma2 , c_type_kho || ':' || c_ma1  c_loai_ma,  "
                   +"   c_type_loaihh || ':' || c_ma2  c_loaihh_ma "
                  + "  FROM m_hanghoa m1  left join m_common m2 "
                  + "  on m1.c_type_kho = m2.c_type and m1.c_ma1 = m2.c_ma "
                  + "  left join m_common m3 "
                  + "   on m1.c_type_loaihh = m3.c_type and m1.c_ma2 = m3.c_ma "
                  + "    left join m_ncc m4 on 	m1.c_mancc = m4.c_mancc "
                + " where c_type_kho || ':' || c_ma1  like '%" + _kho + "%' "
                + " and c_type_loaihh || ':' || c_ma2 like '%" + _loaihh + "%' "
                   + " and m1.c_mahh like '%" + _mahh + "%' "
                     + " and m1.c_tenhh like '%" + _tenhh + "%' "
                             + " and m1.c_mancc like '%" + _mancc + "%' "
                + " order by c_mahh, m2.c_item,m3.c_item ";

            _ds = _cn.Get_ds_CommandSQL(_sql);

            if (_ds.Tables[0].Rows.Count > 0)
            {
                dgv_Data.AutoGenerateColumns = false;
                dgv_Data.DataSource = _ds.Tables[0];
                txt_sodong.Text = _ds.Tables[0].Rows.Count.ToString();

            }
            else
            {
                MessageBox.Show("Không có dữ liệu.!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dgv_Data.DataSource = _ds.Tables[0];
                return;
            }

        }
        private void btn_Search_Click(object sender, EventArgs e)
        {
            TimKiem();
        }


        private void ClearInput()
        {
            cmb_kho_TK.SelectedIndex = -1;
            cmb_loaihh_TK.SelectedIndex = -1;
            cmb_ncc_TK.SelectedIndex = -1;
            cmb_mahh_TK.SelectedIndex = -1;
            cmb_tenhh_TK.SelectedIndex = -1;

            cmb_kho.SelectedIndex = -1;
            cmb_loaihh.SelectedIndex = -1;
            cmb_dvt.SelectedIndex = -1;
            cmb_ncc.SelectedIndex = -1;
            txt_tenhh.Text = string.Empty;
            txt_mahh.Text = string.Empty;
            txt_ghichu.Text = string.Empty;
            txt_sodong.Text = string.Empty;
            dgv_Data.DataSource = null;

        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            ClearInput();
        }


        private static void ExportExcel(System.Data.DataTable _dtT)
        {
            SaveFileDialog sFD = new SaveFileDialog();
            sFD.FileName = "";
            sFD.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";

            sFD.ShowDialog();
            if (sFD.FileName == "")
                return;
            System.IO.File.Copy(System.Windows.Forms.Application.StartupPath + "\\Export_excel.xlsx", sFD.FileName, true);
            Excel.Application _app = new Excel.Application();
            Excel.Workbook _wb = _app.Workbooks.Open(sFD.FileName, 0, false, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true);


            Excel.Sheets sheets = _wb.Worksheets;
            Excel.Worksheet _ws = (Excel.Worksheet)sheets.get_Item(1);
            object[,] arr = new object[_dtT.Rows.Count + 1, _dtT.Columns.Count];
            string[] _arrHeader = { "MSNV"
                                                , "Ho ten"
                                                                                                                        
                                                };
            //lay ten cua cot
            for (int i = 0; i < _arrHeader.Length; i++)
            {
                arr[0, i] = _arrHeader.GetValue(i);
                Excel.Range rng_tieude = (Excel.Range)_ws.Cells[1, i + 1];
                rng_tieude.Font.Bold = true;
                rng_tieude.Font.Size = 12;
            }
            //do du lieu 
            for (int r = 0; r < _dtT.Rows.Count; r++)
            {
                DataRow dr = _dtT.Rows[r];
                for (int c = 0; c < _dtT.Columns.Count; c++)
                {
                    arr[r + 1, c] = dr[c];
                    if (c == 2)
                    {
                        Excel.Range rng_data = (Excel.Range)_app.Cells[r + 1, 2];
                        rng_data.EntireColumn.NumberFormat = "@";
                    }

                }
            }

            Excel.Range c1 = (Excel.Range)_ws.Cells[1, 1];
            Excel.Range c2 = (Excel.Range)_ws.Cells[1 + _dtT.Rows.Count - 1 + 1, _dtT.Columns.Count];

            Excel.Range range = _ws.get_Range(c1, c2);
            range.Value = arr;
            _app.Columns.AutoFit();
            _app.DisplayAlerts = false;
            _wb.Close(true, Missing.Value, Missing.Value);
            _app.Quit();
            releaseObject(_ws);
            releaseObject(_wb);
            releaseObject(_app);
            _ws = null;
            _wb = null;
            _app = null;
        }


        public System.Data.DataTable _MyReadExcel(string sUploadFilePath, int sheet)
        {
            //oXL, oWB, oSheet, sheets
            Excel.Workbook oWB = null;
            Excel.Worksheet oSheet = null;
            Excel.Range oRng = null;
            Excel.Range oRng1 = null;
            Excel.Range oRng2 = null;

            Excel.Range oRng3= null;
            Excel.Range oRng4 = null;
            Excel.Range oRng5 = null;
       

            try
            {
                //Create a Application object       
                Excel.Application oXL = new Excel.Application();

                try
                {
                    oWB = oXL.Workbooks.Open(sUploadFilePath, 0, false, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true);
                }
                catch
                {
                    MessageBox.Show("Không mở được file này");
                }
                //Getting WorkSheet object   
                Excel.Sheets sheets = oWB.Worksheets;
                oSheet = (Excel.Worksheet)sheets.get_Item(1);
                System.Data.DataTable dt = new System.Data.DataTable("dtExcel");
                DataSet ds = new DataSet();
                ds.Tables.Add(dt);
                DataRow dr;
                StringBuilder sb = new StringBuilder();
                int jValue = oSheet.UsedRange.Cells.Columns.Count;
                int iValue = oSheet.UsedRange.Cells.Rows.Count;
                //Getting Data Columns             
                if (jValue > 7)
                {
                    return dt;
                }
                for (int j = 1; j <= jValue; j++)
                {

                    dt.Columns.Add("column" + j, System.Type.GetType("System.String"));

                }
                //Getting Data in Cell
                try
                {
                    //lay dl tu dong so 2, cot 1
                    for (int i = 2; i <= iValue; i++)
                    {
                        dr = ds.Tables["dtExcel"].NewRow();
                       
                        string t1 = string.Empty;
                        string t2 = string.Empty;
                        string t3 = string.Empty;
                        string t4 = string.Empty;
                        string t5 = string.Empty;
                        for (int j = 1; j <= jValue; j++)
                        {

                            oRng = (Excel.Range)oSheet.Cells[i, j];
                            string strValue = oRng.Text.ToString();
                            if (strValue != string.Empty || strValue != "")
                            {
                                oRng1 = (Excel.Range)oSheet.Cells[i, 1];
                                t1 = oRng1.Text.ToString();

                                oRng2 = (Excel.Range)oSheet.Cells[i, 2];
                                t2 = oRng2.Text.ToString();

                                oRng3 = (Excel.Range)oSheet.Cells[i, 3];
                                t3 = oRng3.Text.ToString();

                                oRng4 = (Excel.Range)oSheet.Cells[i, 4];
                                t4 = oRng4.Text.ToString();

                                oRng5 = (Excel.Range)oSheet.Cells[i, 5];
                                t5 = oRng5.Text.ToString();

                                dr["column" + j] = strValue;

                            }

                        }

                        if (t1 != "" || t1 != string.Empty && t2 != "" || t2 != string.Empty && t2 != "" || t3 != string.Empty && t4 != "" || t4 != string.Empty && t5 != "" || t5 != string.Empty)
                        {
                            ds.Tables["dtExcel"].Rows.Add(dr);
                            dt = ds.Tables[0];
                        }

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

                oWB.Close(false, System.Reflection.Missing.Value, System.Reflection.Missing.Value);
                oXL.Workbooks.Close();
                oXL.Quit();

                releaseObject(oSheet);
                releaseObject(sheets);
                releaseObject(oWB);
                releaseObject(oXL);
                oXL = null;
                oWB = null;
                oSheet = null;
                sheets = null;
                oRng = null;
                oRng1 = null;
                oRng2 = null;
                oRng3 = null;
                oRng4 = null;
                oRng5 = null;

                //kill excel
                foreach (System.Diagnostics.Process proc in System.Diagnostics.Process.GetProcessesByName("EXCEL"))
                {
                    if (proc.MainWindowTitle.ToString() == "")
                    {
                        proc.Kill();
                    }

                }

                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                return null;
                throw ex;
            }
            finally
            {

            }
        }


        private static void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }
        private void btn_Excel_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv_Data.RowCount <= 0)
                {
                    MessageBox.Show("Không có dữ liệu để xuất Excel.!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    System.Data.DataTable _dtExcel = new System.Data.DataTable();
                    _dtExcel = (DataTable)dgv_Data.DataSource;
                    //_dtExcel.Columns.Remove("d_date");
                    //_dtExcel.AcceptChanges();
                    if (MessageBox.Show("Bạn Có Muốn Xuất Ra Excel Không ???", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        this.Cursor = Cursors.WaitCursor;
                        ExportExcel(_dtExcel);
                        this.Cursor = Cursors.Default;
                        MessageBox.Show("Xuất Excel thành công.!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //  c_type_kho, c_ma1, c_type_loaihh, c_ma2 , c_type_kho || ':' || c_ma1  c_loai_ma,   c_type_loaihh || ':' || c_ma2  c_loaihh_ma
        string _c_loai_ma_B = string.Empty;   
        string _c_ma1_B = string.Empty;
 
        string _c_loaihh_ma_B = string.Empty; 
        string _c_ma2_B = string.Empty;
 
        string _c_item_B = string.Empty;
        string _c_ghichu_B = string.Empty;

        string _c_mahh_B = string.Empty;
        string _c_tenhh_B = string.Empty;

        string _c_mancc_B = string.Empty;
        string _c_dvt_B = string.Empty;

        private void dgv_Data_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && e.ColumnIndex != -1)
            {
                _flagupdate = 1;
                  // _sql = "SELECT m2.c_item c_item_kho,m3.c_item c_item_loaihh,  c_mahh, c_tenhh, c_dvt, m4.c_mancc c_mancc, "
                  //+ "  m4.c_tenncc c_tenncc, c_note, "
                  //+ " m1.c_msnv  c_msnv, TO_char(m1.d_date, 'YYYY/MM/DD HH24:MI:ss') d_date ,"
                  // + " c_type_kho, c_ma1, c_type_loaihh, c_ma2 , c_type_kho || ':' || c_ma1  c_loai_ma,  
                //c_type_loaihh || ':' || c_ma2  c_loaihh_ma"

                if (dgv_Data.Rows[e.RowIndex].Cells["c_loai_ma"].Value.ToString() != string.Empty)
                {
                    cmb_kho.Text = dgv_Data.Rows[e.RowIndex].Cells["c_item_kho"].Value.ToString();

                    _c_loai_ma_B = dgv_Data.Rows[e.RowIndex].Cells["c_loai_ma"].Value.ToString();
                    string[] _loai = _c_loai_ma_B.Split(':');
                    if (_loai.Length > 0 || _loai[0].ToString() != string.Empty || _loai[1].ToString() != string.Empty)
                    {
                        _c_ma1_B = _loai[1].ToString();
                    }
                  
                }

                if (dgv_Data.Rows[e.RowIndex].Cells["c_loaihh_ma"].Value.ToString() != string.Empty)
                {
                    cmb_loaihh.Text = dgv_Data.Rows[e.RowIndex].Cells["c_item_loaihh"].Value.ToString();

                    _c_loaihh_ma_B = dgv_Data.Rows[e.RowIndex].Cells["c_loaihh_ma"].Value.ToString();

                    string[] _loai = _c_loaihh_ma_B.Split(':');
                    if (_loai.Length > 0 || _loai[0].ToString() != string.Empty || _loai[1].ToString() != string.Empty)
                    {
                        _c_ma2_B = _loai[1].ToString();
                    }
                    
                }

                if (dgv_Data.Rows[e.RowIndex].Cells["c_dvt"].Value.ToString() != string.Empty)
                {
                    cmb_dvt.Text = dgv_Data.Rows[e.RowIndex].Cells["c_dvt"].Value.ToString();
                    _c_dvt_B = dgv_Data.Rows[e.RowIndex].Cells["c_dvt"].Value.ToString();
                }

                if (dgv_Data.Rows[e.RowIndex].Cells["c_mancc"].Value.ToString() != string.Empty)
                {
                    cmb_ncc.Text = dgv_Data.Rows[e.RowIndex].Cells["c_tenncc"].Value.ToString();
                    _c_mancc_B = dgv_Data.Rows[e.RowIndex].Cells["c_mancc"].Value.ToString();

                }

                if (dgv_Data.Rows[e.RowIndex].Cells["c_mahh"].Value != string.Empty)
                {

                    _c_mahh_B = dgv_Data.Rows[e.RowIndex].Cells["c_mahh"].Value.ToString().Trim();
                    txt_mahh.Text = _c_mahh_B;
                }

                if (dgv_Data.Rows[e.RowIndex].Cells["c_tenhh"].Value != string.Empty)
                {

                    _c_tenhh_B = dgv_Data.Rows[e.RowIndex].Cells["c_tenhh"].Value.ToString().Trim();
                    txt_tenhh.Text = _c_tenhh_B;
                }

                if (dgv_Data.Rows[e.RowIndex].Cells["c_note"].Value != string.Empty)
                {

                    _c_ghichu_B = dgv_Data.Rows[e.RowIndex].Cells["c_note"].Value.ToString().Trim();
                    txt_ghichu.Text = _c_ghichu_B;
                }


            }
        }


        private bool CheckdataInput()
        {


            if (cmb_kho.Text == "")
            {
                MessageBox.Show("Chưa chọn " + label4.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }


            if (cmb_loaihh.Text == "")
            {
                MessageBox.Show("Chưa chọn " + label5.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

     
            if (txt_tenhh.Text == "" || txt_tenhh.Text == string.Empty)
            {
                MessageBox.Show("Chưa nhập " + label3.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (cmb_dvt.Text == "")
            {
                MessageBox.Show("Chưa chọn " + label6.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

        
            if (cmb_ncc.Text == "")
            {
                MessageBox.Show("Chưa chọn " + label7.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

        
            return true;
        }
        private void Cleardata_update()
        {
             _c_loai_ma_B = string.Empty;
             _c_ma1_B = string.Empty;

             _c_loaihh_ma_B = string.Empty;
             _c_ma2_B = string.Empty;

             _c_item_B = string.Empty;
             _c_ghichu_B = string.Empty;

             _c_mahh_B = string.Empty;
             _c_tenhh_B = string.Empty;

             _c_mancc_B = string.Empty;
             _c_dvt_B = string.Empty;
        }
        private void btn_Save_Click(object sender, EventArgs e)
        {
            string _kho = string.Empty;
            string _loaihh = string.Empty;
            string _mahh = string.Empty;
            string _tenhh = string.Empty;
            string _mancc = string.Empty;
            string _tenncc = string.Empty;
            string _dvt = string.Empty;
            string _ghichu = string.Empty;

            string c_type_kho = string.Empty;
            string c_ma1 = string.Empty;
            string c_type_loaihh = string.Empty;
            string c_ma2 = string.Empty;
            int _stt = 0;
            int _stt_new = 0;
            string _sql = string.Empty;
            int _dem = 0;
            int _kq = 0;
            int _insert = 0;

            if (CheckdataInput() == true)
            {
                if (cmb_kho.Text != "")
                {
                    _kho = cmb_kho.SelectedValue.ToString();
                    string[] _arr_kho = _kho.Split(':');

                    if (_arr_kho.Length == 2 || _arr_kho.Length > 0)
                    {
                        c_type_kho = _arr_kho[0].ToString();
                        c_ma1 = _arr_kho[1].ToString();
                    }
                }

                if (cmb_loaihh.Text != "")
                {
                    _loaihh = cmb_loaihh.SelectedValue.ToString();
                    string[] _arr_loaihh = _loaihh.Split(':');
                    if (_arr_loaihh.Length == 2 || _arr_loaihh.Length > 0)
                    {
                        c_type_loaihh = _arr_loaihh[0].ToString();
                        c_ma2 = _arr_loaihh[1].ToString();
                    }

                }

                if (txt_tenhh.Text != "")
                {
                    _tenhh = txt_tenhh.Text.Trim();
                    //kiem tra va xu ly cap mahh 
                    DataRow[] dr_tenhh = _dt_data.Select("c_tenhh = '" + _tenhh + "'   ");

                    if (dr_tenhh.Length > 0)
                    {
                     
                        _insert = 1;
                    }
                 
                    _mahh = txt_mahh.Text;
                }

                //_kho, _loaihh, _tenhh, _mahh, _mancc, _tenncc, _ghichu
                if (cmb_dvt.Text != "")
                {
                    _dvt = cmb_dvt.Text;
                }

                if (cmb_ncc.Text != "")
                {
                    _mancc = cmb_ncc.SelectedValue.ToString();
                    _tenncc = cmb_ncc.Text;
                }

                if (txt_ghichu.Text != "")
                {
                    _ghichu = txt_ghichu.Text.Trim().ToUpper();
                }

                if (_flagupdate == 0)
                {
                    if (_insert == 0)
                    {
                        _sql = string.Empty;
                        _sql = "    INSERT INTO m_hanghoa ( c_type_kho, c_ma1, c_type_loaihh, c_ma2, c_mahh, "
                            + " c_tenhh, c_dvt, c_mancc, c_tenncc, c_note, c_msnv, d_date ) "
                            + " values( '" + c_type_kho + "','" + c_ma1 + "', '" + c_type_loaihh + "' ,  '" + c_ma2 + "' ,  '" + _mahh + "', "
                       + "   '" + _tenhh + "',   '" + _dvt + "',   '" + _mancc + "',   '" + _tenncc + "',  '" + _ghichu + "',  '" + _msnv + "', CURRENT_TIMESTAMP ) ";
                        _kq = _cn.Execute_Nonquery(_sql);
                    }
                    if (_insert == 1)
                    {
                        _sql = string.Empty;
                        _sql = "  UPDATE  m_hanghoa set "
                            + "  c_type_kho =  '" + c_type_kho + "', c_ma1 = '" + c_ma1 + "', c_type_loaihh ='" + c_type_loaihh + "' , c_ma2=  '" + c_ma2 + "' "
                            + "  , c_dvt ='" + _dvt + "', c_mancc = '" + _mancc + "', c_tenncc = '" + _tenncc + "', c_note ='" + _ghichu + "', "
                            + " c_msnv ='" + _msnv + "', d_date = CURRENT_TIMESTAMP "
                            + "  where c_mahh = '" + _mahh + "' and c_tenhh  = '" + _tenhh + "' ";
                        _kq = _cn.Execute_Nonquery(_sql);
                    }
                }

                else
                {
                    if (_mahh == _c_mahh_B)
                    {
                        if (_tenhh == _c_tenhh_B)
                        {
                            //update cac cot con lai
                            _sql = string.Empty;
                            _sql = "  UPDATE  m_hanghoa set "
                                + "  c_type_kho =  '" + c_type_kho + "', c_ma1 = '" + c_ma1 + "', c_type_loaihh ='" + c_type_loaihh + "' , c_ma2=  '" + c_ma2 + "' "
                                + "  ,c_dvt ='" + _dvt + "', c_mancc = '" + _mancc + "', c_tenncc = '" + _tenncc + "', c_note ='" + _ghichu + "', "
                                + " c_msnv ='" + _msnv + "', d_date = CURRENT_TIMESTAMP "
                                + "  where c_mahh = '" + _c_mahh_B + "' and c_tenhh  = '" + _c_tenhh_B + "' ";
                            _kq = _cn.Execute_Nonquery(_sql);
                        }
                        else
                        {
                            //update lại tenhh  cot con lai
                           if ( c_ma1 != _c_ma1_B || c_ma2 != _c_ma2_B  || _mancc != _c_mancc_B || _ghichu != _c_ghichu_B ||
                              _dvt != _c_dvt_B || _tenhh != _c_tenhh_B)
                            _sql = string.Empty;
                            _sql = "  UPDATE  m_hanghoa set  c_tenhh  = '" + _tenhh + "',  "
                               + "  c_type_kho =  '" + c_type_kho + "', c_ma1 = '" + c_ma1 + "', c_type_loaihh ='" + c_type_loaihh + "' , c_ma2=  '" + c_ma2 + "' "
                               + " , c_dvt ='" + _dvt + "', c_mancc = '" + _mancc + "', c_tenncc = '" + _tenncc + "', c_note ='" + _ghichu + "', "
                               + " c_msnv ='" + _msnv + "', d_date = CURRENT_TIMESTAMP  "
                               + "  where c_mahh = '" + _mahh + "' ";
                            _kq = _cn.Execute_Nonquery(_sql);
                        }
                        Cleardata_update();

                    }               

                }               
         
                if (_kq == 1)
                {
                    _dem++;
                }

                if (_dem > 0)
                {
                    ClearInput();
                    Loaddata();
                    Loadcombox_TK();
                    Loaddata();
                    _insert = 0;
                    _kq = 0;
                    MessageBox.Show("Lưu dữ liệu thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }



            }

        }

        private void txt_tenhh_KeyPress(object sender, KeyPressEventArgs e)
        {
            string _tenhh = string.Empty;
            string _mahh = string.Empty;
            string _sql = string.Empty;
            int _stt = 0;
            int _stt_new = 0;
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (txt_tenhh.Text != "")
                {
                    _tenhh = cmb_tenhh_TK.Text.Trim();
                    //kiem tra va xu ly cap mahh 
                    DataRow[] dr_tenhh = _dt_data.Select("c_tenhh = '" + _tenhh + "'   ");

                    _sql = "   SELECT max(to_number(c_mahh, '9999999')) FROM m_hanghoa ";
                    DataSet _ds_stt = new DataSet();
                    _ds_stt = _cn.Get_ds_CommandSQL(_sql);
                    if (_ds_stt.Tables[0].Rows[0][0].ToString() != string.Empty) //_ds_stt.Tables[0].Rows.Count > 0 || 
                    {
                        _stt = Convert.ToInt32(_ds_stt.Tables[0].Rows[0][0].ToString());
                    }
                    else
                    {
                        _stt = 0;
                    }

                    if (dr_tenhh.Length > 0)
                    {
                        _mahh = dr_tenhh[0]["c_mahh"].ToString();
                        txt_mahh.Text = _mahh;
                    }
                    else
                    {
                        _stt_new = _stt + 1;
                        _mahh = "HH" + string.Format("{0:00000}", _stt_new);
                        //  _insert = 1;
                        txt_mahh.Text = _mahh;
                    }
                    cmb_dvt.Focus();
                }


            }

        }

        private void DeleteData()
        {
            int _kq = 0;
            int count_kq = 0;
            string _sql = string.Empty;
            string _c_mahh = string.Empty;

            //string _hoten = string.Empty;
            //string _sql = string.Empty;

            if (dgv_Data.Rows.Count > 0)
            {
                int dem = 0;
                for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                {
                    //kiem tra neu co 1 dong dc check thi xoa
                    if (Convert.ToBoolean(dgv_Data.Rows[i].Cells[0].Value) == true)// lay vi tri cua dong dang check
                    {

                        dem++;
                        continue;
                    }

                }
                if (dem == 0)
                {
                    MessageBox.Show("Bạn chưa chọn dòng cần xóa", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (MessageBox.Show("Bạn Có Muốn Xóa Không", "Thông Báo!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                    {
                        if (dgv_Data.Rows[i].Cells["check"].Value != null)
                        {
                            if (dgv_Data.Rows[i].Cells["check"].Value.ToString() == "True" || dgv_Data.Rows[i].Cells["check"].Value.ToString() == "1")
                            {

                                _c_mahh = dgv_Data.Rows[i].Cells["c_mahh"].Value.ToString();
                                _sql = "delete from  m_hanghoa  WHERE c_mahh =  '" + _c_mahh + "'   ";
                                _kq = _cn.Execute_Nonquery(_sql);
                                if (_kq == 1)
                                {
                                    count_kq = count_kq + 1;
                                }

                            }
                        }

                    }
                }

            }

            else
            {
                MessageBox.Show("Không có dữ liệu để xóa", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (count_kq > 0)
            {
                Loadcombox_TK();
                Loadcombox();             
                Loaddata();
                dgv_Data.DataSource = null;
                MessageBox.Show("Đã xóa thành công.", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Xóa dữ liệu bị lỗi.", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btn_Delete_Click(object sender, EventArgs e)
        {
            DeleteData();
        }

        private void dgv_Data_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int _cot = e.ColumnIndex;
            if (dgv_Data.RowCount > 0)
            {
                dgv_Data.CurrentCell = dgv_Data.Rows[0].Cells[1];
                if (_cot == 0)
                {
                    bool kq = dgv_Data.Rows[0].Cells[0].Value == null ? false : Convert.ToBoolean(dgv_Data.Rows[0].Cells[0].Value.ToString());
                    for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                    {
                        dgv_Data.Rows[i].Cells[_cot].Value = !kq;
                    }
                }
            }
        }


        public void Export_Loi(System.Data.DataTable _dt)
        {
            //DataTable _dt;
            try
            {
                if (MessageBox.Show("Import có lỗi, Bạn có muốn xuất lỗi ra excel không???", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    if (_dt.Rows.Count > 0)
                    {
                        try
                        {

                            SaveFileDialog sFD = new SaveFileDialog();
                            sFD.FileName = "";
                            sFD.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                            sFD.ShowDialog();
                            if (sFD.FileName == "")
                                return;

                            System.IO.File.Copy(System.Windows.Forms.Application.StartupPath + "\\Export_excel.xlsx", sFD.FileName, true);
                            Excel.Application _app = new Excel.Application();
                            Excel.Workbook _wb = _app.Workbooks.Open(sFD.FileName, 0, false, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true);
                            Excel.Sheets sheets = _wb.Worksheets;
                            Excel.Worksheet worksheet = (Excel.Worksheet)sheets.get_Item(1);

                            object[,] arr = new object[_dt.Rows.Count + 1, _dt.Columns.Count];

                            string[] _arrHeader = { "MSNV"
                                                                  ,"Họ tên	"
                                                                , "Reason"          
                                                            };
                            //lay ten cua cot
                            for (int i = 0; i <= _arrHeader.Length - 1; i++)
                            {
                                arr[0, i] = _arrHeader.GetValue(i);
                                Excel.Range rng_tieude = (Excel.Range)worksheet.Cells[1, i + 1];
                                //  rng_tieude.Font.b = true;
                                rng_tieude.Font.Size = 11;
                            }

                            //do du lieu 
                            for (int r = 0; r <= _dt.Rows.Count - 1; r++)
                            {
                                DataRow dr = _dt.Rows[r];
                                for (int c = 0; c <= _dt.Columns.Count - 1; c++)
                                {
                                    arr[r + 1, c] = dr[c];

                                }
                            }

                            Excel.Range c1 = (Excel.Range)worksheet.Cells[2, 1];
                            Excel.Range c2 = (Excel.Range)worksheet.Cells[2 + _dt.Rows.Count - 1 + 1, _dt.Columns.Count];

                            Excel.Range range = worksheet.get_Range(c1, c2);
                            range.Value = arr;
                            _app.Columns.AutoFit();
                            _app.DisplayAlerts = false;
                            _wb.Close(true, Missing.Value, Missing.Value);
                            _app.Quit();
                            releaseObject(worksheet);
                            releaseObject(_wb);
                            releaseObject(_app);
                            worksheet = null;
                            _wb = null;
                            _app = null;


                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }

                    else
                    {
                        MessageBox.Show("Không Có Dữ Liệu Xuất Ra Excel", "Thông Báo!!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                return;
            }
        }


        private void btn_Import_Click(object sender, EventArgs e)
        {
            DataTable _dt_import = new DataTable();
            DataTable _dt = new DataTable();
            int _loi = 0;
            int _kq = 0;
            int _dem = 0;
            int _xuatexcel = 0;
            string reason = string.Empty;

            string _kho = string.Empty;
            string c_type_kho = string.Empty;
            string c_ma1 = string.Empty;

            string _loaihh = string.Empty;
            string c_type_loaihh = string.Empty;
            string c_ma2 = string.Empty;

            string _mahh = string.Empty;
            string _tenhh = string.Empty;
            string _mancc = string.Empty;
            string _tenncc = string.Empty;
            string _dvt = string.Empty;
            string _ghichu = string.Empty;
            int _stt = 0;
            int _stt_new = 0;

            string _sql = string.Empty;
            OpenFileDialog _dlg = new OpenFileDialog();
            _dlg.AddExtension = true;
            _dlg.CheckFileExists = true;
            _dlg.Filter = "Excel files|*.xlsx";
            _dlg.Multiselect = false;
            if (_dlg.ShowDialog() == DialogResult.OK)
            {
                F_wait frm = new F_wait();
                frm.Show();
                frm.Refresh();
                _dt = _MyReadExcel(_dlg.FileName, 1);

                if (_dt == null)
                {
                    return;
                }
                if (_dt.Rows.Count == 0)
                {
                    MessageBox.Show("File import khong co du lieu");
                    return;

                }
                if (_dt.Columns.Count > 7)
                {
                    MessageBox.Show("File khong dung dinh dang");
                    return;
                }
                //c_type_kho, c_ma1, c_type_loaihh, c_ma2, c_mahh, 
                _dt.Columns.Add("c_reason");
                _dt.Columns.Add("c_type_kho");
                _dt.Columns.Add("c_ma1");
                _dt.Columns.Add("c_type_loaihh");
                _dt.Columns.Add("c_ma2");
                _dt.Columns.Add("c_mahh");   
                _dt.AcceptChanges();
              
                if (MessageBox.Show("Bạn Có Muốn Lưu dữ liệu không?", "Thông Báo!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    for (int i = 0; i <= _dt.Rows.Count - 1; i++)
                    {
                        if (_dt.Rows[i][0].ToString() == String.Empty || _dt.Rows[i][0].ToString() == "" && _dt.Rows[i][1].ToString() == String.Empty || _dt.Rows[i][1].ToString() == "")
                        {
                            _xuatexcel = -1;                        
                        }
                        else
                        {

                            //0: kho
                            if (_dt.Rows[i][0].ToString() != "" && _dt.Rows[i][0].ToString() != String.Empty)
                            {
                             
                                string[] _kho_arr = _dt.Rows[i][0].ToString().Trim().Split(':');

                                if (_kho_arr.Length > 0 )
                                {
                                    if (_kho_arr[0].ToString() != string.Empty && _kho_arr[1].ToString() != string.Empty)
                                    {
                                        c_type_kho = _kho_arr[0].ToString();

                                        if (_kho_arr[0].ToString() == "01")
                                        {
                                            DataRow[] dr = _ds_kho.Tables[0].Select("c_item = '" + _kho_arr[1].ToString() + "'  ");
                                            if (dr.Length > 0)
                                            {
                                                _kho = _kho_arr[1].ToString();
                                                c_ma1 = dr[0]["c_ma"].ToString();

                                                _dt.Rows[i]["c_type_kho"] = c_type_kho;
                                                _dt.Rows[i]["c_ma1"] = c_ma1;
                                                _dt.AcceptChanges();
                                            }
                                            else
                                            {
                                                _loi++;
                                                reason = "Tên kho không có trong master";
                                                _dt.Rows[i]["c_reason"] = reason;
                                                _dt.AcceptChanges();
                                                _xuatexcel++;
                                            }
                                        }                                  

                                    }
                                    else
                                    {
                                        _loi++;
                                        reason = "Mã kho không có trong master";
                                        _dt.Rows[i]["c_reason"] = reason;
                                        _dt.AcceptChanges();
                                        _xuatexcel++;
                                    }
                               

                                }

                            }
                            else
                            {
                                _loi++;
                                reason = "Kho không được rỗng";
                                _dt.Rows[i]["c_reason"] = reason;
                                _dt.AcceptChanges();
                                _xuatexcel++;
                            }
                    
                            //1: loaihh
                            if (_dt.Rows[i][1].ToString() != "" && _dt.Rows[i][1].ToString() != String.Empty)
                            {

                                string[] _loaihh_arr = _dt.Rows[i][1].ToString().Trim().Split(':');

                                if (_loaihh_arr.Length > 0 )
                                {
                                    if (_loaihh_arr[0].ToString() != string.Empty && _loaihh_arr[1].ToString() != string.Empty)
                                    {
                                        c_type_loaihh = _loaihh_arr[0].ToString();

                                        if (_loaihh_arr[0].ToString() == "02")
                                        {
                                            DataRow[] dr = _ds_loaihh.Tables[0].Select("c_item = '" + _loaihh_arr[1].ToString() + "'  ");
                                            if (dr.Length > 0)
                                            {
                                                _loaihh = _loaihh_arr[1].ToString();
                                                c_ma2 = dr[0]["c_ma"].ToString();

                                                _dt.Rows[i]["c_type_loaihh"] = c_type_loaihh;
                                                _dt.Rows[i]["c_ma2"] = c_ma2;
                                                _dt.AcceptChanges();
                                            }
                                            else
                                            {
                                                _loi++;
                                                reason = "Tên loại hàng hóa không có trong master";
                                                _dt.Rows[i]["c_reason"] = reason;
                                                _dt.AcceptChanges();
                                                _xuatexcel++;
                                            }

                                        }
                                        else
                                        {
                                            _loi++;
                                            reason = "Mã loại hàng hóa không có trong master";
                                            _dt.Rows[i]["c_reason"] = reason;
                                            _dt.AcceptChanges();
                                            _xuatexcel++;
                                        }

                                    }


                                }

                            }
                            else
                            {
                                _loi++;
                                reason = "Loại hàng hóa không được rỗng";
                                _dt.Rows[i]["c_reason"] = reason;
                                _dt.AcceptChanges();
                                _xuatexcel++;
                            }

                            //2:  tênhh
                            if (_dt.Rows[i][2].ToString() != "" && _dt.Rows[i][2].ToString() != String.Empty)
                            {
                                //kiem tra tenhh có trong master ko
                         
                                DataRow[] dr = _dt_data.Select("c_tenhh = '" + _dt.Rows[i][2].ToString().Trim() + "' ");
                                if (dr.Length > 0)
                                {
                                    //neu tenhh có rồi thì lấy dc mahh
                                    _mahh = dr[0]["c_mahh"].ToString();
                                 
                                    _dt.Rows[i]["c_mahh"] = _mahh;                                 
                                    _dt.AcceptChanges();

                                }
                                else
                                {
                                    //neu chua thi cap mã mới                                  
                                    _sql = "   SELECT max(to_number(c_mahh, '9999999')) FROM m_hanghoa ";
                                    DataSet _ds_stt = new DataSet();
                                    _ds_stt = _cn.Get_ds_CommandSQL(_sql);
                                    if (_ds_stt.Tables[0].Rows[0][0].ToString() != string.Empty) //_ds_stt.Tables[0].Rows.Count > 0 || 
                                    {
                                        _stt = Convert.ToInt32(_ds_stt.Tables[0].Rows[0][0].ToString());
                                    }
                                    else
                                    {
                                        _stt = 0;
                                    }
                                    _stt_new = _stt + 1;
                                    _mahh = "HH" + string.Format("{0:00000}", _stt_new);

                                    _dt.Rows[i]["c_mahh"] = _mahh;
                                    _dt.AcceptChanges();
                                }
                                _tenhh = _dt.Rows[i][2].ToString().Trim();
                            }


                            //3:  dvt
                            if (_dt.Rows[i][3].ToString() != "" && _dt.Rows[i][3].ToString() != String.Empty)
                            {
                                DataRow[] dr = _ds_dvt.Tables[0].Select("c_item = '" + _dt.Rows[i][3].ToString().Trim() + "' ");
                                if (dr.Length > 0)
                                {
                                    _dvt = _dt.Rows[i][3].ToString().Trim();
                                }
                                else
                                {
                                    _loi++;
                                    reason = "DVT không có trong master";
                                    _dt.Rows[i]["c_reason"] = reason;
                                    _dt.AcceptChanges();
                                    _xuatexcel++;
                                }

                            }
                            else
                            {
                                _loi++;
                                reason = "DVT không được rỗng";
                                _dt.Rows[i]["c_reason"] = reason;
                                _dt.AcceptChanges();
                                _xuatexcel++;
                            }

                            //4: mancc
                            if (_dt.Rows[i][4].ToString() != "" && _dt.Rows[i][4].ToString() != String.Empty)
                            {
                                DataRow[] dr = _ds_ncc.Tables[0].Select("c_mancc = '" + _dt.Rows[i][4].ToString().Trim().ToUpper() + "' ");
                                if (dr.Length > 0)
                                {
                                    _mancc = _dt.Rows[i][4].ToString().Trim().ToUpper();
                                    _tenncc = dr[0]["c_tenncc"].ToString();

                                    _dt.Rows[i][5] = _tenncc;
                                    _dt.AcceptChanges();

                                }
                                else
                                {
                                    _loi++;
                                    reason = "Mã NCC không có trong master";
                                    _dt.Rows[i]["c_reason"] = reason;
                                    _dt.AcceptChanges();
                                    _xuatexcel++;
                                }

                            }
                            else
                            {

                                _loi++;
                                reason = "Mã NCC không được rỗng";
                                _dt.Rows[i]["c_reason"] = reason;
                                _dt.AcceptChanges();
                                _xuatexcel++;
                            }

                            //5: ghichu
                            if (_dt.Rows[i][6].ToString() != "" && _dt.Rows[i][6].ToString() != String.Empty)
                            {
                                _ghichu = _dt.Rows[i][6].ToString().Trim().ToUpper();
                                _dt.Rows[i][6] = _ghichu;
                                _dt.AcceptChanges();
                            }

                            if (_loi == 0)
                            {
                                ////kiem tra MSNV da co chưa

                                DataRow[] dr_mahh = _dt_data.Select("c_mahh = '" + _mahh + "'  ");
                                if (dr_mahh.Length > 0)
                                {
                                    //update

                                    _sql = string.Empty;
                                    _sql = "  UPDATE  m_hanghoa set "
                                        + "  c_type_kho =  '" + c_type_kho + "', c_ma1 = '" + c_ma1 + "', c_type_loaihh ='" + c_type_loaihh + "' , c_ma2=  '" + c_ma2 + "' "
                                        + "  , c_dvt ='" + _dvt + "', c_mancc = '" + _mancc + "', c_tenncc = '" + _tenncc + "', c_note ='" + _ghichu + "', "
                                        + " c_msnv ='" + _msnv + "', d_date = CURRENT_TIMESTAMP "
                                        + "  where c_mahh = '" + _mahh + "' and c_tenhh  = '" + _tenhh + "' ";
                                    _kq = _cn.Execute_Nonquery(_sql);

                                }
                                else
                                {
                                    //insert new
                                    _sql = string.Empty;
                                    _sql = "    INSERT INTO m_hanghoa ( c_type_kho, c_ma1, c_type_loaihh, c_ma2, c_mahh, "
                                        + " c_tenhh, c_dvt, c_mancc, c_tenncc, c_note, c_msnv, d_date ) "
                                        + " values( '" + c_type_kho + "','" + c_ma1 + "', '" + c_type_loaihh + "' ,  '" + c_ma2 + "' ,  '" + _mahh + "', "
                                   + "   '" + _tenhh + "',   '" + _dvt + "',   '" + _mancc + "',   '" + _tenncc + "',  '" + _ghichu + "',  '" + _msnv + "', CURRENT_TIMESTAMP ) ";
                                    _kq = _cn.Execute_Nonquery(_sql);
                                }

                                 if (_kq == 1)
                                 {
                                     _dem++;
                                     _loi = 0;
                                 }

                            }

                        }
                    }

                    if (_dem > 0 || _xuatexcel == -1 || _loi > 0)
                    {
                        DataRow[] dr_loi = _dt.Select("c_reason is not null  ");
                        DataTable _dt_excel = new DataTable();
                        _dt_excel = _dt.Copy();
                        _dt_excel.AcceptChanges();
                        //  //c_type_kho, c_ma1,c_type_loaihh,c_ma2,c_mahh
                        _dt_excel.Columns.Remove("c_type_kho");
                        _dt_excel.Columns.Remove("c_ma1");
                        _dt_excel.Columns.Remove("c_type_loaihh");
                        _dt_excel.Columns.Remove("c_ma2");
                        _dt_excel.Columns.Remove("c_mahh");
                        _dt_excel.AcceptChanges();
                        if (dr_loi.Length > 0)
                        {
                            Export_Loi(_dt_excel);
                        }
                        Loadcombox();
                        Loadcombox_TK();
                        Loaddata();
                        MessageBox.Show("Số dòng đã import thành công: " + _dem.ToString() + " dòng" + "\n" + "Số dòng lỗi: " + dr_loi.Length.ToString() + " dòng");
                    }

                }
                frm.Close();
            }
        
           
          
        }

        private void txt_excelmau_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process p = new System.Diagnostics.Process();
            p.StartInfo.FileName = Application.StartupPath + @"\ExcelImport_HangHoa.xlsx";
            p.Start();
        }

    }
        
}
