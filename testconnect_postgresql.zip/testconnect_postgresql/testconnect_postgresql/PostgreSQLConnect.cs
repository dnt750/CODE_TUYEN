﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Npgsql;
using System.Windows.Forms;
using System.Xml;
using System.IO;
//using System.Data.OleDb;

    public class DataProvider
    {
        protected NpgsqlCommand _cmd;
        protected NpgsqlDataAdapter _adap;
        protected DataSet _ds;
        //https://qiita.com/mimitaro/items/fde451da2f722fe12072

        public static string GetXMLconn()
        {
            string xmlConStr = "";
            //
            string XMLconnect = Application.StartupPath + @"\" + "ConnectionString.xml";

            // Get the Connection String from the XML file.
            XmlTextReader textReader = new XmlTextReader(XMLconnect);
          
            DataSet Tbl_table = new DataSet();
            Tbl_table.ReadXml(textReader);
            xmlConStr = Tbl_table.Tables[0].Rows[0][0].ToString();        
            return xmlConStr;

            //https://www.sqlines.com/postgresql/npgsql_cs_result_sets
        }
    
        NpgsqlConnection connection = new NpgsqlConnection(GetXMLconn());
          //_dt = new DataTable();
          //  cmd_str = "SELECT * FROM test";
          //  cmd = new NpgsqlCommand(cmd_str, conn);
          //  da = new NpgsqlDataAdapter(cmd);
          //  da.Fill(dt);

        public  DataSet Get_ds_CommandSQL(string _strSQL)
        {

            _cmd = new NpgsqlCommand();
            _adap = new NpgsqlDataAdapter();           
            _ds = new DataSet();
            try
            {
              
                connection.Open();
                _cmd.Connection = connection;
                _cmd.CommandText = _strSQL;
                _cmd.CommandType = CommandType.Text;

                _cmd.ExecuteNonQuery();
                _adap.SelectCommand = _cmd;
                _ds.Clear();
                _adap.Fill(_ds);
                connection.Close();
                _cmd.Dispose();
                _adap.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _ds;
        }
        
        public  DataTable Get_dt_CommandSQL(string _strSQL)
        {

            _cmd = new NpgsqlCommand();
            _adap = new NpgsqlDataAdapter();           
            DataTable _dt = new DataTable();
            try
            {              
                connection.Open();
                _cmd.Connection = connection;
                _cmd.CommandText = _strSQL;
                _cmd.CommandType = CommandType.Text;
                _cmd.ExecuteNonQuery();
                _adap.SelectCommand = _cmd;              
                _adap.Fill(_dt);
                connection.Close();
                _cmd.Dispose();
                _adap.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _dt;
        }

   
    
        public System.Data.DataTable GetData_Proc(string _storename)
        {

            _cmd = new NpgsqlCommand();
            _adap = new NpgsqlDataAdapter();
            System.Data.DataTable _dt = new System.Data.DataTable();

            try
            {
                connection.Open();
                _cmd.Connection = connection;
                NpgsqlTransaction tran = connection.BeginTransaction();
                _cmd.CommandType = CommandType.StoredProcedure;           
                _cmd.CommandType = CommandType.Text;
                _cmd = new NpgsqlCommand(_storename, connection);


                    _cmd.ExecuteNonQuery();
             
                    _adap.SelectCommand = _cmd;
                    _adap.Fill(_dt);


                    tran.Commit();
                    connection.Close();
                    _cmd.Dispose();
                    _adap.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _dt;
        }


        public int Execute_Nonquery(string _sql  ) //, string[] _arrparameter, string[] _arrvalue )
        {
            int _kq;
            _cmd = new NpgsqlCommand();
            _adap = new NpgsqlDataAdapter();
            System.Data.DataTable _dt = new System.Data.DataTable();
         
            try
            {
                connection.Open();
                _cmd.Connection = connection;
               NpgsqlTransaction tran = connection.BeginTransaction();

             
                _cmd = new NpgsqlCommand(_sql, connection);

            
                 _cmd.ExecuteNonQuery();
               _kq = 1;
                tran.Commit();
                connection.Close();
                _cmd.Dispose();
                _adap.Dispose();


            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _kq;


        }
  
        public System.Data.DataTable GetData_Proc2(string _storename)
        {

            _cmd = new NpgsqlCommand();
            _adap = new NpgsqlDataAdapter();
            System.Data.DataTable _dt = new System.Data.DataTable();

            try
            {
                //https://stackoverflow.com/questions/32862416/how-can-i-get-cursor-data-with-calling-stored-procedure-in-npgsql
                connection.Open();
                _cmd.Connection = connection;
                // Start a transaction as it is required to work with result sets (cursors) in PostgreSQL
                NpgsqlTransaction tran = connection.BeginTransaction();
                _cmd.CommandType = CommandType.Text;
                _cmd.CommandText = _storename;
                _cmd.CommandType = CommandType.StoredProcedure;
                _cmd.Parameters.Clear();
              
                _adap.SelectCommand = _cmd;
                _ds.Clear();
                _adap.Fill(_dt);
                tran.Commit();
                connection.Close();
                _cmd.Dispose();
                _adap.Dispose();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return _dt;

        }

        //public System.Data.DataTable Read_excel_new_HDR(string fileName)
        //{
        //    System.Data.DataTable _dt = new System.Data.DataTable();
        //    var connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties=\"Excel 12.0;IMEX=1;HDR=YES;TypeGuessRows=0;ImportMixedTypes=Text\"";
        //    FileInfo fi = new FileInfo(fileName);
        //    if (fi.Extension == ".xls")
        //        connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;data source=" + fileName + ";Extended Properties=\"Excel 8.0;HDR=YES;IMEX=1\";";

        //    using (var conn = new OleDbConnection(connectionString))
        //    {
        //        conn.Open();
        //        var sheets = conn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
        //        //var sheets = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
        //        using (var cmd = conn.CreateCommand())
        //        {
        //            //[Sheet1$]"
        //            cmd.CommandText = "SELECT * FROM [イベント対応依頼書$] ";
        //            //cmd.CommandText = "SELECT * FROM [" + sheets.Rows[0]["TABLE_NAME"].ToString() + "] ";

        //            var adapter = new OleDbDataAdapter(cmd);
        //            var ds = new DataSet();
        //            adapter.Fill(_dt);

        //        }
        //    }

        //    return _dt;
        //}
   
    }
