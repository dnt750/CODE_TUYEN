﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
//C:\Windows\Microsoft.NET\assembly\GAC_MSIL\Npgsql\v4.0_3.2.7.0__5d8b90d52f46fda7
//Npgsql version: 3.2.7
//PostgreSQL version: PostgreSQL 16
//.NET Framework: 4.6.2

//https://minhhn.com/lap-trinh-c-sharp/cach-ket-noi-co-so-du-lieu-postgresql-tu-csharp/


//create [or replace] procedure procedure_name(parameter_list)
//language plpgsql
//as $$
//declare
//-- variable declaration
//begin
//-- stored procedure body
//end; $$


//CREATE OR REPLACE PROCEDURE procedure_name(parameter1 datatype, parameter2 datatype)
//LANGUAGE plpgsql
//AS $$
//DECLARE
//    -- Declare local variables if needed
//BEGIN
//    -- Your SQL logic here
//EXCEPTION
//    WHEN OTHERS THEN
//        -- Handle exceptions if needed
//        RAISE EXCEPTION 'exception';
//END;
//$$;



  //create function get_results()
  //    returns setof refcursor
  //  as
  //  $$
  //  declare
  //     c1 refcursor;
  //     c2 refcursor;
  //  begin
  //     open c1 for select * from (values (1,2,3), (4,5,6)) as t(a,b,c);
  //     return next c1;
  //     open c2 for select * from (values ('one'),('two'),('three'),('four')) as p(name);
  //     return next c2;
  //  end;
  //  $$
  //  language plpgsql;

namespace testconnect_postgresql
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DataProvider _cn = new DataProvider();
        DataSet _ds = new DataSet();
        DataTable _dt_mnsv = new DataTable();
        DataTable _dt = new DataTable();
        DataTable _dt_data = new DataTable();
        int _flagupdate = 0;

        private void TimKiem()
        {
            string _msnv = string.Empty;
            string _hoten = string.Empty;
            string _sql = string.Empty;
            if (cbo_MSNV_TK.Text != "")
            {
                _msnv = cbo_MSNV_TK.SelectedValue.ToString();
            }
            else
            {
                _msnv = cbo_MSNV_TK.Text;
            }

            if (cbo_hoten_TK.Text != "")
            {
                _hoten = cbo_hoten_TK.Text;
            }
            else
            {
                _hoten = cbo_hoten_TK.Text;
            }


            _sql = "SELECT c_msnv ,c_hoten  , TO_char(d_date, 'YYYY/MM/DD HH24:MI:ss') d_date FROM m_nhanvien   where 1=1 and ";  // c_msnv  = '" + _msnv + "' order by c_hoten 
            _sql = _sql + " c_msnv like '" + _msnv + "%' ";
            _sql = _sql + " and c_hoten like '" + _hoten + "%' ";
            _sql = _sql + " order by c_msnv ";

            _ds = _cn.Get_ds_CommandSQL(_sql);

            if (_ds.Tables[0].Rows.Count > 0)
            {
                dgv_Data.AutoGenerateColumns = false;
                dgv_Data.DataSource = _ds.Tables[0];
                txt_sodong.Text = _ds.Tables[0].Rows.Count.ToString();

            }
            else
            {
                MessageBox.Show("Không có dữ liệu.!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dgv_Data.DataSource = _ds.Tables[0];
                return;
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
 ////           // string connectionString = "Host=my_host;Port=port_number;Database=database_name;User Id=username;Password=password;";
//            string connectionString = string.Format("Server={0};Port={1};User Id={2};Password={3};Database={4};",
//"localhost", 5432, "postgres", "tuyen", "postgres");
//            NpgsqlConnection connection = new NpgsqlConnection(connectionString);
//            connection.Open();

//            NpgsqlCommand cmd = new NpgsqlCommand("SELECT * FROM m_nhanvien", connection);

 ////   NpgsqlDataReader reader = cmd.ExecuteReader();

            TimKiem();

        }

        private void FormatGrid()
        {
            dgv_Data.EnableHeadersVisualStyles = false;
            dgv_Data.Font = new Font("Times New Roman", 10, FontStyle.Regular);
            dgv_Data.EnableHeadersVisualStyles = false;
            dgv_Data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv_Data.ColumnHeadersHeight = 45;
            dgv_Data.BorderStyle = BorderStyle.Fixed3D;
            DataGridViewCellStyle styleHeader = new DataGridViewCellStyle();

            styleHeader.Font = new Font("Times New Roman", 10, FontStyle.Bold);
            styleHeader.ForeColor = Color.Blue;
            styleHeader.Alignment = DataGridViewContentAlignment.MiddleCenter;

            for (int i = 0; i < dgv_Data.Columns.Count; i++)
            {
                dgv_Data.Columns[i].HeaderCell.Style = styleHeader;
                // dgv_Data.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

        }

        private void createGrid()
        {

            dgv_Data.Rows.Clear();
            dgv_Data.Columns.Clear();
            dgv_Data.DataSource = null;

            DataGridViewCheckBoxColumn colCheck = new DataGridViewCheckBoxColumn();
            colCheck.Name = "check";
            dgv_Data.Columns.Add(colCheck);
            dgv_Data.Columns[0].HeaderText = "Check";
            dgv_Data.Columns[0].Width = 48;
          
            dgv_Data.Columns.Add("c_msnv", "MSNV");
            dgv_Data.Columns[1].Width = 85;
            dgv_Data.Columns[1].ReadOnly = true;
            dgv_Data.Columns[1].DataPropertyName = "c_msnv";
            dgv_Data.Columns[1].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_hoten", "Ho ten");
            dgv_Data.Columns[2].Width = 220;
            dgv_Data.Columns[2].ReadOnly = true;
            dgv_Data.Columns[2].DataPropertyName = "c_hoten";
            dgv_Data.Columns[2].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("d_date", "Ngày cập nhật");
            dgv_Data.Columns[3].Width = 160;
            dgv_Data.Columns[3].ReadOnly = true;
            dgv_Data.Columns[3].DataPropertyName = "d_date";
            dgv_Data.Columns[3].DefaultCellStyle.BackColor = Color.LightGray;

            FormatGrid();

        }
        private void Loadcombox_MSNV_TK()
        {
            DataSet ds = new DataSet();

            string _sql = string.Empty;
            _sql = "SELECT c_msnv FROM m_nhanvien order by c_msnv ";
            ds = _cn.Get_ds_CommandSQL(_sql);
            if (ds.Tables[0].Rows.Count > 0)
            {

                DataRow row = ds.Tables[0].NewRow();
                ds.Tables[0].Rows.InsertAt(row, 0);
                cbo_MSNV_TK.DataSource = ds.Tables[0];
                cbo_MSNV_TK.DisplayMember = "c_msnv";
                cbo_MSNV_TK.ValueMember = "c_msnv";
            }
        }
        private void Loadcombox_hoten_TK()
        {
           
            string _msnv = string.Empty;

            if (cbo_MSNV_TK.Text != "")
            {
                _msnv = cbo_MSNV_TK.SelectedValue.ToString();
            }
            else
            {
                _msnv = cbo_MSNV_TK.Text;
            }

            string _sql = string.Empty;
            _sql = string.Empty;
            _sql = "SELECT c_hoten,  c_msnv  FROM m_nhanvien   where 1=1 and ";  // c_msnv  = '" + _msnv + "' order by c_hoten 
            _sql = _sql + "c_msnv like '" + _msnv + "%' ";
            _sql = _sql + "order by c_hoten ";
           
            DataSet ds1 = new DataSet();
            ds1 = _cn.Get_ds_CommandSQL(_sql);
            if (ds1.Tables[0].Rows.Count > 0)
            {

                DataRow row = ds1.Tables[0].NewRow();
                ds1.Tables[0].Rows.InsertAt(row, 0);
                cbo_hoten_TK.DataSource = ds1.Tables[0];
                cbo_hoten_TK.DisplayMember = "c_hoten";
                cbo_hoten_TK.ValueMember = "c_msnv";
            }

        }
        private void Loadcombox_TK()
        {
            Loadcombox_MSNV_TK();
            Loadcombox_hoten_TK();
  
        }

        private void Loaddata()
        {
            string _sql = string.Empty;
            _sql = "SELECT  c_msnv, c_hoten, d_date FROM m_nhanvien order by  c_msnv";
            _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                _dt_data = _ds.Tables[0];

            }
            else
            {
                _dt_data = _ds.Tables[0];
            }

            _sql = string.Empty;
            _sql = "SELECT  c_msnv  FROM m_nhanvien order by  c_msnv";
            _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                _dt_mnsv = _ds.Tables[0];

            }
            else
            {
                _dt_mnsv = _ds.Tables[0];
            }


        }


        private void Form1_Load(object sender, EventArgs e)
        {
            createGrid();
            Loadcombox_TK();
            Loaddata();

            //_dt = new DataTable();
            //cmd_str = "SELECT * FROM test";
            //cmd = new NpgsqlCommand(cmd_str, conn);
            //da = new NpgsqlDataAdapter(cmd);
            //da.Fill(dt);

            //so sanh oracle-to-postgresql
            //https://www.sqlines.com/oracle-to-postgresql
            //https://www.linuxlover.in/2021/12/refcursor-in-postgresql.html


            //https://www.numpyninja.com/post/cursors-in-pl-pgsql-in-postgresql-database-system


          //  https://www.postgresql.org/docs/current/plpgsql-porting.html
            //https://www.sqlines.com/postgresql/stored_procedures_functions
             DataTable _dt = new DataTable();
            // _dt = _cn.GetData_Proc("select get_m_nhanvien()" );
            //if (_dt.Rows.Count > 0)
            //{
            //    dgv_Data.AutoGenerateColumns = false;
            //    dgv_Data.DataSource = _ds.Tables[0];
            //}
     
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DeleteData()
        {
            int _kq = 0;
            int count_kq = 0;

            string _c_msnv = string.Empty;
            string _hoten = string.Empty;
            string _sql = string.Empty;

            if (dgv_Data.Rows.Count > 0)
            {
                int dem = 0;
                for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                {
                    //kiem tra neu co 1 dong dc check thi xoa
                    if (Convert.ToBoolean(dgv_Data.Rows[i].Cells[0].Value) == true)// lay vi tri cua dong dang check
                    {

                        dem++;
                        continue;
                    }

                }
                if (dem == 0)
                {
                    MessageBox.Show("Bạn chưa chọn dòng cần xóa", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (MessageBox.Show("Bạn Có Muốn Xóa Không", "Thông Báo!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                    {
                        if (dgv_Data.Rows[i].Cells["check"].Value != null)
                        {
                            if (dgv_Data.Rows[i].Cells["check"].Value.ToString() == "True" || dgv_Data.Rows[i].Cells["check"].Value.ToString() == "1")
                            {

                                _c_msnv  = dgv_Data.Rows[i].Cells["c_msnv"].Value.ToString();
                                _hoten = dgv_Data.Rows[i].Cells["c_hoten"].Value.ToString();

                                _sql = "delete from  m_nhanvien  WHERE c_msnv =  '" + _c_msnv + "'   ";                     
                                _kq = _cn.Execute_Nonquery(_sql);
                                if (_kq == 1)
                                {
                                    count_kq = count_kq + 1;
                                }
                               
                                //if (kq == 1)
                                //{
                                //    //ghi log
                                //    count_kq = count_kq + 1;
                                //    string _details = "Delete M_LINESTOP  where " + " c_seizou= " + _dto.C_mapct + "  ,c_line= " + _dto.C_line + " ";
                                //    _buss.Execute_Nonquery_Log("PK_CHOKUSIJI_TUYEN.WRITELOG", _msnv, _IPMachine, _details); //ghi log CT
                                //}

                            }
                        }

                    }
                }

            }

            else
            {
                MessageBox.Show("Không có dữ liệu để xóa", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (count_kq > 0)
            {
                Loadcombox_TK();
                TimKiem();
                Loaddata();
                MessageBox.Show("Đã xóa thành công.", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Xóa dữ liệu bị lỗi.", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btn_Delete_Click(object sender, EventArgs e)
        {
            DeleteData();
        }

        private void Nhapdulieu()
        {
            string _msnv = string.Empty;
            string _hoten = string.Empty;
            int _kq= 0;
            //1
            if (txt_MSNV.Text != "")
            {
                if (txt_MSNV.Text.Trim().Length > 10)
                {
                    MessageBox.Show("MSNV phải < 11 kí tự", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    _msnv = txt_MSNV.Text.Trim();

                }
            }
            else
            {
                MessageBox.Show("MSNV không được rỗng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //
            if (txt_hoten.Text != "")
            {
                _hoten = txt_hoten.Text.Trim().ToUpper();
            }
            else
            {
                MessageBox.Show("Họ tên không được rỗng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (_dt_data.Rows.Count > 0)
            {

                DataRow[] dr_check_msnv = _dt_data.Select("c_msnv= '" + _msnv + "'   ");
                DataRow[] dr_check = _dt_data.Select("c_msnv= '" + _msnv + "' and c_hoten= '" + _hoten + "'  ");

                string[] _param = { "p_msnv", "p_hoten" };
                string[] _value = { _msnv, _hoten };
                string _sql = string.Empty;

              
                //string procedure = "proc_insert_msnv() ";
                //CALL sp_add_users_new(:p1, :p2)
                //_kq = _cn.Execute_Nonquery_in(_msnv, _hoten);
              //  _kq = _cn.Execute_Nonquery(procedure, _param, _value);
                if (dr_check_msnv.Length > 0)
                {
                    //update
                
                    _sql = "update m_nhanvien SET  c_hoten = '" + _hoten + "', d_date = CURRENT_TIMESTAMP  "
                   + " WHERE c_msnv =  '" + _msnv + "' ";
                    _kq = _cn.Execute_Nonquery(_sql);

                }
                else
                {
                    //insert new
                    _sql = " insert into m_nhanvien(c_msnv, c_hoten, d_date ) "
                 + " values('" + _msnv + "','" + _hoten + "', CURRENT_TIMESTAMP ) ";
                  _kq=   _cn.Execute_Nonquery (_sql);

                }
                if (_kq == 1)
                {
                    Clear_input();
                    MessageBox.Show("Lưu dữ liệu thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Loadcombox_TK();
                    TimKiem();
                    Loaddata();
                 
                }
                
            }

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            Nhapdulieu();
        }

        private void dgv_Data_ColumnHeaderMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {

            int _cot = e.ColumnIndex;
            if (dgv_Data.RowCount > 0)
            {
                dgv_Data.CurrentCell = dgv_Data.Rows[0].Cells[1];
                if (_cot == 0)
                {
                    bool kq = dgv_Data.Rows[0].Cells[0].Value == null ? false : Convert.ToBoolean(dgv_Data.Rows[0].Cells[0].Value.ToString());
                    for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                    {
                        dgv_Data.Rows[i].Cells[_cot].Value = !kq;
                    }
                }
            }         

        }

     
        #region khai bao
        string _c_msnv_B = string.Empty;
        string _c_hoten_B = string.Empty;
        string _c_hoten_E = string.Empty;

        #endregion
        private void dgv_Data_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1 && e.ColumnIndex != -1)
            {
                _flagupdate = 1;

                if (dgv_Data.Rows[e.RowIndex].Cells["c_msnv"].Value != string.Empty)
                {

                    _c_msnv_B = dgv_Data.Rows[e.RowIndex].Cells["c_msnv"].Value.ToString().Trim();
                    txt_MSNV.Text = _c_msnv_B;
                }

                if (dgv_Data.Rows[e.RowIndex].Cells["c_hoten"].Value != string.Empty)
                {

                    _c_hoten_B = dgv_Data.Rows[e.RowIndex].Cells["c_hoten"].Value.ToString().Trim();
                    txt_hoten.Text = _c_hoten_B;
                }
            }

        }

      
        private static void ExportExcel(System.Data.DataTable _dtT)
        {
            SaveFileDialog sFD = new SaveFileDialog();
            sFD.FileName = "";
            sFD.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";

            sFD.ShowDialog();
            if (sFD.FileName == "")
                return;
            System.IO.File.Copy(System.Windows.Forms.Application.StartupPath + "\\Export_excel.xlsx", sFD.FileName, true);
            Excel.Application _app = new Excel.Application();
            Excel.Workbook _wb = _app.Workbooks.Open(sFD.FileName, 0, false, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true);


            Excel.Sheets sheets = _wb.Worksheets;
            Excel.Worksheet _ws = (Excel.Worksheet)sheets.get_Item(1);
            object[,] arr = new object[_dtT.Rows.Count + 1, _dtT.Columns.Count];
            string[] _arrHeader = { "MSNV"
                                                , "Ho ten"
                                                                                                                        
                                                };
            //lay ten cua cot
            for (int i = 0; i < _arrHeader.Length; i++)
            {
                arr[0, i] = _arrHeader.GetValue(i);
                Excel.Range rng_tieude = (Excel.Range)_ws.Cells[1, i + 1];
                rng_tieude.Font.Bold = true;
                rng_tieude.Font.Size = 12;
            }
            //do du lieu 
            for (int r = 0; r < _dtT.Rows.Count; r++)
            {
                DataRow dr = _dtT.Rows[r];
                for (int c = 0; c < _dtT.Columns.Count; c++)
                {
                    arr[r + 1, c] = dr[c];
                    if (c == 2)
                    {
                        Excel.Range rng_data = (Excel.Range)_app.Cells[r + 1, 2];
                        rng_data.EntireColumn.NumberFormat = "@";
                    }

                }
            }

            Excel.Range c1 = (Excel.Range)_ws.Cells[1, 1];
            Excel.Range c2 = (Excel.Range)_ws.Cells[1 + _dtT.Rows.Count - 1 + 1, _dtT.Columns.Count];

            Excel.Range range = _ws.get_Range(c1, c2);
            range.Value = arr;
            _app.Columns.AutoFit();
            _app.DisplayAlerts = false;
            _wb.Close(true, Missing.Value, Missing.Value);
            _app.Quit();
            releaseObject(_ws);
            releaseObject(_wb);
            releaseObject(_app);
            _ws = null;
            _wb = null;
            _app = null;
        }


        public System.Data.DataTable _MyReadExcel(string sUploadFilePath, int sheet)
        {
            //oXL, oWB, oSheet, sheets
            Excel.Workbook oWB = null;
            Excel.Worksheet oSheet = null;
            Excel.Range oRng = null;
            Excel.Range oRng1 = null;
            Excel.Range oRng2 = null;
    
            try
            {
                //Create a Application object       
                Excel.Application oXL = new Excel.Application();

                try
                {
                    oWB = oXL.Workbooks.Open(sUploadFilePath, 0, false, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true);
                }
                catch
                {
                    MessageBox.Show("Không mở được file này");
                }
                //Getting WorkSheet object   
                Excel.Sheets sheets = oWB.Worksheets;
                oSheet = (Excel.Worksheet)sheets.get_Item(1);
                System.Data.DataTable dt = new System.Data.DataTable("dtExcel");
                DataSet ds = new DataSet();
                ds.Tables.Add(dt);
                DataRow dr;
                StringBuilder sb = new StringBuilder();
                int jValue = oSheet.UsedRange.Cells.Columns.Count;
                int iValue = oSheet.UsedRange.Cells.Rows.Count;
                //Getting Data Columns             
                if (jValue > 2)
                {
                    return dt;
                }
                for (int j = 1; j <= jValue ; j++)
                {

                    dt.Columns.Add("column" + j, System.Type.GetType("System.String"));

                }
                //Getting Data in Cell
                try
                {
                    //lay dl tu dong so 2, cot 1
                    for (int i = 2; i <= iValue; i++)
                    {
                        dr = ds.Tables["dtExcel"].NewRow();
                        string t1 = string.Empty;
                        string t2 = string.Empty;
                        for (int j = 1; j <= jValue ; j++)
                        {

                            oRng = (Excel.Range)oSheet.Cells[i, j];
                            string strValue = oRng.Text.ToString();
                            if (strValue != string.Empty || strValue != "")
                            {
                                oRng1 = (Excel.Range)oSheet.Cells[i, 1];
                                t1 = oRng1.Text.ToString();

                                oRng2 = (Excel.Range)oSheet.Cells[i, 2];
                                t2= oRng2.Text.ToString();

                                dr["column" + j] = strValue;

                            }

                        }

                        if (t1 != "" || t1 != string.Empty && t2 != "" || t2 != string.Empty)
                        {
                            ds.Tables["dtExcel"].Rows.Add(dr);
                            dt = ds.Tables[0];
                        }

                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

                oWB.Close(false, System.Reflection.Missing.Value, System.Reflection.Missing.Value);
                oXL.Workbooks.Close();
                oXL.Quit();

                releaseObject(oSheet);
                releaseObject(sheets);
                releaseObject(oWB);
                releaseObject(oXL);
                oXL = null;
                oWB = null;
                oSheet = null;
                sheets = null;
                oRng = null;
              

                //kill excel
                foreach (System.Diagnostics.Process proc in System.Diagnostics.Process.GetProcessesByName("EXCEL"))
                {
                    if (proc.MainWindowTitle.ToString() == "")
                    {
                        proc.Kill();
                    }

                }

                return ds.Tables[0];
            }
            catch (Exception ex)
            {
                return null;
                throw ex;
            }
            finally
            {
               
            }
        }


        private static void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        private void btn_Excel_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgv_Data.RowCount <= 0)
                {
                    MessageBox.Show("Không có dữ liệu để xuất Excel.!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                else
                {
                    System.Data.DataTable _dtExcel = new System.Data.DataTable();
                    _dtExcel = (DataTable)dgv_Data.DataSource;
                    _dtExcel.Columns.Remove("d_date");
                    _dtExcel.AcceptChanges();
                    if (MessageBox.Show("Bạn Có Muốn Xuất Ra Excel Không ???", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        this.Cursor = Cursors.WaitCursor;
                        ExportExcel(_dtExcel);
                        this.Cursor = Cursors.Default;
                        MessageBox.Show("Xuất Excel thành công.!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Clear_input()
        {
            cbo_hoten_TK.SelectedIndex = -1;
            cbo_MSNV_TK.SelectedIndex = -1;
        
            txt_MSNV.Text = string.Empty;
            txt_hoten.Text = string.Empty;
            txt_sodong.Text = string.Empty;
            dgv_Data.DataSource = null;
            // mtb_datestop.Text = "    /  /";
          
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            Clear_input();
        }

        private void cbo_MSNV_TK_SelectedIndexChanged(object sender, EventArgs e)
        {
            Loadcombox_hoten_TK(); 
        }

        private void txt_MSNV_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                if (txt_MSNV.Text == "" || txt_MSNV.Text == string.Empty)
                {
                    MessageBox.Show("chưa nhập MSNV", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    txt_hoten.Focus();
                }
            }

        }

        private void txt_excelmau_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process p = new Process();
            p.StartInfo.FileName = Application.StartupPath + @"\ExcelImport_MSNV.xlsx";
            p.Start();
        }

        public void Export_Loi(System.Data.DataTable _dt)
        {
            //DataTable _dt;
            try
            {
                if (MessageBox.Show("Import có lỗi, Bạn có muốn xuất lỗi ra excel không???", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    if (_dt.Rows.Count > 0)
                    {
                        try
                        {

                            SaveFileDialog sFD = new SaveFileDialog();
                            sFD.FileName = "";
                            sFD.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                            sFD.ShowDialog();
                            if (sFD.FileName == "")
                                return;

                            System.IO.File.Copy(System.Windows.Forms.Application.StartupPath + "\\Export_excel.xlsx", sFD.FileName, true);
                            Excel.Application _app = new Excel.Application();
                            Excel.Workbook _wb = _app.Workbooks.Open(sFD.FileName, 0, false, 5, "", "", true, Excel.XlPlatform.xlWindows, "\t", false, false, 0, true);
                            Excel.Sheets sheets = _wb.Worksheets;
                            Excel.Worksheet worksheet = (Excel.Worksheet)sheets.get_Item(1);

                            object[,] arr = new object[_dt.Rows.Count + 1, _dt.Columns.Count];

                            string[] _arrHeader = { "MSNV"
                                                                  ,"Họ tên	"
                                                                , "Reason"          
                                                            };
                            //lay ten cua cot
                            for (int i = 0; i <= _arrHeader.Length - 1; i++)
                            {
                                arr[0, i] = _arrHeader.GetValue(i);
                                Excel.Range rng_tieude = (Excel.Range)worksheet.Cells[1, i + 1];
                                //  rng_tieude.Font.b = true;
                                rng_tieude.Font.Size = 11;
                            }

                            //do du lieu 
                            for (int r = 0; r <= _dt.Rows.Count - 1; r++)
                            {
                                DataRow dr = _dt.Rows[r];
                                for (int c = 0; c <= _dt.Columns.Count - 1; c++)
                                {
                                    arr[r + 1, c] = dr[c];

                                }
                            }

                            Excel.Range c1 = (Excel.Range)worksheet.Cells[2, 1];
                            Excel.Range c2 = (Excel.Range)worksheet.Cells[2 + _dt.Rows.Count - 1 + 1, _dt.Columns.Count];

                            Excel.Range range = worksheet.get_Range(c1, c2);
                            range.Value = arr;
                            _app.Columns.AutoFit();
                            _app.DisplayAlerts = false;
                            _wb.Close(true, Missing.Value, Missing.Value);
                            _app.Quit();
                            releaseObject(worksheet);
                            releaseObject(_wb);
                            releaseObject(_app);
                            worksheet = null;
                            _wb = null;
                            _app = null;


                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }

                    else
                    {
                        MessageBox.Show("Không Có Dữ Liệu Xuất Ra Excel", "Thông Báo!!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
                return;
            }
        }

        private void btn_Import_Click(object sender, EventArgs e)
        {
            DataTable _dt_import = new DataTable();
   
            int _loi = 0;
            int _kq = 0;
            int _dem = 0;
            int _xuatexcel = 0;
            string reason = string.Empty;
            string _c_msnv = string.Empty;
            string _c_hoten= string.Empty;
            string _sql = string.Empty;

             OpenFileDialog _dlg = new OpenFileDialog();
            _dlg.AddExtension = true;
            _dlg.CheckFileExists = true;
            _dlg.Filter = "Excel files|*.xlsx";
            _dlg.Multiselect = false;
            if (_dlg.ShowDialog() == DialogResult.OK)
            {
                _dt = _MyReadExcel(_dlg.FileName, 1);

                if (_dt == null)
                {
                    return;
                }
                if (_dt.Rows.Count == 0)
                {
                    MessageBox.Show("File import khong co du lieu");
                    return;

                }
                if (_dt.Columns.Count > 2)
                {
                    MessageBox.Show("File khong dung dinh dang");
                    return;
                }

                _dt.Columns.Add("c_reason");
                _dt.AcceptChanges();
              
                if (MessageBox.Show("Bạn Có Muốn Lưu dữ liệu không?", "Thông Báo!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    for (int i = 0; i <= _dt.Rows.Count - 1; i++)
                    {
                        if (_dt.Rows[i][0].ToString() == String.Empty || _dt.Rows[i][0].ToString() == "" && _dt.Rows[i][1].ToString() == String.Empty || _dt.Rows[i][1].ToString() == "")
                        {
                            _xuatexcel = -1;
                            if (_dt.Rows[i][0].ToString() == String.Empty || _dt.Rows[i][0].ToString() == "")
                            {
                                _loi++;
                                reason = "MSNV không được rỗng";
                                _dt.Rows[i]["c_reason"] = reason;
                                _dt.AcceptChanges();
                                _xuatexcel++;
                            }

                            if (_dt.Rows[i][1].ToString() == String.Empty || _dt.Rows[i][1].ToString() == "")
                            {
                                _loi++;
                                reason = "Họ tên không được rỗng";
                                _dt.Rows[i]["c_reason"] = reason;
                                _dt.AcceptChanges();
                                _xuatexcel++;
                            }
                        }
                        else
                        {
                            //0
                            if (_dt.Rows[i][0].ToString() != "" && _dt.Rows[i][0].ToString() != String.Empty)
                            {
                               _c_msnv =  _dt.Rows[i][0].ToString().Trim();
                            }
                            else
                            {
                                _loi++;
                                reason = "MSNV không được rỗng";
                                _dt.Rows[i]["c_reason"] = reason;
                                _dt.AcceptChanges();
                                _xuatexcel++;
                            }

                            //1
                              if (_dt.Rows[i][1].ToString() != "" && _dt.Rows[i][1].ToString() != String.Empty)
                            {
                               _c_hoten =  _dt.Rows[i][1].ToString().Trim().ToUpper();
                            }
                            else
                            {
                                _loi++;
                                reason = "Họ tên không được rỗng";
                                _dt.Rows[i]["c_reason"] = reason;
                                _dt.AcceptChanges();
                                _xuatexcel++;
                            }

                            if (_loi == 0)
                            {
                                //kiem tra MSNV da co chưa
                                
                                DataRow[] dr_msnv = _dt_data.Select("c_msnv = '" + _c_msnv + "'  ");
                                DataRow[] dr_ = _dt_data.Select("c_msnv = '" + _c_msnv + "'  and c_hoten =  '" + _c_hoten + "' ");
                                
                                if (dr_msnv.Length > 0)
                                {
                                    if (dr_.Length == 0)
                                    {
                                        //update hoten
                                          _sql = "update m_nhanvien SET  c_hoten = '" + _c_hoten + "', d_date = CURRENT_TIMESTAMP  "
                                       + " WHERE c_msnv =  '" + _c_msnv + "' ";
                                        _kq = _cn.Execute_Nonquery(_sql);
                                        if (_kq ==1)
                                        {
                                            _dem++;
                                        }
                                    }

                                }
                                else
                                {
                                    //neu chua co insert new
                                        _sql = " insert into m_nhanvien(c_msnv, c_hoten, d_date ) "
                                     + " values('" + _c_msnv + "','" + _c_hoten + "', CURRENT_TIMESTAMP ) ";
                                      _kq=   _cn.Execute_Nonquery (_sql);
                                       if (_kq ==1)
                                        {
                                            _dem++;
                                              _loi = 0;
                                        }
                                }

                               
                            }
                         

                        }
                    }

                    if (_dem > 0 || _xuatexcel == -1 || _loi > 0)
                    {
                         DataRow[] dr_loi = _dt.Select("c_reason is not null  ");
                        if (dr_loi.Length > 0)
                        {
                            Export_Loi(_dt);
                        }
                        Loadcombox_TK();
                        Loaddata();
                        MessageBox.Show("Số dòng đã import thành công: " + _dem.ToString() + " dòng" + "\n" + "Số dòng lỗi: " + dr_loi.Length.ToString() + " dòng");
                    }

                }
            }



        }

      

    }
}
