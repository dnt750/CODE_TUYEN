﻿namespace frm_m_buhin
{
    partial class frm_m_buhin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_ghichu = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cmb_ncc = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmb_dvt = new System.Windows.Forms.ComboBox();
            this.cmb_loaihh = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cmb_kho = new System.Windows.Forms.ComboBox();
            this.txt_excelmau = new System.Windows.Forms.LinkLabel();
            this.btn_Import = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_tenhh = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_sodong = new System.Windows.Forms.TextBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.txt_mahh = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cmb_ncc_TK = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cmb_tenhh_TK = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmb_mahh_TK = new System.Windows.Forms.ComboBox();
            this.cmb_loaihh_TK = new System.Windows.Forms.ComboBox();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_Excel = new System.Windows.Forms.Button();
            this.Label11 = new System.Windows.Forms.Label();
            this.btn_Search = new System.Windows.Forms.Button();
            this.cmb_kho_TK = new System.Windows.Forms.ComboBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dgv_Data = new System.Windows.Forms.DataGridView();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Data)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txt_ghichu);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cmb_ncc);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.cmb_dvt);
            this.groupBox2.Controls.Add(this.cmb_loaihh);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.cmb_kho);
            this.groupBox2.Controls.Add(this.txt_excelmau);
            this.groupBox2.Controls.Add(this.btn_Import);
            this.groupBox2.Controls.Add(this.btn_Exit);
            this.groupBox2.Controls.Add(this.btn_Delete);
            this.groupBox2.Controls.Add(this.btn_Save);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txt_tenhh);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txt_sodong);
            this.groupBox2.Controls.Add(this.Label15);
            this.groupBox2.Controls.Add(this.txt_mahh);
            this.groupBox2.Location = new System.Drawing.Point(7, 495);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(951, 188);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Blue;
            this.label8.Location = new System.Drawing.Point(389, 117);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 19);
            this.label8.TabIndex = 233;
            this.label8.Text = "Ghi chú";
            // 
            // txt_ghichu
            // 
            this.txt_ghichu.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ghichu.Location = new System.Drawing.Point(455, 112);
            this.txt_ghichu.MaxLength = 50;
            this.txt_ghichu.Name = "txt_ghichu";
            this.txt_ghichu.Size = new System.Drawing.Size(236, 25);
            this.txt_ghichu.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Blue;
            this.label7.Location = new System.Drawing.Point(389, 78);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 19);
            this.label7.TabIndex = 231;
            this.label7.Text = "NCC";
            // 
            // cmb_ncc
            // 
            this.cmb_ncc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_ncc.DropDownHeight = 100;
            this.cmb_ncc.DropDownWidth = 100;
            this.cmb_ncc.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_ncc.FormattingEnabled = true;
            this.cmb_ncc.IntegralHeight = false;
            this.cmb_ncc.Location = new System.Drawing.Point(455, 75);
            this.cmb_ncc.Name = "cmb_ncc";
            this.cmb_ncc.Size = new System.Drawing.Size(236, 27);
            this.cmb_ncc.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(389, 48);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 19);
            this.label6.TabIndex = 229;
            this.label6.Text = "ĐVT";
            // 
            // cmb_dvt
            // 
            this.cmb_dvt.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_dvt.DropDownHeight = 100;
            this.cmb_dvt.DropDownWidth = 100;
            this.cmb_dvt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_dvt.FormattingEnabled = true;
            this.cmb_dvt.IntegralHeight = false;
            this.cmb_dvt.Location = new System.Drawing.Point(455, 40);
            this.cmb_dvt.Name = "cmb_dvt";
            this.cmb_dvt.Size = new System.Drawing.Size(83, 27);
            this.cmb_dvt.TabIndex = 3;
            // 
            // cmb_loaihh
            // 
            this.cmb_loaihh.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_loaihh.DropDownHeight = 100;
            this.cmb_loaihh.DropDownWidth = 100;
            this.cmb_loaihh.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_loaihh.FormattingEnabled = true;
            this.cmb_loaihh.IntegralHeight = false;
            this.cmb_loaihh.Location = new System.Drawing.Point(105, 75);
            this.cmb_loaihh.Name = "cmb_loaihh";
            this.cmb_loaihh.Size = new System.Drawing.Size(196, 27);
            this.cmb_loaihh.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(7, 78);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 19);
            this.label5.TabIndex = 226;
            this.label5.Text = "Loại hàng hóa";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(7, 48);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 19);
            this.label4.TabIndex = 225;
            this.label4.Text = "Kho";
            // 
            // cmb_kho
            // 
            this.cmb_kho.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_kho.DropDownHeight = 100;
            this.cmb_kho.DropDownWidth = 100;
            this.cmb_kho.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_kho.FormattingEnabled = true;
            this.cmb_kho.IntegralHeight = false;
            this.cmb_kho.Location = new System.Drawing.Point(105, 40);
            this.cmb_kho.Name = "cmb_kho";
            this.cmb_kho.Size = new System.Drawing.Size(103, 27);
            this.cmb_kho.TabIndex = 0;
            // 
            // txt_excelmau
            // 
            this.txt_excelmau.AutoSize = true;
            this.txt_excelmau.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_excelmau.Location = new System.Drawing.Point(251, 155);
            this.txt_excelmau.Name = "txt_excelmau";
            this.txt_excelmau.Size = new System.Drawing.Size(58, 15);
            this.txt_excelmau.TabIndex = 223;
            this.txt_excelmau.TabStop = true;
            this.txt_excelmau.Text = "Excel Mẫu";
            this.txt_excelmau.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.txt_excelmau.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.txt_excelmau_LinkClicked);
            // 
            // btn_Import
            // 
            this.btn_Import.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Import.ForeColor = System.Drawing.Color.Blue;
            this.btn_Import.Location = new System.Drawing.Point(315, 148);
            this.btn_Import.Name = "btn_Import";
            this.btn_Import.Size = new System.Drawing.Size(75, 27);
            this.btn_Import.TabIndex = 6;
            this.btn_Import.Text = "Import";
            this.btn_Import.UseVisualStyleBackColor = true;
            this.btn_Import.Click += new System.EventHandler(this.btn_Import_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.ForeColor = System.Drawing.Color.Red;
            this.btn_Exit.Location = new System.Drawing.Point(850, 151);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(75, 27);
            this.btn_Exit.TabIndex = 9;
            this.btn_Exit.Text = "Thoát";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete.ForeColor = System.Drawing.Color.Red;
            this.btn_Delete.Location = new System.Drawing.Point(616, 147);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 27);
            this.btn_Delete.TabIndex = 8;
            this.btn_Delete.Text = "Xóa";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.Blue;
            this.btn_Save.Location = new System.Drawing.Point(455, 147);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(75, 27);
            this.btn_Save.TabIndex = 7;
            this.btn_Save.Text = "Lưu";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(1, 117);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 19);
            this.label3.TabIndex = 221;
            this.label3.Text = "Tên hàng hóa";
            // 
            // txt_tenhh
            // 
            this.txt_tenhh.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tenhh.Location = new System.Drawing.Point(105, 111);
            this.txt_tenhh.MaxLength = 50;
            this.txt_tenhh.Name = "txt_tenhh";
            this.txt_tenhh.Size = new System.Drawing.Size(237, 25);
            this.txt_tenhh.TabIndex = 2;
            this.txt_tenhh.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_tenhh_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(7, 15);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 19);
            this.label2.TabIndex = 219;
            this.label2.Text = "Số dòng";
            // 
            // txt_sodong
            // 
            this.txt_sodong.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sodong.ForeColor = System.Drawing.Color.Blue;
            this.txt_sodong.Location = new System.Drawing.Point(105, 9);
            this.txt_sodong.MaxLength = 30;
            this.txt_sodong.Name = "txt_sodong";
            this.txt_sodong.ReadOnly = true;
            this.txt_sodong.Size = new System.Drawing.Size(103, 25);
            this.txt_sodong.TabIndex = 10;
            this.txt_sodong.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label15.ForeColor = System.Drawing.Color.Blue;
            this.Label15.Location = new System.Drawing.Point(5, 151);
            this.Label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(88, 19);
            this.Label15.TabIndex = 217;
            this.Label15.Text = "Mã hàng hóa";
            // 
            // txt_mahh
            // 
            this.txt_mahh.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_mahh.Location = new System.Drawing.Point(107, 145);
            this.txt_mahh.MaxLength = 10;
            this.txt_mahh.Name = "txt_mahh";
            this.txt_mahh.ReadOnly = true;
            this.txt_mahh.Size = new System.Drawing.Size(103, 25);
            this.txt_mahh.TabIndex = 18;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.cmb_ncc_TK);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.cmb_tenhh_TK);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.cmb_mahh_TK);
            this.groupBox1.Controls.Add(this.cmb_loaihh_TK);
            this.groupBox1.Controls.Add(this.btn_Clear);
            this.groupBox1.Controls.Add(this.btn_Excel);
            this.groupBox1.Controls.Add(this.Label11);
            this.groupBox1.Controls.Add(this.btn_Search);
            this.groupBox1.Controls.Add(this.cmb_kho_TK);
            this.groupBox1.Controls.Add(this.Label21);
            this.groupBox1.Location = new System.Drawing.Point(7, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(951, 107);
            this.groupBox1.TabIndex = 221;
            this.groupBox1.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(752, 15);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 19);
            this.label12.TabIndex = 224;
            this.label12.Text = "NCC";
            // 
            // cmb_ncc_TK
            // 
            this.cmb_ncc_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_ncc_TK.DropDownHeight = 150;
            this.cmb_ncc_TK.DropDownWidth = 100;
            this.cmb_ncc_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_ncc_TK.FormattingEnabled = true;
            this.cmb_ncc_TK.IntegralHeight = false;
            this.cmb_ncc_TK.Location = new System.Drawing.Point(672, 37);
            this.cmb_ncc_TK.Name = "cmb_ncc_TK";
            this.cmb_ncc_TK.Size = new System.Drawing.Size(200, 27);
            this.cmb_ncc_TK.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(510, 15);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 19);
            this.label10.TabIndex = 222;
            this.label10.Text = "Tên HH";
            // 
            // cmb_tenhh_TK
            // 
            this.cmb_tenhh_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_tenhh_TK.DropDownHeight = 500;
            this.cmb_tenhh_TK.DropDownWidth = 100;
            this.cmb_tenhh_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_tenhh_TK.FormattingEnabled = true;
            this.cmb_tenhh_TK.IntegralHeight = false;
            this.cmb_tenhh_TK.Location = new System.Drawing.Point(430, 37);
            this.cmb_tenhh_TK.Name = "cmb_tenhh_TK";
            this.cmb_tenhh_TK.Size = new System.Drawing.Size(236, 27);
            this.cmb_tenhh_TK.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(334, 15);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 19);
            this.label9.TabIndex = 220;
            this.label9.Text = "Mã HH";
            // 
            // cmb_mahh_TK
            // 
            this.cmb_mahh_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_mahh_TK.DropDownHeight = 500;
            this.cmb_mahh_TK.DropDownWidth = 100;
            this.cmb_mahh_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_mahh_TK.FormattingEnabled = true;
            this.cmb_mahh_TK.IntegralHeight = false;
            this.cmb_mahh_TK.Location = new System.Drawing.Point(322, 37);
            this.cmb_mahh_TK.Name = "cmb_mahh_TK";
            this.cmb_mahh_TK.Size = new System.Drawing.Size(99, 27);
            this.cmb_mahh_TK.TabIndex = 12;
            this.cmb_mahh_TK.SelectedIndexChanged += new System.EventHandler(this.cmb_mahh_TK_SelectedIndexChanged);
            // 
            // cmb_loaihh_TK
            // 
            this.cmb_loaihh_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_loaihh_TK.DropDownHeight = 100;
            this.cmb_loaihh_TK.DropDownWidth = 200;
            this.cmb_loaihh_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_loaihh_TK.FormattingEnabled = true;
            this.cmb_loaihh_TK.IntegralHeight = false;
            this.cmb_loaihh_TK.Location = new System.Drawing.Point(112, 37);
            this.cmb_loaihh_TK.Name = "cmb_loaihh_TK";
            this.cmb_loaihh_TK.Size = new System.Drawing.Size(197, 27);
            this.cmb_loaihh_TK.TabIndex = 11;
            // 
            // btn_Clear
            // 
            this.btn_Clear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clear.ForeColor = System.Drawing.Color.Blue;
            this.btn_Clear.Location = new System.Drawing.Point(753, 74);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(91, 27);
            this.btn_Clear.TabIndex = 16;
            this.btn_Clear.Text = "Xóa trắng";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Excel
            // 
            this.btn_Excel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Excel.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn_Excel.Location = new System.Drawing.Point(850, 73);
            this.btn_Excel.Name = "btn_Excel";
            this.btn_Excel.Size = new System.Drawing.Size(75, 27);
            this.btn_Excel.TabIndex = 17;
            this.btn_Excel.Text = "Excel";
            this.btn_Excel.UseVisualStyleBackColor = true;
            this.btn_Excel.Click += new System.EventHandler(this.btn_Excel_Click);
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.ForeColor = System.Drawing.Color.Blue;
            this.Label11.Location = new System.Drawing.Point(19, 15);
            this.Label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(36, 19);
            this.Label11.TabIndex = 218;
            this.Label11.Text = "Kho";
            // 
            // btn_Search
            // 
            this.btn_Search.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.Color.Blue;
            this.btn_Search.Location = new System.Drawing.Point(672, 74);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(75, 27);
            this.btn_Search.TabIndex = 15;
            this.btn_Search.Text = "Tìm kiếm";
            this.btn_Search.UseVisualStyleBackColor = true;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // cmb_kho_TK
            // 
            this.cmb_kho_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_kho_TK.DropDownHeight = 100;
            this.cmb_kho_TK.DropDownWidth = 100;
            this.cmb_kho_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_kho_TK.FormattingEnabled = true;
            this.cmb_kho_TK.IntegralHeight = false;
            this.cmb_kho_TK.Location = new System.Drawing.Point(7, 37);
            this.cmb_kho_TK.Name = "cmb_kho_TK";
            this.cmb_kho_TK.Size = new System.Drawing.Size(99, 27);
            this.cmb_kho_TK.TabIndex = 10;
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label21.ForeColor = System.Drawing.Color.Blue;
            this.Label21.Location = new System.Drawing.Point(148, 15);
            this.Label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(94, 19);
            this.Label21.TabIndex = 217;
            this.Label21.Text = "Loại hàng hóa";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(351, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 24);
            this.label1.TabIndex = 223;
            this.label1.Text = "MH ";
            // 
            // dgv_Data
            // 
            this.dgv_Data.AllowUserToAddRows = false;
            this.dgv_Data.AllowUserToDeleteRows = false;
            this.dgv_Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Data.Location = new System.Drawing.Point(7, 150);
            this.dgv_Data.Name = "dgv_Data";
            this.dgv_Data.RowHeadersVisible = false;
            this.dgv_Data.RowTemplate.Height = 21;
            this.dgv_Data.Size = new System.Drawing.Size(951, 339);
            this.dgv_Data.TabIndex = 234;
            this.dgv_Data.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Data_CellDoubleClick);
            this.dgv_Data.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Data_ColumnHeaderMouseClick);
            // 
            // frm_m_buhin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(961, 686);
            this.Controls.Add(this.dgv_Data);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "frm_m_buhin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MH MASTER HANG HOA";
            this.Load += new System.EventHandler(this.frm_m_buhin_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Data)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmb_loaihh;
        internal System.Windows.Forms.Label label5;
        internal System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmb_kho;
        private System.Windows.Forms.LinkLabel txt_excelmau;
        private System.Windows.Forms.Button btn_Import;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_Delete;
        private System.Windows.Forms.Button btn_Save;
        internal System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_tenhh;
        internal System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_sodong;
        internal System.Windows.Forms.Label Label15;
        private System.Windows.Forms.TextBox txt_mahh;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmb_loaihh_TK;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_Excel;
        internal System.Windows.Forms.Label Label11;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.ComboBox cmb_kho_TK;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_ghichu;
        internal System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmb_ncc;
        internal System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmb_dvt;
        internal System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cmb_ncc_TK;
        internal System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmb_tenhh_TK;
        internal System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmb_mahh_TK;
        private System.Windows.Forms.DataGridView dgv_Data;
    }
}

