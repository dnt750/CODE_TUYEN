﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frm_nhapkho
{
    public partial class frm_nhapkho : Form
    {
        public frm_nhapkho()
        {
            InitializeComponent();
        }
        #region khaibao
        DataProvider _cn = new DataProvider();
        DataSet _ds = new DataSet();
        DataTable _dt_data = new DataTable();
        DataSet _ds_datetime = new DataSet();

        DataSet _ds_kho = new DataSet();
        DataSet _ds_loaihh = new DataSet();
        DataSet _ds_dvt = new DataSet();
        DataSet _ds_ncc = new DataSet();
        DataSet _ds_tenhh = new DataSet();
        DataSet _ds_mahh = new DataSet();
        string DATE_FORMAT = "yyyy/MM/dd";
        string DATE_FORMAT_H = "yyyy/MM/dd HH:mm:ss";
        string _d_sysdate = string.Empty;
        string _d_sysdate_time = string.Empty;
        string c_yyyyMMdd = string.Empty;

        string _const_type_kho = "01";
        string _const_type_loaihh = "02";
        string _const_type_dvt = "03";
        string _const_type_bophan = "05";
        int _flagupdate = 0;
        int _flagfrom = 0;
        string _msnv = string.Empty;
        #endregion khaibao


        private void Loaddata()
        {

            string _sql = string.Empty;
            _sql = "SELECT to_char(t.d_input,  'YYYY/MM/DD HH24:MI:ss') d_input, to_char(d_p_nhapkho, 'yyyy/MM/dd') d_p_nhapkho, "
                    + " c_mabx, c_sophieu_nk, l_stt, c_mahh, c_tenhh, c_dvt,  c_solot,"
            + "  l_sl, l_sl_order, l_sl_hoan, l_sl_haohut, c_kho,m1.c_item c_item1,   c_loaihh, m2.c_item  c_item2,  "
            + " t.c_mancc c_mancc, m3.c_tenncc c_tenncc , c_soinvoice, c_note, c_msnv_nguoinhan, m4.c_hoten "
            + " FROM t_nhapkho t left join  m_common m1 on t.c_kho = m1.c_type || ':' ||m1.c_ma and m1.c_type = '" + _const_type_kho + "' "
            + " left join  m_common m2 on t.c_loaihh = m2.c_type || ':' ||m2.c_ma and m2.c_type =  '" + _const_type_loaihh + "' "
            + " left join m_ncc m3 on t.c_mancc = m3.c_mancc "
            + " left join m_nhanvien m4 on t.c_msnv_nguoinhan = m4.c_msnv ";
            _ds = new DataSet();

            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                _dt_data = _ds.Tables[0];

            }
            else
            {
                _dt_data = _ds.Tables[0];
            }
            //
            _sql = string.Empty;
            //        SELECT To_char(CURRENT_DATE, 'yyyy/MM/dd') as DT_SYSDATE, 
            //to_char(CURRENT_TIMESTAMP,  'yyyy/MM/dd HH24:mm:ss') as DT_SYSDATETIME
            _sql = " SELECT To_char(CURRENT_DATE, 'yyyy/MM/dd') as DT_SYSDATE, "
                + "  To_char(CURRENT_DATE, 'yyyyMMdd') as C_SYSDATE, "
                 + " to_char(CURRENT_TIMESTAMP,  'yyyy/MM/dd HH24:mm:ss') as DT_SYSDATETIME ";
            _ds_datetime = _cn.Get_ds_CommandSQL(_sql);
            if (_ds_datetime.Tables[0].Rows.Count > 0)
            {
                _d_sysdate = _ds_datetime.Tables[0].Rows[0]["DT_SYSDATE"].ToString();
                c_yyyyMMdd = _ds_datetime.Tables[0].Rows[0]["C_SYSDATE"].ToString();
                _d_sysdate_time = _ds_datetime.Tables[0].Rows[0]["DT_SYSDATETIME"].ToString();
            }

        }

        #region createGrid
        private void FormatGrid()
        {
            dgv_Data.EnableHeadersVisualStyles = false;
            dgv_Data.Font = new Font("Times New Roman", 10, FontStyle.Regular);
            dgv_Data.EnableHeadersVisualStyles = false;
            dgv_Data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgv_Data.ColumnHeadersHeight = 45;
            dgv_Data.BorderStyle = BorderStyle.Fixed3D;
            DataGridViewCellStyle styleHeader = new DataGridViewCellStyle();

            styleHeader.Font = new Font("Times New Roman", 10, FontStyle.Bold);
            styleHeader.ForeColor = Color.Blue;
            styleHeader.Alignment = DataGridViewContentAlignment.MiddleCenter;

            for (int i = 0; i < dgv_Data.Columns.Count; i++)
            {
                dgv_Data.Columns[i].HeaderCell.Style = styleHeader;
                // dgv_Data.Columns[i].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }

        }

        private void createGrid()
        {

            //to_char(d_p_nhapkho, 'yyyy/MM/dd') d_p_nhapkho, c_item_kho, c_item_loaihh , 
            //   c_mahh, c_tenhh, c_sophieu_nk, c_solot,  l_sl_order,  l_sl, c_dvt, m3.c_tenncc c_tenncc, c_soinvoice, m4.c_hoten c_hoten,           
            //c_note, l_sl_hoan, l_sl_haohut,         
            //c_msnv, to_char(t.d_input,  'YYYY/MM/DD HH24:MI:ss') d_input ,  to_char(t.d_date,  'YYYY/MM/DD HH24:MI:ss') d_date, 
            // c_bophan, c_mabx, l_stt,
            ////c_kho, c_loaihh,   c_mancc, c_msnv_nguoinhan, c_solot_all     

            dgv_Data.Rows.Clear();
            dgv_Data.Columns.Clear();
            dgv_Data.DataSource = null;

            DataGridViewCheckBoxColumn colCheck = new DataGridViewCheckBoxColumn();
            colCheck.Name = "check";
            dgv_Data.Columns.Add(colCheck);
            dgv_Data.Columns[0].HeaderText = "Check";
            dgv_Data.Columns[0].Width = 48;

            dgv_Data.Columns.Add("d_p_nhapkho", "Ngày");
            dgv_Data.Columns[1].Width = 90;
            dgv_Data.Columns[1].ReadOnly = true;
            dgv_Data.Columns[1].DataPropertyName = "d_p_nhapkho";
            dgv_Data.Columns[1].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_item_kho", "Kho");
            dgv_Data.Columns[2].Width = 50;
            dgv_Data.Columns[2].ReadOnly = true;
            dgv_Data.Columns[2].DataPropertyName = "c_item_kho";
            dgv_Data.Columns[2].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_item_loaihh", "Loại hàng hóa");
            dgv_Data.Columns[3].Width = 122;
            dgv_Data.Columns[3].ReadOnly = true;
            dgv_Data.Columns[3].DataPropertyName = "c_item_loaihh";
            dgv_Data.Columns[3].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_mahh", "MãHH");
            dgv_Data.Columns[4].Width = 78;
            dgv_Data.Columns[4].ReadOnly = true;
            dgv_Data.Columns[4].DataPropertyName = "c_mahh";
            dgv_Data.Columns[4].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_tenhh", "TênHH");
            dgv_Data.Columns[5].Width = 210;
            dgv_Data.Columns[5].ReadOnly = true;
            dgv_Data.Columns[5].DataPropertyName = "c_tenhh";
            dgv_Data.Columns[5].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_sophieu_nk", "Số phiếu");
            dgv_Data.Columns[6].Width = 70;
            dgv_Data.Columns[6].ReadOnly = true;
            dgv_Data.Columns[6].DataPropertyName = "c_sophieu_nk";
            dgv_Data.Columns[6].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_solot", "Số lot");
            dgv_Data.Columns[7].Width = 65;
            dgv_Data.Columns[7].ReadOnly = true;
            dgv_Data.Columns[7].DataPropertyName = "c_solot";
            dgv_Data.Columns[7].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("l_sl_order", "SL invoice");
            dgv_Data.Columns[8].Width = 70;
            dgv_Data.Columns[8].ReadOnly = true;
            dgv_Data.Columns[8].DataPropertyName = "l_sl_order";
            dgv_Data.Columns[8].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgv_Data.Columns.Add("l_sl", "Số lượng");
            dgv_Data.Columns[9].Width = 70;
            dgv_Data.Columns[9].ReadOnly = true;
            dgv_Data.Columns[9].DataPropertyName = "l_sl";
            dgv_Data.Columns[9].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgv_Data.Columns.Add("c_dvt", "ĐVT");
            dgv_Data.Columns[10].Width = 50;
            dgv_Data.Columns[10].ReadOnly = true;
            dgv_Data.Columns[10].DataPropertyName = "c_dvt";
            dgv_Data.Columns[10].DefaultCellStyle.BackColor = Color.LightGray;
       
            dgv_Data.Columns.Add("c_tenncc", "NCC");
            dgv_Data.Columns[11].Width = 110;
            dgv_Data.Columns[11].ReadOnly = true;
            dgv_Data.Columns[11].DataPropertyName = "c_tenncc";
            dgv_Data.Columns[11].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_soinvoice", "Số invoice");
            dgv_Data.Columns[12].Width = 110;
            dgv_Data.Columns[12].ReadOnly = true;
            dgv_Data.Columns[12].DataPropertyName = "c_soinvoice";
            dgv_Data.Columns[12].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_hoten", "Người nhận");
            dgv_Data.Columns[13].Width = 130;
            dgv_Data.Columns[13].ReadOnly = true;
            dgv_Data.Columns[13].DataPropertyName = "c_hoten";
            dgv_Data.Columns[13].DefaultCellStyle.BackColor = Color.LightGray;
          
            dgv_Data.Columns.Add("c_note", "Ghi chú");
            dgv_Data.Columns[14].Width = 120;
            dgv_Data.Columns[14].ReadOnly = true;
            dgv_Data.Columns[14].DataPropertyName = "c_note";
            dgv_Data.Columns[14].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("l_sl_hoan", "SL hoàn");
            dgv_Data.Columns[15].Width = 60;
            dgv_Data.Columns[15].ReadOnly = true;
            dgv_Data.Columns[15].DataPropertyName = "l_sl_hoan";
            dgv_Data.Columns[15].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[15].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgv_Data.Columns.Add("l_sl_haohut", "SL hao hụt");
            dgv_Data.Columns[16].Width = 60;
            dgv_Data.Columns[16].ReadOnly = true;
            dgv_Data.Columns[16].DataPropertyName = "l_sl_haohut";
            dgv_Data.Columns[16].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[16].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgv_Data.Columns.Add("c_msnv", "Người nhập");
            dgv_Data.Columns[17].Width = 90;
            dgv_Data.Columns[17].ReadOnly = true;
            dgv_Data.Columns[17].DataPropertyName = "c_msnv";
            dgv_Data.Columns[17].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("d_input", "Ngày xử lý");
            dgv_Data.Columns[18].Width = 160;
            dgv_Data.Columns[18].ReadOnly = true;
            dgv_Data.Columns[18].DataPropertyName = "d_input";
            dgv_Data.Columns[18].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("d_date", "Ngày cập nhật");
            dgv_Data.Columns[19].Width = 160;
            dgv_Data.Columns[19].ReadOnly = true;
            dgv_Data.Columns[19].DataPropertyName = "d_date";
            dgv_Data.Columns[19].DefaultCellStyle.BackColor = Color.LightGray;

            dgv_Data.Columns.Add("c_bophan", "SL c_bophan");
            dgv_Data.Columns[20].Width = 50;
            dgv_Data.Columns[20].ReadOnly = true;
            dgv_Data.Columns[20].DataPropertyName = "c_bophan";
            dgv_Data.Columns[20].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[20].Visible = false;
  
            dgv_Data.Columns.Add("c_mabx", "Mã BX");
            dgv_Data.Columns[21].Width = 50;
            dgv_Data.Columns[21].ReadOnly = true;
            dgv_Data.Columns[21].DataPropertyName = "c_mabx";
            dgv_Data.Columns[21].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[21].Visible = false;

            dgv_Data.Columns.Add("l_stt", "STT");
            dgv_Data.Columns[22].Width = 50;
            dgv_Data.Columns[22].ReadOnly = true;
            dgv_Data.Columns[22].DataPropertyName = "l_stt";
            dgv_Data.Columns[22].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[22].Visible = false;

            dgv_Data.Columns.Add("c_kho", "c_kho");
            dgv_Data.Columns[23].Width = 50;
            dgv_Data.Columns[23].ReadOnly = true;
            dgv_Data.Columns[23].DataPropertyName = "c_kho";
            dgv_Data.Columns[23].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[23].Visible = false;

            dgv_Data.Columns.Add("c_loaihh", "c_loaihh");
            dgv_Data.Columns[24].Width = 50;
            dgv_Data.Columns[24].ReadOnly = true;
            dgv_Data.Columns[24].DataPropertyName = "c_loaihh";
            dgv_Data.Columns[24].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[24].Visible = false;

            dgv_Data.Columns.Add("c_mancc", "c_mancc");
            dgv_Data.Columns[25].Width = 50;
            dgv_Data.Columns[25].ReadOnly = true;
            dgv_Data.Columns[25].DataPropertyName = "c_mancc";
            dgv_Data.Columns[25].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[25].Visible = false;

            dgv_Data.Columns.Add("c_msnv_nguoinhan", "MSNV nhận");
            dgv_Data.Columns[26].Width = 50;
            dgv_Data.Columns[26].ReadOnly = true;
            dgv_Data.Columns[26].DataPropertyName = "c_msnv_nguoinhan";
            dgv_Data.Columns[26].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[26].Visible = false;

            dgv_Data.Columns.Add("c_solot_all", "c_solot_all");
            dgv_Data.Columns[27].Width = 50;
            dgv_Data.Columns[27].ReadOnly = true;
            dgv_Data.Columns[27].DataPropertyName = "c_solot_all";
            dgv_Data.Columns[27].DefaultCellStyle.BackColor = Color.LightGray;
            dgv_Data.Columns[27].Visible = false;

            FormatGrid();

        }

        #endregion createGrid
   
        #region loadcombobox
                private void Loadcombobox_MaHH()
                {
                    string _mahh = string.Empty;

                    if (cmb_tenhh.Text != "")
                    {
                        _mahh = cmb_tenhh.SelectedValue.ToString();
                    }
                    else
                    {
                        _mahh = string.Empty;
                    }

                    string _sql = string.Empty;
                    _sql = string.Empty;
                    _sql = "SELECT distinct c_mahh, c_dvt FROM m_hanghoa   where 1=1 and ";
                    _sql = _sql + " c_mahh like '%" + _mahh + "%' ";
                    _sql = _sql + "order by c_mahh ";

                    _ds_mahh = _cn.Get_ds_CommandSQL(_sql);
                    if (_ds_mahh.Tables[0].Rows.Count > 0)
                    {

                        DataRow row = _ds_mahh.Tables[0].NewRow();
                        _ds_mahh.Tables[0].Rows.InsertAt(row, 0);
                        cmb_mahh.DataSource = _ds_mahh.Tables[0];
                        cmb_mahh.DisplayMember = "c_mahh";
                        cmb_mahh.ValueMember = "c_mahh";

                        if (_ds_mahh.Tables[0].Rows.Count == 2)
                        {
                            txt_dvt.Text = _ds_mahh.Tables[0].Rows[1]["c_dvt"].ToString();
                            cmb_mahh.Text = _ds_mahh.Tables[0].Rows[1]["c_mahh"].ToString();
                        }
                    }

                }

                private void Loadcombobox_TenHH()
                {

                    string _sql = string.Empty;
                    _sql = string.Empty;
                    _sql = " SELECT distinct c_tenhh, c_mahh , c_dvt from m_hanghoa "
                        //   + " where c_type =   '" + _const_type_dvt + "'  "
                      + "ORDER BY c_tenhh ";

                    _ds_tenhh = _cn.Get_ds_CommandSQL(_sql);
                    if (_ds_tenhh.Tables[0].Rows.Count > 0)
                    {

                        DataRow row = _ds_tenhh.Tables[0].NewRow();
                        _ds_tenhh.Tables[0].Rows.InsertAt(row, 0);
                        cmb_tenhh.DataSource = _ds_tenhh.Tables[0];
                        cmb_tenhh.DisplayMember = "c_tenhh";
                        cmb_tenhh.ValueMember = "c_mahh";

                    }

                }

                private void Loadcombobox_Kho_LoaiHH_NCC()
                {
                    //cmb_kho
                    string _mahh = string.Empty;

                    if (cmb_tenhh.Text != "")
                    {
                        _mahh = cmb_tenhh.SelectedValue.ToString();
                    }
                    else
                    {
                        _mahh = string.Empty;
                    }

                    string _sql = string.Empty;
                    _sql = " SELECT distinct c_item, m.c_type_kho || ':' || m.c_ma1 as c_kho, m.c_ma1, m.c_type_kho  FROM m_hanghoa m  "
                        + " left join m_common m1 on m.c_type_kho = m1.c_type and m.c_ma1 = m1.c_ma    "
                      + " where  m.c_type_kho =   '" + _const_type_kho + "'  "
                      + " and m.c_mahh like  '%" + _mahh + "%'  "
                      + "ORDER BY c_item ";
                    //SELECT distinct c_item, m.c_type_kho || ':' || m.c_ma1 as c_kho, m.c_ma1, m.c_type_kho 
                    //FROM m_hanghoa m   left join m_common m1 on m.c_type_kho = m1.c_type 
                    //and m.c_ma1 = m1.c_ma  where  m.c_type_kho =   '01'  
                    //and m.c_mahh like  '%HH00023%'  ORDER BY c_item 

                    _ds_kho = _cn.Get_ds_CommandSQL(_sql);
                    if (_ds_kho.Tables[0].Rows.Count > 0)
                    {
                        DataRow row = _ds_kho.Tables[0].NewRow();
                        _ds_kho.Tables[0].Rows.InsertAt(row, 0);
                        cmb_kho.DataSource = _ds_kho.Tables[0];
                        cmb_kho.DisplayMember = "c_item";
                        cmb_kho.ValueMember = "c_kho";
                    }

                    //cmb_loaihh
                    _sql = string.Empty;
                    _sql = " SELECT distinct c_item, m.c_type_loaihh || ':' || m.c_ma2 as c_loaihh, m.c_ma2, m.c_type_loaihh  FROM m_hanghoa m  "
                         + " left join m_common m1 on m.c_type_loaihh = m1.c_type and m.c_ma2 = m1.c_ma    "
                       + " where  m.c_type_loaihh =   '" + _const_type_loaihh + "'  "
                       + " and m.c_mahh like  '%" + _mahh + "%'  "
                       + "ORDER BY c_item ";
                    //SELECT distinct c_item, m.c_type_loaihh || ':' || m.c_ma2 as c_kho,  m.c_ma2, m.c_type_loaihh 
                    // FROM m_hanghoa m   left join m_common m1 on m.c_type_loaihh = m1.c_type 
                    // and m.c_ma2 = m1.c_ma  where  m.c_type_loaihh =   '02'  
                    // and m.c_mahh like  '%HH00023%'  ORDER BY c_item 

                    _ds_loaihh = _cn.Get_ds_CommandSQL(_sql);
                    if (_ds_loaihh.Tables[0].Rows.Count > 0)
                    {
                        DataRow row = _ds_loaihh.Tables[0].NewRow();
                        _ds_loaihh.Tables[0].Rows.InsertAt(row, 0);
                        cmb_loaihh.DataSource = _ds_loaihh.Tables[0];
                        cmb_loaihh.DisplayMember = "c_item";
                        cmb_loaihh.ValueMember = "c_loaihh";
                    }

                    //cmb_ncc

                    _sql = string.Empty;
                    _sql = " SELECT distinct m.c_mancc c_mancc, m.c_tenncc c_tenncc "
                         + " FROM m_hanghoa m  left join m_ncc m1 on m.c_mancc = m1.c_mancc  "
                       + " where m.c_mahh like  '%" + _mahh + "%'  "
                       + " ORDER BY c_tenncc ";
                    //      SELECT distinct m.c_mancc c_mancc, m.c_tenncc c_tenncc 
                    //FROM m_hanghoa m  left join m_ncc m1 on m.c_mancc = m1.c_mancc  
                    //    where m.c_mahh like  '%" + _mahh + "%' 
                    //        ORDER BY c_tenncc
                    _ds_ncc = _cn.Get_ds_CommandSQL(_sql);
                    if (_ds_ncc.Tables[0].Rows.Count > 0)
                    {
                        DataRow row = _ds_ncc.Tables[0].NewRow();
                        _ds_ncc.Tables[0].Rows.InsertAt(row, 0);
                        cmb_ncc.DataSource = _ds_ncc.Tables[0];
                        cmb_ncc.DisplayMember = "c_tenncc";
                        cmb_ncc.ValueMember = "c_mancc";
                    }
                }

                private void Loadcombobox_nguoinhan()
                {
                    string _sql = string.Empty;
                    _sql = " select c_msnv, c_hoten FROM m_nhanvien "
                         + " where c_flag = '1' ORDER BY c_msnv ASC  ";

                    DataSet _ds = _cn.Get_ds_CommandSQL(_sql);
                    if (_ds.Tables[0].Rows.Count > 0)
                    {
                        DataRow row = _ds.Tables[0].NewRow();
                        _ds.Tables[0].Rows.InsertAt(row, 0);
                        cmb_nguoinhan.DataSource = _ds.Tables[0];
                        cmb_nguoinhan.DisplayMember = "c_hoten";
                        cmb_nguoinhan.ValueMember = "c_msnv";
                    }
                }

                private void Loadcombox()
                {
                    Loadcombobox_TenHH();
                    Loadcombobox_MaHH();
                    Loadcombobox_Kho_LoaiHH_NCC();
                    Loadcombobox_nguoinhan();
                }
        #endregion loadcombobox
      
        #region loadcombobox TK

        private void Combobox_Kho_TK()
        {
 
            string _sql = string.Empty;
            //           SELECT distinct c_kho,m2.c_item,  m2.c_type, m2.c_ma 
            //FROM t_nhapkho m1  left join m_common m2
            //on m2.c_type || ':' || m2.c_ma = c_kho and m2.c_type = '01'  ORDER BY c_kho

            _sql = "    SELECT distinct c_kho, m2.c_item  c_item ,  m2.c_type c_type, m2.c_ma c_ma "
                + " FROM t_nhapkho m1  left join m_common m2 "
              + " on m2.c_type || ':' || m2.c_ma = c_kho and m2.c_type = '" + _const_type_kho + "'  "
              + " ORDER BY c_kho ";

            DataSet _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds.Tables[0].NewRow();
                _ds.Tables[0].Rows.InsertAt(row, 0);
                cmb_kho_TK.DataSource = _ds.Tables[0];
                cmb_kho_TK.DisplayMember = "c_item";
                cmb_kho_TK.ValueMember = "c_kho";
            }
        }

        private void Combobox_LoaiHH_TK()
        {
            string _sql = string.Empty;

            //SELECT distinct c_loaihh,m2.c_item,  m2.c_type, m2.c_ma 
            //FROM t_nhapkho m1  left join m_common m2
            //on m2.c_type || ':' || m2.c_ma = c_loaihh and m2.c_type = '02' 
            //ORDER BY c_loaihh
            _sql = "    SELECT  distinct c_loaihh, m2.c_item c_item,  m2.c_type, m2.c_ma  "
                + " FROM t_nhapkho m1  left join m_common m2 "
              + " on m2.c_type || ':' || m2.c_ma = c_loaihh and m2.c_type = '" + _const_type_loaihh + "'  "
              + " ORDER BY c_loaihh ";
            DataSet _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds.Tables[0].NewRow();
                _ds.Tables[0].Rows.InsertAt(row, 0);
                cmb_loaihh_TK.DataSource = _ds.Tables[0];
                cmb_loaihh_TK.DisplayMember = "c_item";
                cmb_loaihh_TK.ValueMember = "c_loaihh";
            }

        }

        private void Combobox_MaHH_TK()
        {
            string _sql = string.Empty;
            //      SELECT distinct  c_mahh
            //FROM m_hanghoa order by c_mahh
            _sql = "   SELECT distinct  t.c_mahh c_mahh"
                + " FROM t_nhapkho t  left join m_hanghoa m "
                + "on t.c_mahh = m.c_mahh  order by c_mahh ";

            DataSet _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds.Tables[0].NewRow();
                _ds.Tables[0].Rows.InsertAt(row, 0);
                cmb_mahh_TK.DataSource = _ds.Tables[0];
                cmb_mahh_TK.DisplayMember = "c_mahh";
                cmb_mahh_TK.ValueMember = "c_mahh";
            }

        }

        private void Combobox_TenHH_TK()
        {
            string _mahh = string.Empty;

            if (cmb_mahh_TK.Text != "")
            {
                _mahh = cmb_mahh_TK.SelectedValue.ToString();
            }
            else
            {
                _mahh = cmb_mahh_TK.Text;
            }

            string _sql = string.Empty;
            _sql = string.Empty;
            _sql = "SELECT distinct c_tenhh,  c_mahh  FROM t_nhapkho   where 1=1 and ";
            _sql = _sql + "c_mahh like '" + _mahh + "%' ";
            _sql = _sql + "order by c_tenhh ";

            DataSet ds1 = new DataSet();
            ds1 = _cn.Get_ds_CommandSQL(_sql);
            if (ds1.Tables[0].Rows.Count > 0)
            {

                DataRow row = ds1.Tables[0].NewRow();
                ds1.Tables[0].Rows.InsertAt(row, 0);
                cmb_tenhh_TK.DataSource = ds1.Tables[0];
                cmb_tenhh_TK.DisplayMember = "c_tenhh";
                cmb_tenhh_TK.ValueMember = "c_mahh";
            }


        }


        private void Combobox_NCC_TK()
        {
            string _sql = string.Empty;
            //   SELECT distinct  t.c_mancc c_mancc, m.c_tenncc c_tenncc  FROM t_nhapkho t left join m_ncc m  
            //on t.c_mancc = m.c_mancc  order by c_tenncc
            _sql = "   SELECT distinct  t.c_mancc c_mancc, m.c_tenncc c_tenncc"
                + " FROM t_nhapkho t left join m_ncc m  "
                + " on t.c_mancc = m.c_mancc  order by c_tenncc ";

            DataSet _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds.Tables[0].NewRow();
                _ds.Tables[0].Rows.InsertAt(row, 0);
                cmb_ncc_TK.DataSource = _ds.Tables[0];
                cmb_ncc_TK.DisplayMember = "c_tenncc";
                cmb_ncc_TK.ValueMember = "c_mancc";
            }

        }

        private void Combobox_Solot_TK()
        {
            string _sql = string.Empty;
          
            _sql = "   SELECT distinct  c_solot "
                + " FROM t_nhapkho t  order by c_solot ";           

            DataSet _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds.Tables[0].NewRow();
                _ds.Tables[0].Rows.InsertAt(row, 0);
                cmb_solot_TK.DataSource = _ds.Tables[0];
                cmb_solot_TK.DisplayMember = "c_solot";
                cmb_solot_TK.ValueMember = "c_solot";
            }

        }

        private void Combobox_SophieuNK_TK()
        {
            string _sql = string.Empty;
        
            _sql = "   SELECT distinct  c_sophieu_nk "
                + " FROM t_nhapkho t  order by c_sophieu_nk ";

            DataSet _ds = new DataSet();
            _ds = _cn.Get_ds_CommandSQL(_sql);
            if (_ds.Tables[0].Rows.Count > 0)
            {
                DataRow row = _ds.Tables[0].NewRow();
                _ds.Tables[0].Rows.InsertAt(row, 0);
                cmb_sophieu_TK.DataSource = _ds.Tables[0];
                cmb_sophieu_TK.DisplayMember = "c_sophieu_nk";
                cmb_sophieu_TK.ValueMember = "c_sophieu_nk";
            }

        }

        private void Loadcombox_TK()
        {
            Combobox_Kho_TK();
            Combobox_LoaiHH_TK();
            Combobox_MaHH_TK();
            Combobox_TenHH_TK();
            Combobox_NCC_TK();

            Combobox_Solot_TK();
            Combobox_SophieuNK_TK();

        }
        #endregion loadcombobox TK

    
   //// select distinct to_char(date_trunc('month', d_p_nhapkho)::date, 'yyyy/MM/dd') AS d_dauthang,
   //// to_char(d_p_nhapkho,'yyyy/MM/dd')d_p_nhapkho,
   ////to_char(  (date_trunc('month', d_p_nhapkho) + interval '1 month - 1 day')::date  ,'yyyy/MM/dd') AS d_cuoithang
   ////     FROM t_nhapkho

        private void frm_nhapkho_Load(object sender, EventArgs e)
        {
            createGrid();
            Loaddata();
            Loadcombox();
            Loadcombox_TK();        
            _flagfrom = 1;
            msk_ngayPNK.Text = _d_sysdate;
            
        }

        #region event_SelectedIndexChanged

        private void cmb_tenhh_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_flagfrom == 1)
            {

                Loadcombobox_Kho_LoaiHH_NCC();

                cmb_mahh.Text = string.Empty;
                txt_dvt.Text = string.Empty;
                if (cmb_mahh.Text == string.Empty || cmb_mahh.Text == "")
                {

                    Loadcombobox_MaHH();

                }
                cmb_kho.Focus();

            }
        }

        private void cmb_kho_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_flagfrom == 1)
            {
                cmb_loaihh.Focus();
            }
        }

        private void cmb_loaihh_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_flagfrom == 1)
            {
                txt_sl_nhap.Focus();

            }
        }
        private void cmb_ncc_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_flagfrom == 1)
            {
                cmb_nguoinhan.Focus();

            }
        }


        #endregion event_SelectedIndexChanged
     

    
     
        #region eventkey
        private void txt_sl_nhap_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;

            }
            else
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    if (txt_sl_nhap.Text == "")
                    {
                        MessageBox.Show("Chưa nhập " + label29.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                        txt_sl_invoice.Text = txt_sl_nhap.Text;

                        txt_solot.Focus();
                    }
                }
            }
        }

        private void txt_sophieu_NK_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (txt_sophieu_NK.Text == "")
                {
                    MessageBox.Show("Chưa nhập " + label18.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    txt_soinvoice.Focus();
                }
            }
        }

        private void txt_solot_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (txt_solot.Text == "")
                {
                    MessageBox.Show("Chưa nhập " + label17.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    txt_sophieu_NK.Focus();
                }
            }
        }

        private void txt_soinvoice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (txt_soinvoice.Text == "")
                {
                    MessageBox.Show("Chưa nhập " + label33.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else
                {
                    cmb_ncc.Focus();
                }
            }
        }


        private void txt_sl_haohut_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;

            }
            else
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    if (txt_sl_haohut.Text != "")
                    {
                        txt_sl_hoan.Focus();
                    }
                }

            }
        }

        private void txt_sl_hoan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;

            }
            else
            {
                if (e.KeyChar == (char)Keys.Enter)
                {
                    if (txt_sl_hoan.Text == "")
                    {
                        MessageBox.Show("Chưa nhập " + label30.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                }

            }
        }
        #endregion eventkey

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public static bool Date(object _strDate)
        {
            DateTime _d;
            bool _check = DateTime.TryParse(_strDate.ToString(), out _d);
            return _check;
        }

       
        private bool CheckdataInput()
        {

            if (msk_ngayPNK.Text != "    /  /")
            {
                ///kiem tra dung dinh dạng ngay + ngày ko dc nho hơn ngay hien tai
                if (Date(msk_ngayPNK.Text) == true)
                {

                    DateTime d_sysdate = DateTime.Parse(_d_sysdate);
                    DateTime d_input = DateTime.Parse(msk_ngayPNK.Text);
                    int compare = DateTime.Compare(d_sysdate, d_input);
                    TimeSpan diff = d_input - d_sysdate;
                    if (diff.Days > 0)
                    {
                        MessageBox.Show("Ngày nhập không được > ngày hiện tại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        msk_ngayPNK.Text = string.Empty;
                        msk_ngayPNK.Focus();
                        return false;
                    }
                  
                }

            }
            else
            {
                MessageBox.Show("Ngày không được để trống", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (cmb_tenhh.Text == "")
            {
                MessageBox.Show("Chưa chọn " + label26.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (cmb_mahh.Text == "")
            {
                MessageBox.Show("Chưa chọn " + label28.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txt_dvt.Text == "")
            {
                MessageBox.Show("Chưa nhập " + label23.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (cmb_kho.Text == "")
            {
                MessageBox.Show("Chưa chọn " + label25.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (cmb_loaihh.Text == "")
            {
                MessageBox.Show("Chưa chọn " + label24.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

       
            if (txt_sl_nhap.Text == "")
            {
                MessageBox.Show("Chưa nhập " + label29.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txt_sl_invoice.Text == "")
            {
                MessageBox.Show("Chưa nhập " + label32.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txt_sophieu_NK.Text == "")
            {
                MessageBox.Show("Chưa nhập " + label18.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txt_solot.Text == "")
            {
                MessageBox.Show("Chưa nhập " + label17.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (txt_soinvoice.Text == "")
            {
                MessageBox.Show("Chưa nhập " + label33.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }


            if (cmb_ncc.Text == "")
            {
                MessageBox.Show("Chưa chọn " + label22.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (cmb_nguoinhan.Text == "")
            {
                MessageBox.Show("Chưa chọn " + label5.Text, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;


        }

        //d_input, d_p_nhapkho, c_mabx, c_sophieu_nk, l_stt, c_mahh, c_tenhh, c_dvt, c_solot, l_sl, 
        //l_sl_order, l_sl_hoan, l_sl_haohut, c_kho, c_loaihh, c_nguoinhan, c_soinvoice, c_note, c_msnv, d_date
        private void btn_Save_Click(object sender, EventArgs e)
        {
            //d_input, d_date
            string _ngaynk = string.Empty;
            string _c_mabx= string.Empty;
            string _c_sophieu_nk = string.Empty;
          
            string _c_mahh = string.Empty;
            string _c_tenhh = string.Empty;
            string _c_dvt = string.Empty;
            string _c_solot = string.Empty;
            string _l_sl = string.Empty;
            string _l_sl_invoice = string.Empty; 
           string _l_sl_order= string.Empty;
           string _l_sl_hoan = string.Empty;
           string _l_sl_haohut = string.Empty;
           string _c_kho = string.Empty;
           string _c_loaihh = string.Empty;
           string _c_nguoinhan = string.Empty;
           string _c_soinvoice = string.Empty;
           string _c_note = string.Empty;
           string _c_msnv = string.Empty;
           string _c_mancc = string.Empty;
           string _sql = string.Empty;

           int _kq = 0;
           int _l_stt = 0;

            if (CheckdataInput() == true)
            {
                _ngaynk = msk_ngayPNK.Text;
                _c_mabx = msk_ngayPNK.Text.Replace("/", "");        
            

                if (cmb_tenhh.Text != "")
                {
                    _c_tenhh = cmb_tenhh.Text;
                }

                if (cmb_mahh.Text != "")
                {
                    _c_mahh = cmb_mahh.SelectedValue.ToString();
                }

                if (txt_dvt.Text != "")
                {
                    _c_dvt = txt_dvt.Text;
                }

                if (cmb_kho.Text != "")
                {
                    _c_kho = cmb_kho.SelectedValue.ToString();
                }

                if (cmb_loaihh.Text != "")
                {
                    _c_loaihh = cmb_loaihh.SelectedValue.ToString();
                }


                if (txt_sl_nhap.Text.Trim() != "")
                {
                    _l_sl = txt_sl_nhap.Text.Trim();
                }

                if (txt_sl_invoice.Text != "")
                {
                    _l_sl_invoice = txt_sl_invoice.Text.Trim();
                }

                if (txt_sophieu_NK.Text != "")
                {
                    _c_sophieu_nk = txt_sophieu_NK.Text.Trim();
                }

                if (txt_solot.Text != "")
                {
                    _c_solot = txt_solot.Text.Trim().ToUpper();
                }

                if (txt_soinvoice.Text != "")
                {
                    _c_soinvoice = txt_soinvoice.Text.Trim().ToUpper();
                    
                }        

                if (cmb_ncc.Text != "")
                {
                    _c_mancc = cmb_ncc.SelectedValue.ToString();
                }

                if (cmb_nguoinhan.Text != "")
                {
                    _c_nguoinhan = cmb_nguoinhan.SelectedValue.ToString();
                }

                if (txt_sl_haohut.Text == "")
                {
                    _l_sl_haohut = "0";
                }
                else
                {
                    _l_sl_haohut = txt_sl_haohut.Text.Trim();
                }

                if (txt_sl_hoan.Text == "")
                {
                    _l_sl_hoan = "0";
                }
                else
                {
                    _l_sl_hoan = txt_sl_hoan.Text.Trim();
                }

                 //lay stt
                _sql = string.Empty;
                _sql = "   SELECT max(l_stt ) l_stt  FROM t_nhapkho "
                    + "where d_p_nhapkho =  '" + msk_ngayPNK.Text + "' and c_sophieu_nk = '" + _c_sophieu_nk + "' ";
                DataSet _ds_stt = new DataSet();
                _ds_stt = _cn.Get_ds_CommandSQL(_sql);
                if (_ds_stt.Tables[0].Rows[0][0].ToString() != string.Empty) //_ds_stt.Tables[0].Rows.Count > 0 || 
                {
                    _l_stt = Convert.ToInt32(_ds_stt.Tables[0].Rows[0][0].ToString()) ;
                }
                else
                {
                    _l_stt = 0;
                }

                //kiem tra neu d_p_nhapkho,  _c_mahh, _c_solot: co roi thi update
                //nguoc lai la insert new
                DataRow[] dr_check = _dt_data.Select("c_mahh  = '" + _c_mahh + "'  and  d_p_nhapkho =  '" + msk_ngayPNK.Text + "' and c_solot = '" + _c_solot + "' ");
              
                if (dr_check.Length ==0)
                {

                    if (_flagupdate == 0)
                    {
                      
                        _l_stt = _l_stt + 1;
                        if (MessageBox.Show("Bạn Có Muốn Lưu dữ liệu không?", "Thông Báo!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            _sql = string.Empty;
                            _sql = "    INSERT INTO t_nhapkho ( "
                           + " 	d_input, d_p_nhapkho, c_mabx, c_sophieu_nk, l_stt, c_mahh, c_tenhh, "
                           + "	c_dvt, c_solot, l_sl, l_sl_order, l_sl_hoan, l_sl_haohut, c_kho, "
                           + " 	c_loaihh, c_msnv_nguoinhan, c_soinvoice, c_note,   c_mancc , c_msnv, d_date) "
                       + " values(  CURRENT_TIMESTAMP, '" + msk_ngayPNK.Text + "',    '" + _c_mabx + "',  '" + _c_sophieu_nk + "', '" + _l_stt + "', '" + _c_mahh + "' ,  '" + _c_tenhh + "' ,  '" + _c_dvt + "', "
                       + "   '" + _c_solot + "',   '" + _l_sl + "',   '" + _l_sl_invoice + "',   '" + _l_sl_hoan + "',  '" + _l_sl_haohut + "',  '" + _c_kho + "',  "
                       + "  '" + _c_loaihh + "', '" + _c_nguoinhan + "','" + _c_soinvoice + "', '" + _c_note + "',  '" + _c_mancc + "','" + _msnv + "', CURRENT_TIMESTAMP ) ";
                            _kq = _cn.Execute_Nonquery(_sql);
                        }                   

                    }
                }
                else
                {
                    //ko lam gi
                    if (_flagupdate == 0)
                    {
                        MessageBox.Show("Dữ liệu đã có rồi", "Thông Báo!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        return;
                    }
                    //update các cột còn lại dựa vào :d_p_nhapkho,  _c_mahh, _c_solot
                    if (_flagupdate == 1)
                    {

                        if (MessageBox.Show("Dữ liệu đã có rồi, Bạn có muốn cập nhật dữ liệu không?", "Thông Báo!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            _sql = string.Empty;
                            _sql = "  Update t_nhapkho  "
                      + " set  c_dvt  = '" + _c_dvt + "' ,   c_sophieu_nk =  '" + _c_sophieu_nk + "' "
                      + " l_sl = '" + _l_sl + "', l_sl_order = '" + txt_sl_invoice.Text + "' , l_sl_hoan = '" + _l_sl_hoan + "'   ,  "
                      + " 	  l_sl_haohut = '" + _l_sl_haohut + "', c_kho = '" + _c_kho + "', c_loaihh = '" + _c_loaihh + "', c_msnv_nguoinhan =   '" + _c_nguoinhan + "', c_soinvoice  = '" + _c_soinvoice + "',    "
                      + " c_note = '" + _c_note + "',   c_mancc =  '" + _c_mancc + "', c_msnv = '" + _c_msnv + "' , d_date =  CURRENT_TIMESTAMP "
                      + "  where  d_p_nhapkho = '" + msk_ngayPNK.Text + "' and   c_mahh = '" + _c_mahh + "'     "
                       + "  and  c_solot =  '" + _c_solot + "' and l_stt = '" + _l_stt.ToString() + "'  ";
                        }                 

                    }
                }

                if (_kq == 1)
                {
                    Clear_Input();
                    Loaddata();
                    Loadcombox();
                    Loadcombox_TK();
                    _flagupdate = 0;      
                    _kq = 0;
                    MessageBox.Show("Lưu dữ liệu thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }

            }

        }
  
        private void dgv_Data_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void TimKiem()
        {

            string _kho = string.Empty;
            string _loaihh = string.Empty;
            string _mahh = string.Empty;
            string _tenhh = string.Empty;
            string _mancc = string.Empty;
            string _solot = string.Empty;
            string _sophieuNK = string.Empty;
            string _tungay = string.Empty;
            string _denngay = string.Empty;

            string _sql = string.Empty;
            if (cmb_kho_TK.Text != "")
            {
                _kho = cmb_kho_TK.SelectedValue.ToString();
            }
            else
            {
                _kho = cmb_kho_TK.Text;
            }

            if (cmb_loaihh_TK.Text != "")
            {
                _loaihh = cmb_loaihh_TK.SelectedValue.ToString();
            }
            else
            {
                _loaihh = cmb_loaihh_TK.Text;
            }


            if (cmb_mahh_TK.Text != "")
            {
                _mahh = cmb_mahh_TK.SelectedValue.ToString();
            }
            else
            {
                _mahh = cmb_mahh_TK.Text;
            }

            if (cmb_tenhh_TK.Text != "")
            {
                _tenhh = cmb_tenhh_TK.Text;
            }
            else
            {
                _tenhh = cmb_tenhh_TK.Text;
            }

            if (cmb_ncc_TK.Text != "")
            {
                _mancc = cmb_ncc_TK.SelectedValue.ToString();
            }
            else
            {
                _mancc = cmb_ncc_TK.Text;
            }

            if (cmb_solot_TK.Text != "")
            {
                _solot = cmb_solot_TK.SelectedValue.ToString();
            }
            else
            {
                _solot = cmb_solot_TK.Text;
            }

            if (cmb_sophieu_TK.Text != "")
            {
                _sophieuNK= cmb_sophieu_TK.SelectedValue.ToString();
            }
            else
            {
                _sophieuNK = cmb_sophieu_TK.Text;
            }

            if (mtb_TuNgay_TK.Text != "    /  /")
            {
           
                if (Date(mtb_TuNgay_TK.Text) == true)
                {

                    DateTime d_sysdate = DateTime.Parse(_d_sysdate);
                    DateTime d_input = DateTime.Parse(mtb_TuNgay_TK.Text);
                    int compare = DateTime.Compare(d_sysdate, d_input);
                    TimeSpan diff = d_input - d_sysdate;
                    if (diff.Days > 0)
                    {
                        MessageBox.Show("Từ ngày không được > ngày hiện tại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    else
                    {
                      
                        _tungay = mtb_TuNgay_TK.Text;
                    }

                }
                else
                {
                    MessageBox.Show("Từ ngày không đúng định dạng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    mtb_TuNgay_TK.Text = "    /  /";
                    return;
                }
            }
            else
            {
                _tungay = string.Empty;
            }

            if (mtb_DenNgay_TK.Text != "    /  /")
            {
          
                if (Date(mtb_DenNgay_TK.Text) == true)
                {

                    DateTime d_sysdate = DateTime.Parse(_d_sysdate);
                    DateTime d_input = DateTime.Parse(mtb_DenNgay_TK.Text);
                    int compare = DateTime.Compare(d_sysdate, d_input);
                    TimeSpan diff = d_input - d_sysdate;
                    if (diff.Days > 0)
                    {
                        MessageBox.Show("Đến ngày không được > ngày hiện tại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        mtb_DenNgay_TK.Text = "    /  /";
                        return;
                    }
                    else
                    {
                        // kiem tra  den ngay >= tu ngay              
                        if (mtb_TuNgay_TK.Text != "    /  /")
                        {
                            DateTime d_tungay = DateTime.Parse(mtb_TuNgay_TK.Text);
                            int compare2 = DateTime.Compare(d_tungay, d_input);
                            TimeSpan diff2 = d_input - d_tungay;
                            if (diff2.Days < 0)
                            {
                                MessageBox.Show("Đến ngày phải >= Từ ngày", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                mtb_DenNgay_TK.Text = "    /  /";
                                return;
                            }
                            else
                            {
                                _denngay = mtb_DenNgay_TK.Text;
                            }
                        }
                        else
                        {
                          //neu  ko nhap tu ngày 
                            _tungay = "2024/01/01";
                            _denngay = mtb_DenNgay_TK.Text;
                            
                        }

                    }

                }
                else
                {
                    MessageBox.Show("Đến ngày không đúng định dạng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    mtb_DenNgay_TK.Text = "    /  /";
                    return;
                }
            }
            else
            {
                _denngay = _d_sysdate;
            }
            //SELECT to_char(d_p_nhapkho, 'yyyy/MM/dd') d_p_nhapkho, c_item_kho, c_item_loaihh , 
            //   c_mahh, c_tenhh, c_sophieu_nk, c_solot,  l_sl_order,  l_sl, c_dvt, m3.c_tenncc c_tenncc, c_soinvoice, m4.c_hoten c_hoten,           
            //c_note, l_sl_hoan, l_sl_haohut,         
            //c_msnv, to_char(t.d_input,  'YYYY/MM/DD HH24:MI:ss') d_input ,  to_char(t.d_date,  'YYYY/MM/DD HH24:MI:ss') d_date, 
            // c_bophan, c_mabx, l_stt,
            ////c_kho, c_loaihh,   c_mancc, c_msnv_nguoinhan, c_solot_all           
            //FROM t_nhapkho t left join  m_common m1 on t.c_kho = m1.c_type || ':' ||m1.c_ma and m1.c_type = '01'
            //left join  m_common m2 on t.c_loaihh = m2.c_type || ':' ||m2.c_ma and m2.c_type = '02'
            //left join m_ncc m3 on t.c_mancc = m3.c_mancc
            //left join m_nhanvien m4 on t.c_nguoinhan = m4.c_msnv

            _sql = " SELECT to_char(d_p_nhapkho, 'yyyy/MM/dd') d_p_nhapkho, m1.c_item c_item_kho, "
            + " m2.c_item c_item_loaihh ,  "
            + "   c_mahh, c_tenhh, c_sophieu_nk, c_solot,  l_sl_order,  l_sl, c_dvt, m3.c_tenncc c_tenncc, c_soinvoice, m4.c_hoten c_hoten,  "
            + " c_note, l_sl_hoan, l_sl_haohut,  t.c_msnv,        "
            + " to_char(t.d_input,  'YYYY/MM/DD HH24:MI:ss') d_input ,  to_char(t.d_date,  'YYYY/MM/DD HH24:MI:ss') d_date, "
            + " c_bophan, c_mabx, l_stt, "
            + " c_kho, c_loaihh,   t.c_mancc, c_msnv_nguoinhan, c_solot_all   "
            + " FROM t_nhapkho t left join  m_common m1 on t.c_kho = m1.c_type || ':' ||m1.c_ma and m1.c_type = '" + _const_type_kho + "' "
            + " left join  m_common m2 on t.c_loaihh = m2.c_type || ':' ||m2.c_ma and m2.c_type =  '" + _const_type_loaihh + "' "
            + " left join m_ncc m3 on t.c_mancc = m3.c_mancc "
            + " left join m_nhanvien m4 on t.c_msnv_nguoinhan = m4.c_msnv "
            + " where c_kho  like '%" + _kho + "%' "
            + " and c_loaihh like '%" + _loaihh + "%' "
            + " and t.c_mahh like '%" + _mahh + "%' "
            + " and t.c_tenhh like '%" + _tenhh + "%' "
            + " and t.c_mancc like '%" + _mancc + "%' "
            + " and c_solot like '%" + _solot + "%' "
            + " and t.c_sophieu_nk like '%" + _sophieuNK + "%' "
            + " and  to_char(t.d_p_nhapkho, 'yyyy/MM/dd')  between  '" + _tungay + "' AND  '" + _denngay + "'  "
            + " order by d_p_nhapkho,c_item_kho , c_item_loaihh,c_mahh, l_stt ";      

            _ds = _cn.Get_ds_CommandSQL(_sql);

            if (_ds.Tables[0].Rows.Count > 0)
            {
                dgv_Data.AutoGenerateColumns = false;
                dgv_Data.DataSource = _ds.Tables[0];
                txt_sodong.Text = _ds.Tables[0].Rows.Count.ToString();

            }
            else
            {
                MessageBox.Show("Không có dữ liệu.!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dgv_Data.DataSource = _ds.Tables[0];
                return;
            }

        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
          
            TimKiem();
        }

        private void Clear_Search()
        {
            cmb_kho_TK.SelectedIndex = -1;
            cmb_loaihh_TK.SelectedIndex = -1;
            cmb_mahh_TK.SelectedIndex = -1;
            cmb_tenhh_TK.SelectedIndex = -1;
            cmb_ncc_TK.SelectedIndex = -1;
            cmb_solot_TK.SelectedIndex = -1;
            cmb_sophieu_TK.SelectedIndex = -1;
            mtb_TuNgay_TK.Text = "    /  /";
            mtb_DenNgay_TK.Text = "    /  /";

        }

        private void Clear_Input()
        {
            msk_ngayPNK.Text = _d_sysdate;
            cmb_tenhh.SelectedIndex = -1;
            cmb_mahh.SelectedIndex = -1;
            txt_dvt.Text = string.Empty;
            cmb_kho.SelectedIndex = -1;
            cmb_loaihh.SelectedIndex = -1;
            cmb_ncc.SelectedIndex = -1;
            cmb_nguoinhan.SelectedIndex = -1;

            txt_sl_nhap.Text = string.Empty;
            txt_sl_invoice.Text = string.Empty;
            txt_sophieu_NK.Text = string.Empty;
            txt_solot.Text = string.Empty;
            txt_soinvoice.Text = string.Empty;
            txt_sophieu_NK.Text = string.Empty;
            txt_ghichu.Text = string.Empty;
            txt_sl_haohut.Text = string.Empty;
            txt_sl_hoan.Text = string.Empty;
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            Clear_Search();
            Clear_Input();
            txt_sodong.Text = string.Empty;
            dgv_Data.DataSource = null;
        }

        private void DeleteData()
        {
            int _kq = 0;
            int count_kq = 0;
            string _sql = string.Empty;
            string _c_mahh = string.Empty;
            string _c_solot = string.Empty;
            string _l_stt= string.Empty;
            string _d_ngaynk = string.Empty;

            if (dgv_Data.Rows.Count > 0)
            {
                int dem = 0;
                for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                {
                    //kiem tra neu co 1 dong dc check thi xoa
                    if (Convert.ToBoolean(dgv_Data.Rows[i].Cells[0].Value) == true)// lay vi tri cua dong dang check
                    {

                        dem++;
                        continue;
                    }

                }
                if (dem == 0)
                {
                    MessageBox.Show("Bạn chưa chọn dòng cần xóa", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (MessageBox.Show("Bạn Có Muốn Xóa Không", "Thông Báo!!", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                    {
                        if (dgv_Data.Rows[i].Cells["check"].Value != null)
                        {
                            if (dgv_Data.Rows[i].Cells["check"].Value.ToString() == "True" || dgv_Data.Rows[i].Cells["check"].Value.ToString() == "1")
                            {
                                _d_ngaynk = dgv_Data.Rows[i].Cells["d_p_nhapkho"].Value.ToString();
                                _c_mahh = dgv_Data.Rows[i].Cells["c_mahh"].Value.ToString();
                                _c_solot = dgv_Data.Rows[i].Cells["c_solot"].Value.ToString();
                                _l_stt = dgv_Data.Rows[i].Cells["l_stt"].Value.ToString();

                                _sql = "delete from  t_nhapkho  WHERE c_mahh =  '" + _c_mahh + "' and  d_p_nhapkho =   '" + _d_ngaynk + "'  "
                                    + " and  c_solot =  '" + _c_solot + "' and  l_stt =   '" + _l_stt + "'";
                                _kq = _cn.Execute_Nonquery(_sql);
                                if (_kq == 1)
                                {
                                    count_kq = count_kq + 1;
                                }

                            }
                        }

                    }
                }

            }

            else
            {
                MessageBox.Show("Không có dữ liệu để xóa", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (count_kq > 0)
            {
                Loadcombox_TK();
                Loadcombox();
                Loaddata();
                dgv_Data.DataSource = null;
                MessageBox.Show("Đã xóa thành công.", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Xóa dữ liệu bị lỗi.", "Thông Báo!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btn_Delete_Click(object sender, EventArgs e)
        {

            DeleteData();
        }

        private void dgv_Data_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int _cot = e.ColumnIndex;
            if (dgv_Data.RowCount > 0)
            {
                dgv_Data.CurrentCell = dgv_Data.Rows[0].Cells[1];
                if (_cot == 0)
                {
                    bool kq = dgv_Data.Rows[0].Cells[0].Value == null ? false : Convert.ToBoolean(dgv_Data.Rows[0].Cells[0].Value.ToString());
                    for (int i = 0; i <= dgv_Data.Rows.Count - 1; i++)
                    {
                        dgv_Data.Rows[i].Cells[_cot].Value = !kq;
                    }
                }
            }
        }



    }
}
