﻿namespace frm_nhapkho
{
    partial class frm_nhapkho
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_Data = new System.Windows.Forms.DataGridView();
            this.txt_excelmau = new System.Windows.Forms.LinkLabel();
            this.btn_Import = new System.Windows.Forms.Button();
            this.btn_Save = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmb_solot_TK = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb_sophieu_TK = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.mtb_TuNgay_TK = new System.Windows.Forms.MaskedTextBox();
            this.mtb_DenNgay_TK = new System.Windows.Forms.MaskedTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.cmb_ncc_TK = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cmb_tenhh_TK = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cmb_mahh_TK = new System.Windows.Forms.ComboBox();
            this.cmb_loaihh_TK = new System.Windows.Forms.ComboBox();
            this.btn_Clear = new System.Windows.Forms.Button();
            this.btn_Excel = new System.Windows.Forms.Button();
            this.Label11 = new System.Windows.Forms.Label();
            this.btn_Search = new System.Windows.Forms.Button();
            this.cmb_kho_TK = new System.Windows.Forms.ComboBox();
            this.Label21 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_solot = new System.Windows.Forms.TextBox();
            this.group = new System.Windows.Forms.GroupBox();
            this.cmb_nguoinhan = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_dvt = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.cmb_kho = new System.Windows.Forms.ComboBox();
            this.txt_soinvoice = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.cmb_loaihh = new System.Windows.Forms.ComboBox();
            this.txt_sl_invoice = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.txt_sl_hoan = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txt_ghichu = new System.Windows.Forms.TextBox();
            this.txt_sl_nhap = new System.Windows.Forms.TextBox();
            this.txt_sl_haohut = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_sophieu_NK = new System.Windows.Forms.TextBox();
            this.cmb_mahh = new System.Windows.Forms.ComboBox();
            this.cmb_tenhh = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.msk_ngayPNK = new System.Windows.Forms.MaskedTextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cmb_ncc = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txt_sodong = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Data)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.group.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgv_Data
            // 
            this.dgv_Data.AllowUserToAddRows = false;
            this.dgv_Data.AllowUserToDeleteRows = false;
            this.dgv_Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Data.Location = new System.Drawing.Point(3, 172);
            this.dgv_Data.Name = "dgv_Data";
            this.dgv_Data.RowHeadersVisible = false;
            this.dgv_Data.RowTemplate.Height = 21;
            this.dgv_Data.Size = new System.Drawing.Size(969, 325);
            this.dgv_Data.TabIndex = 238;
            this.dgv_Data.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Data_CellDoubleClick);
            this.dgv_Data.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_Data_ColumnHeaderMouseClick);
            // 
            // txt_excelmau
            // 
            this.txt_excelmau.AutoSize = true;
            this.txt_excelmau.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_excelmau.Location = new System.Drawing.Point(789, 44);
            this.txt_excelmau.Name = "txt_excelmau";
            this.txt_excelmau.Size = new System.Drawing.Size(58, 15);
            this.txt_excelmau.TabIndex = 223;
            this.txt_excelmau.TabStop = true;
            this.txt_excelmau.Text = "Excel Mẫu";
            this.txt_excelmau.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // btn_Import
            // 
            this.btn_Import.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Import.ForeColor = System.Drawing.Color.Blue;
            this.btn_Import.Location = new System.Drawing.Point(853, 37);
            this.btn_Import.Name = "btn_Import";
            this.btn_Import.Size = new System.Drawing.Size(75, 27);
            this.btn_Import.TabIndex = 17;
            this.btn_Import.Text = "Import";
            this.btn_Import.UseVisualStyleBackColor = true;
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.Blue;
            this.btn_Save.Location = new System.Drawing.Point(853, 70);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(75, 27);
            this.btn_Save.TabIndex = 18;
            this.btn_Save.Text = "Lưu";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cmb_solot_TK);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cmb_sophieu_TK);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Label8);
            this.groupBox1.Controls.Add(this.mtb_TuNgay_TK);
            this.groupBox1.Controls.Add(this.mtb_DenNgay_TK);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.cmb_ncc_TK);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.cmb_tenhh_TK);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.cmb_mahh_TK);
            this.groupBox1.Controls.Add(this.cmb_loaihh_TK);
            this.groupBox1.Controls.Add(this.btn_Clear);
            this.groupBox1.Controls.Add(this.btn_Excel);
            this.groupBox1.Controls.Add(this.Label11);
            this.groupBox1.Controls.Add(this.btn_Search);
            this.groupBox1.Controls.Add(this.cmb_kho_TK);
            this.groupBox1.Controls.Add(this.Label21);
            this.groupBox1.Location = new System.Drawing.Point(6, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(966, 129);
            this.groupBox1.TabIndex = 236;
            this.groupBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Blue;
            this.label4.Location = new System.Drawing.Point(29, 70);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 19);
            this.label4.TabIndex = 232;
            this.label4.Text = "Số lot";
            // 
            // cmb_solot_TK
            // 
            this.cmb_solot_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_solot_TK.DropDownHeight = 100;
            this.cmb_solot_TK.DropDownWidth = 100;
            this.cmb_solot_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_solot_TK.FormattingEnabled = true;
            this.cmb_solot_TK.IntegralHeight = false;
            this.cmb_solot_TK.Location = new System.Drawing.Point(7, 92);
            this.cmb_solot_TK.Name = "cmb_solot_TK";
            this.cmb_solot_TK.Size = new System.Drawing.Size(101, 27);
            this.cmb_solot_TK.TabIndex = 28;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(137, 70);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 19);
            this.label3.TabIndex = 230;
            this.label3.Text = "Số phiếu";
            // 
            // cmb_sophieu_TK
            // 
            this.cmb_sophieu_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_sophieu_TK.DropDownHeight = 100;
            this.cmb_sophieu_TK.DropDownWidth = 100;
            this.cmb_sophieu_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_sophieu_TK.FormattingEnabled = true;
            this.cmb_sophieu_TK.IntegralHeight = false;
            this.cmb_sophieu_TK.Location = new System.Drawing.Point(115, 92);
            this.cmb_sophieu_TK.Name = "cmb_sophieu_TK";
            this.cmb_sophieu_TK.Size = new System.Drawing.Size(101, 27);
            this.cmb_sophieu_TK.TabIndex = 29;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(232, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 19);
            this.label2.TabIndex = 227;
            this.label2.Text = "Từ  (ngày phiếu NK)";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.ForeColor = System.Drawing.Color.Blue;
            this.Label8.Location = new System.Drawing.Point(380, 70);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(66, 19);
            this.Label8.TabIndex = 228;
            this.Label8.Text = "Đến ngày";
            this.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mtb_TuNgay_TK
            // 
            this.mtb_TuNgay_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtb_TuNgay_TK.Location = new System.Drawing.Point(227, 93);
            this.mtb_TuNgay_TK.Mask = "0000/00/00";
            this.mtb_TuNgay_TK.Name = "mtb_TuNgay_TK";
            this.mtb_TuNgay_TK.Size = new System.Drawing.Size(94, 26);
            this.mtb_TuNgay_TK.TabIndex = 26;
            // 
            // mtb_DenNgay_TK
            // 
            this.mtb_DenNgay_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mtb_DenNgay_TK.Location = new System.Drawing.Point(379, 93);
            this.mtb_DenNgay_TK.Mask = "0000/00/00";
            this.mtb_DenNgay_TK.Name = "mtb_DenNgay_TK";
            this.mtb_DenNgay_TK.Size = new System.Drawing.Size(88, 26);
            this.mtb_DenNgay_TK.TabIndex = 27;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Blue;
            this.label12.Location = new System.Drawing.Point(752, 15);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 19);
            this.label12.TabIndex = 224;
            this.label12.Text = "NCC";
            // 
            // cmb_ncc_TK
            // 
            this.cmb_ncc_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_ncc_TK.DropDownHeight = 100;
            this.cmb_ncc_TK.DropDownWidth = 100;
            this.cmb_ncc_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_ncc_TK.FormattingEnabled = true;
            this.cmb_ncc_TK.IntegralHeight = false;
            this.cmb_ncc_TK.Location = new System.Drawing.Point(672, 37);
            this.cmb_ncc_TK.Name = "cmb_ncc_TK";
            this.cmb_ncc_TK.Size = new System.Drawing.Size(200, 27);
            this.cmb_ncc_TK.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(510, 15);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 19);
            this.label10.TabIndex = 222;
            this.label10.Text = "Tên HH";
            // 
            // cmb_tenhh_TK
            // 
            this.cmb_tenhh_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_tenhh_TK.DropDownHeight = 100;
            this.cmb_tenhh_TK.DropDownWidth = 100;
            this.cmb_tenhh_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_tenhh_TK.FormattingEnabled = true;
            this.cmb_tenhh_TK.IntegralHeight = false;
            this.cmb_tenhh_TK.Location = new System.Drawing.Point(430, 37);
            this.cmb_tenhh_TK.Name = "cmb_tenhh_TK";
            this.cmb_tenhh_TK.Size = new System.Drawing.Size(236, 27);
            this.cmb_tenhh_TK.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Blue;
            this.label9.Location = new System.Drawing.Point(334, 15);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 19);
            this.label9.TabIndex = 220;
            this.label9.Text = "Mã HH";
            // 
            // cmb_mahh_TK
            // 
            this.cmb_mahh_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_mahh_TK.DropDownHeight = 100;
            this.cmb_mahh_TK.DropDownWidth = 100;
            this.cmb_mahh_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_mahh_TK.FormattingEnabled = true;
            this.cmb_mahh_TK.IntegralHeight = false;
            this.cmb_mahh_TK.Location = new System.Drawing.Point(322, 37);
            this.cmb_mahh_TK.Name = "cmb_mahh_TK";
            this.cmb_mahh_TK.Size = new System.Drawing.Size(99, 27);
            this.cmb_mahh_TK.TabIndex = 23;
            // 
            // cmb_loaihh_TK
            // 
            this.cmb_loaihh_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_loaihh_TK.DropDownHeight = 100;
            this.cmb_loaihh_TK.DropDownWidth = 200;
            this.cmb_loaihh_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_loaihh_TK.FormattingEnabled = true;
            this.cmb_loaihh_TK.IntegralHeight = false;
            this.cmb_loaihh_TK.Location = new System.Drawing.Point(112, 37);
            this.cmb_loaihh_TK.Name = "cmb_loaihh_TK";
            this.cmb_loaihh_TK.Size = new System.Drawing.Size(197, 27);
            this.cmb_loaihh_TK.TabIndex = 22;
            // 
            // btn_Clear
            // 
            this.btn_Clear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Clear.ForeColor = System.Drawing.Color.Blue;
            this.btn_Clear.Location = new System.Drawing.Point(753, 91);
            this.btn_Clear.Name = "btn_Clear";
            this.btn_Clear.Size = new System.Drawing.Size(91, 27);
            this.btn_Clear.TabIndex = 31;
            this.btn_Clear.Text = "Xóa trắng";
            this.btn_Clear.UseVisualStyleBackColor = true;
            this.btn_Clear.Click += new System.EventHandler(this.btn_Clear_Click);
            // 
            // btn_Excel
            // 
            this.btn_Excel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Excel.ForeColor = System.Drawing.Color.SeaGreen;
            this.btn_Excel.Location = new System.Drawing.Point(850, 90);
            this.btn_Excel.Name = "btn_Excel";
            this.btn_Excel.Size = new System.Drawing.Size(75, 27);
            this.btn_Excel.TabIndex = 32;
            this.btn_Excel.Text = "Excel";
            this.btn_Excel.UseVisualStyleBackColor = true;
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.ForeColor = System.Drawing.Color.Blue;
            this.Label11.Location = new System.Drawing.Point(19, 15);
            this.Label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(36, 19);
            this.Label11.TabIndex = 218;
            this.Label11.Text = "Kho";
            // 
            // btn_Search
            // 
            this.btn_Search.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Search.ForeColor = System.Drawing.Color.Blue;
            this.btn_Search.Location = new System.Drawing.Point(672, 91);
            this.btn_Search.Name = "btn_Search";
            this.btn_Search.Size = new System.Drawing.Size(75, 27);
            this.btn_Search.TabIndex = 30;
            this.btn_Search.Text = "Tìm kiếm";
            this.btn_Search.UseVisualStyleBackColor = true;
            this.btn_Search.Click += new System.EventHandler(this.btn_Search_Click);
            // 
            // cmb_kho_TK
            // 
            this.cmb_kho_TK.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_kho_TK.DropDownHeight = 100;
            this.cmb_kho_TK.DropDownWidth = 100;
            this.cmb_kho_TK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_kho_TK.FormattingEnabled = true;
            this.cmb_kho_TK.IntegralHeight = false;
            this.cmb_kho_TK.Location = new System.Drawing.Point(7, 37);
            this.cmb_kho_TK.Name = "cmb_kho_TK";
            this.cmb_kho_TK.Size = new System.Drawing.Size(99, 27);
            this.cmb_kho_TK.TabIndex = 21;
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label21.ForeColor = System.Drawing.Color.Blue;
            this.Label21.Location = new System.Drawing.Point(148, 15);
            this.Label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(94, 19);
            this.Label21.TabIndex = 217;
            this.Label21.Text = "Loại hàng hóa";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(353, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 24);
            this.label1.TabIndex = 237;
            this.label1.Text = "MH ";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Blue;
            this.label17.Location = new System.Drawing.Point(334, 112);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(47, 19);
            this.label17.TabIndex = 241;
            this.label17.Text = "Số lot";
            // 
            // txt_solot
            // 
            this.txt_solot.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_solot.Location = new System.Drawing.Point(413, 113);
            this.txt_solot.MaxLength = 50;
            this.txt_solot.Name = "txt_solot";
            this.txt_solot.Size = new System.Drawing.Size(92, 25);
            this.txt_solot.TabIndex = 9;
            this.txt_solot.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_solot_KeyPress);
            // 
            // group
            // 
            this.group.Controls.Add(this.cmb_nguoinhan);
            this.group.Controls.Add(this.label5);
            this.group.Controls.Add(this.txt_dvt);
            this.group.Controls.Add(this.label33);
            this.group.Controls.Add(this.label25);
            this.group.Controls.Add(this.cmb_kho);
            this.group.Controls.Add(this.txt_soinvoice);
            this.group.Controls.Add(this.label24);
            this.group.Controls.Add(this.label32);
            this.group.Controls.Add(this.cmb_loaihh);
            this.group.Controls.Add(this.txt_sl_invoice);
            this.group.Controls.Add(this.label31);
            this.group.Controls.Add(this.txt_sl_hoan);
            this.group.Controls.Add(this.label29);
            this.group.Controls.Add(this.label20);
            this.group.Controls.Add(this.label30);
            this.group.Controls.Add(this.txt_ghichu);
            this.group.Controls.Add(this.txt_sl_nhap);
            this.group.Controls.Add(this.txt_sl_haohut);
            this.group.Controls.Add(this.label17);
            this.group.Controls.Add(this.txt_solot);
            this.group.Controls.Add(this.label18);
            this.group.Controls.Add(this.txt_sophieu_NK);
            this.group.Controls.Add(this.cmb_mahh);
            this.group.Controls.Add(this.cmb_tenhh);
            this.group.Controls.Add(this.txt_excelmau);
            this.group.Controls.Add(this.btn_Import);
            this.group.Controls.Add(this.label19);
            this.group.Controls.Add(this.msk_ngayPNK);
            this.group.Controls.Add(this.label22);
            this.group.Controls.Add(this.btn_Save);
            this.group.Controls.Add(this.cmb_ncc);
            this.group.Controls.Add(this.label23);
            this.group.Controls.Add(this.btn_Exit);
            this.group.Controls.Add(this.btn_Delete);
            this.group.Controls.Add(this.label26);
            this.group.Controls.Add(this.label27);
            this.group.Controls.Add(this.txt_sodong);
            this.group.Controls.Add(this.label28);
            this.group.Location = new System.Drawing.Point(3, 503);
            this.group.Name = "group";
            this.group.Size = new System.Drawing.Size(969, 207);
            this.group.TabIndex = 0;
            this.group.TabStop = false;
            // 
            // cmb_nguoinhan
            // 
            this.cmb_nguoinhan.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_nguoinhan.DropDownHeight = 300;
            this.cmb_nguoinhan.DropDownWidth = 200;
            this.cmb_nguoinhan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_nguoinhan.FormattingEnabled = true;
            this.cmb_nguoinhan.IntegralHeight = false;
            this.cmb_nguoinhan.Location = new System.Drawing.Point(615, 79);
            this.cmb_nguoinhan.Name = "cmb_nguoinhan";
            this.cmb_nguoinhan.Size = new System.Drawing.Size(150, 27);
            this.cmb_nguoinhan.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(523, 82);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 19);
            this.label5.TabIndex = 253;
            this.label5.Text = "Người nhận";
            // 
            // txt_dvt
            // 
            this.txt_dvt.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_dvt.Location = new System.Drawing.Point(262, 112);
            this.txt_dvt.MaxLength = 50;
            this.txt_dvt.Name = "txt_dvt";
            this.txt_dvt.ReadOnly = true;
            this.txt_dvt.Size = new System.Drawing.Size(56, 25);
            this.txt_dvt.TabIndex = 4;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Blue;
            this.label33.Location = new System.Drawing.Point(334, 174);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(72, 19);
            this.label33.TabIndex = 251;
            this.label33.Text = "Số invoice";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Blue;
            this.label25.Location = new System.Drawing.Point(6, 146);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(36, 19);
            this.label25.TabIndex = 225;
            this.label25.Text = "Kho";
            // 
            // cmb_kho
            // 
            this.cmb_kho.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_kho.DropDownHeight = 100;
            this.cmb_kho.DropDownWidth = 100;
            this.cmb_kho.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_kho.FormattingEnabled = true;
            this.cmb_kho.IntegralHeight = false;
            this.cmb_kho.Location = new System.Drawing.Point(107, 143);
            this.cmb_kho.Name = "cmb_kho";
            this.cmb_kho.Size = new System.Drawing.Size(101, 27);
            this.cmb_kho.TabIndex = 5;
            this.cmb_kho.SelectedIndexChanged += new System.EventHandler(this.cmb_kho_SelectedIndexChanged);
            // 
            // txt_soinvoice
            // 
            this.txt_soinvoice.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_soinvoice.Location = new System.Drawing.Point(413, 173);
            this.txt_soinvoice.MaxLength = 50;
            this.txt_soinvoice.Name = "txt_soinvoice";
            this.txt_soinvoice.Size = new System.Drawing.Size(92, 25);
            this.txt_soinvoice.TabIndex = 11;
            this.txt_soinvoice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_soinvoice_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Blue;
            this.label24.Location = new System.Drawing.Point(6, 177);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(94, 19);
            this.label24.TabIndex = 226;
            this.label24.Text = "Loại hàng hóa";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Blue;
            this.label32.Location = new System.Drawing.Point(334, 82);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(72, 19);
            this.label32.TabIndex = 249;
            this.label32.Text = "SL invoice";
            // 
            // cmb_loaihh
            // 
            this.cmb_loaihh.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_loaihh.DropDownHeight = 200;
            this.cmb_loaihh.DropDownWidth = 200;
            this.cmb_loaihh.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_loaihh.FormattingEnabled = true;
            this.cmb_loaihh.IntegralHeight = false;
            this.cmb_loaihh.Location = new System.Drawing.Point(107, 174);
            this.cmb_loaihh.Name = "cmb_loaihh";
            this.cmb_loaihh.Size = new System.Drawing.Size(211, 27);
            this.cmb_loaihh.TabIndex = 6;
            this.cmb_loaihh.SelectedIndexChanged += new System.EventHandler(this.cmb_loaihh_SelectedIndexChanged);
            // 
            // txt_sl_invoice
            // 
            this.txt_sl_invoice.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sl_invoice.Location = new System.Drawing.Point(413, 78);
            this.txt_sl_invoice.MaxLength = 10;
            this.txt_sl_invoice.Name = "txt_sl_invoice";
            this.txt_sl_invoice.Size = new System.Drawing.Size(92, 25);
            this.txt_sl_invoice.TabIndex = 8;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Black;
            this.label31.Location = new System.Drawing.Point(523, 145);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(74, 19);
            this.label31.TabIndex = 247;
            this.label31.Text = "SL hao hụt";
            // 
            // txt_sl_hoan
            // 
            this.txt_sl_hoan.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sl_hoan.Location = new System.Drawing.Point(615, 174);
            this.txt_sl_hoan.MaxLength = 10;
            this.txt_sl_hoan.Name = "txt_sl_hoan";
            this.txt_sl_hoan.Size = new System.Drawing.Size(92, 25);
            this.txt_sl_hoan.TabIndex = 16;
            this.txt_sl_hoan.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_sl_hoan_KeyPress);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Blue;
            this.label29.Location = new System.Drawing.Point(334, 49);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(59, 19);
            this.label29.TabIndex = 243;
            this.label29.Text = "SL nhập";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(523, 112);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 19);
            this.label20.TabIndex = 233;
            this.label20.Text = "Ghi chú";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(523, 177);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(59, 19);
            this.label30.TabIndex = 245;
            this.label30.Text = "SL hoàn";
            // 
            // txt_ghichu
            // 
            this.txt_ghichu.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ghichu.Location = new System.Drawing.Point(615, 112);
            this.txt_ghichu.MaxLength = 1000;
            this.txt_ghichu.Name = "txt_ghichu";
            this.txt_ghichu.Size = new System.Drawing.Size(185, 25);
            this.txt_ghichu.TabIndex = 14;
            // 
            // txt_sl_nhap
            // 
            this.txt_sl_nhap.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sl_nhap.Location = new System.Drawing.Point(413, 47);
            this.txt_sl_nhap.MaxLength = 10;
            this.txt_sl_nhap.Name = "txt_sl_nhap";
            this.txt_sl_nhap.Size = new System.Drawing.Size(92, 25);
            this.txt_sl_nhap.TabIndex = 7;
            this.txt_sl_nhap.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_sl_nhap_KeyPress);
            // 
            // txt_sl_haohut
            // 
            this.txt_sl_haohut.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sl_haohut.Location = new System.Drawing.Point(615, 141);
            this.txt_sl_haohut.MaxLength = 10;
            this.txt_sl_haohut.Name = "txt_sl_haohut";
            this.txt_sl_haohut.Size = new System.Drawing.Size(92, 25);
            this.txt_sl_haohut.TabIndex = 15;
            this.txt_sl_haohut.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_sl_haohut_KeyPress);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Blue;
            this.label18.Location = new System.Drawing.Point(334, 145);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 19);
            this.label18.TabIndex = 239;
            this.label18.Text = "Số phiếu";
            // 
            // txt_sophieu_NK
            // 
            this.txt_sophieu_NK.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sophieu_NK.Location = new System.Drawing.Point(413, 141);
            this.txt_sophieu_NK.MaxLength = 50;
            this.txt_sophieu_NK.Name = "txt_sophieu_NK";
            this.txt_sophieu_NK.Size = new System.Drawing.Size(92, 25);
            this.txt_sophieu_NK.TabIndex = 10;
            this.txt_sophieu_NK.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txt_sophieu_NK_KeyPress);
            // 
            // cmb_mahh
            // 
            this.cmb_mahh.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_mahh.DropDownHeight = 200;
            this.cmb_mahh.DropDownWidth = 100;
            this.cmb_mahh.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_mahh.FormattingEnabled = true;
            this.cmb_mahh.IntegralHeight = false;
            this.cmb_mahh.Location = new System.Drawing.Point(108, 110);
            this.cmb_mahh.Name = "cmb_mahh";
            this.cmb_mahh.Size = new System.Drawing.Size(100, 27);
            this.cmb_mahh.TabIndex = 3;
            // 
            // cmb_tenhh
            // 
            this.cmb_tenhh.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_tenhh.DropDownHeight = 300;
            this.cmb_tenhh.DropDownWidth = 200;
            this.cmb_tenhh.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_tenhh.FormattingEnabled = true;
            this.cmb_tenhh.IntegralHeight = false;
            this.cmb_tenhh.Location = new System.Drawing.Point(107, 75);
            this.cmb_tenhh.Name = "cmb_tenhh";
            this.cmb_tenhh.Size = new System.Drawing.Size(211, 27);
            this.cmb_tenhh.TabIndex = 2;
            this.cmb_tenhh.SelectedIndexChanged += new System.EventHandler(this.cmb_tenhh_SelectedIndexChanged);
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Blue;
            this.label19.Location = new System.Drawing.Point(7, 47);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 20);
            this.label19.TabIndex = 235;
            this.label19.Text = "Ngày";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // msk_ngayPNK
            // 
            this.msk_ngayPNK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msk_ngayPNK.Location = new System.Drawing.Point(108, 41);
            this.msk_ngayPNK.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.msk_ngayPNK.Mask = "0000/00/00";
            this.msk_ngayPNK.Name = "msk_ngayPNK";
            this.msk_ngayPNK.Size = new System.Drawing.Size(103, 26);
            this.msk_ngayPNK.TabIndex = 1;
            this.msk_ngayPNK.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.msk_ngayPNK.ValidatingType = typeof(System.DateTime);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Blue;
            this.label22.Location = new System.Drawing.Point(523, 49);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(43, 19);
            this.label22.TabIndex = 231;
            this.label22.Text = "NCC";
            // 
            // cmb_ncc
            // 
            this.cmb_ncc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_ncc.DropDownHeight = 300;
            this.cmb_ncc.DropDownWidth = 180;
            this.cmb_ncc.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_ncc.FormattingEnabled = true;
            this.cmb_ncc.IntegralHeight = false;
            this.cmb_ncc.Location = new System.Drawing.Point(615, 46);
            this.cmb_ncc.Name = "cmb_ncc";
            this.cmb_ncc.Size = new System.Drawing.Size(150, 27);
            this.cmb_ncc.TabIndex = 12;
            this.cmb_ncc.SelectedIndexChanged += new System.EventHandler(this.cmb_ncc_SelectedIndexChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Blue;
            this.label23.Location = new System.Drawing.Point(215, 113);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(40, 19);
            this.label23.TabIndex = 229;
            this.label23.Text = "ĐVT";
            // 
            // btn_Exit
            // 
            this.btn_Exit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.ForeColor = System.Drawing.Color.Red;
            this.btn_Exit.Location = new System.Drawing.Point(853, 165);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(75, 27);
            this.btn_Exit.TabIndex = 20;
            this.btn_Exit.Text = "Thoát";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.btn_Exit_Click);
            // 
            // btn_Delete
            // 
            this.btn_Delete.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete.ForeColor = System.Drawing.Color.Red;
            this.btn_Delete.Location = new System.Drawing.Point(853, 103);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 27);
            this.btn_Delete.TabIndex = 19;
            this.btn_Delete.Text = "Xóa";
            this.btn_Delete.UseVisualStyleBackColor = true;
            this.btn_Delete.Click += new System.EventHandler(this.btn_Delete_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Blue;
            this.label26.Location = new System.Drawing.Point(6, 78);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(99, 19);
            this.label26.TabIndex = 221;
            this.label26.Text = "Tên hàng hóa";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Blue;
            this.label27.Location = new System.Drawing.Point(7, 15);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 19);
            this.label27.TabIndex = 219;
            this.label27.Text = "Số dòng";
            // 
            // txt_sodong
            // 
            this.txt_sodong.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sodong.ForeColor = System.Drawing.Color.Blue;
            this.txt_sodong.Location = new System.Drawing.Point(105, 9);
            this.txt_sodong.MaxLength = 30;
            this.txt_sodong.Name = "txt_sodong";
            this.txt_sodong.ReadOnly = true;
            this.txt_sodong.Size = new System.Drawing.Size(103, 25);
            this.txt_sodong.TabIndex = 32;
            this.txt_sodong.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Blue;
            this.label28.Location = new System.Drawing.Point(6, 112);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(97, 19);
            this.label28.TabIndex = 217;
            this.label28.Text = "Mã hàng hóa";
            // 
            // frm_nhapkho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(974, 713);
            this.Controls.Add(this.group);
            this.Controls.Add(this.dgv_Data);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Name = "frm_nhapkho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frm_nhapkho_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Data)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.group.ResumeLayout(false);
            this.group.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_Data;
        private System.Windows.Forms.LinkLabel txt_excelmau;
        private System.Windows.Forms.Button btn_Import;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.GroupBox groupBox1;
        internal System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox cmb_ncc_TK;
        internal System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmb_tenhh_TK;
        internal System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmb_mahh_TK;
        private System.Windows.Forms.ComboBox cmb_loaihh_TK;
        private System.Windows.Forms.Button btn_Clear;
        private System.Windows.Forms.Button btn_Excel;
        internal System.Windows.Forms.Label Label11;
        private System.Windows.Forms.Button btn_Search;
        private System.Windows.Forms.ComboBox cmb_kho_TK;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox group;
        internal System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox txt_sl_hoan;
        internal System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txt_sl_haohut;
        internal System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txt_sl_nhap;
        internal System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_solot;
        internal System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_sophieu_NK;
        private System.Windows.Forms.ComboBox cmb_mahh;
        private System.Windows.Forms.ComboBox cmb_tenhh;
        internal System.Windows.Forms.Label label19;
        internal System.Windows.Forms.MaskedTextBox msk_ngayPNK;
        internal System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txt_ghichu;
        internal System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cmb_ncc;
        internal System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cmb_loaihh;
        internal System.Windows.Forms.Label label24;
        internal System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cmb_kho;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_Delete;
        internal System.Windows.Forms.Label label26;
        internal System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txt_sodong;
        internal System.Windows.Forms.Label label28;
        internal System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txt_sl_invoice;
        internal System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txt_soinvoice;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.MaskedTextBox mtb_TuNgay_TK;
        internal System.Windows.Forms.MaskedTextBox mtb_DenNgay_TK;
        internal System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmb_solot_TK;
        internal System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmb_sophieu_TK;
        private System.Windows.Forms.TextBox txt_dvt;
        internal System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmb_nguoinhan;
    }
}

