﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//  using System;
//   using System.Data;
//   using Npgsql; 
 
//   class Sample
//   {
//     static void Main(string[] args)
//     {
//         // Connect to a PostgreSQL database
//         NpgsqlConnection conn = new NpgsqlConnection("Server=127.0.0.1;User Id=postgres; " + 
//             "Password=pwd;Database=postgres;");
//         conn.Open();
 
//         // Start a transaction as it is required to work with result sets (cursors) in PostgreSQL
//         NpgsqlTransaction tran = conn.BeginTransaction();
 
//         // Define a command to call show_cities() procedure
//         NpgsqlCommand command = new NpgsqlCommand("show_cities", conn);
//         command.CommandType = CommandType.StoredProcedure;
 
//         // Execute the procedure and obtain a result set
//         NpgsqlDataReader dr = command.ExecuteReader();
 
//         // Output rows 
//         while (dr.Read())
//            Console.Write("{0} \t {1} \n", dr[0], dr[1]);
 
//         tran.Commit();  
//         conn.Close();   
//       }
//     }

////-- Procedure that returns a single result set (cursor) 
////   CREATE OR REPLACE FUNCTION show_cities() RETURNS refcursor AS $$
////    DECLARE
////      ref refcursor;                                                     -- Declare a cursor variable
////    BEGIN
////      OPEN ref FOR SELECT city, state FROM cities;   -- Open a cursor
////      RETURN ref;                                                       -- Return the cursor to the caller
////    END;
////    $$ LANGUAGE plpgsql;

//using (var cmd = new NpgsqlCommand("SELECT my_func()", conn))
//{
//    cmd.Parameters.Add(new NpgsqlParameter("p_out", DbType.String) { Direction = ParameterDirection.Output });
//    cmd.ExecuteNonQuery();
//    Console.WriteLine(cmd.Parameters[0].Value);
//}

//create procedure trans_amt(
//   sender_id int,
//   receiver_id int, 
//   transaction_amt dec
//)
//language plpgsql    
//as 
//$$
//begin
    
//    update acc_holders 
//    set balance = balance - transaction_amt 
//    where id = sender_id;


//    update acc_holders
//    set balance = balance + transaction_amt 
//    where id = receiver_id;


//    commit;
//end;
//$$

//https://stackoverflow.com/questions/78546083/c-sharp-postgres-procedure-with-parameters
//https://medium.com/@karthicksrinivasan.s42/simplifying-postgresql-function-calls-in-c-with-pg2csharp-26fb1d3afd02