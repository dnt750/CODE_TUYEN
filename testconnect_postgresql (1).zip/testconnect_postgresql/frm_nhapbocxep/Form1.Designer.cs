﻿namespace frm_nhapbocxep
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.group = new System.Windows.Forms.GroupBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txt_ghichu = new System.Windows.Forms.TextBox();
            this.txt_sl_nhap = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_solot = new System.Windows.Forms.TextBox();
            this.cmb_mahh = new System.Windows.Forms.ComboBox();
            this.cmb_tenhh = new System.Windows.Forms.ComboBox();
            this.txt_excelmau = new System.Windows.Forms.LinkLabel();
            this.btn_Import = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.msk_ngayPNK = new System.Windows.Forms.MaskedTextBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.cmb_ncc = new System.Windows.Forms.ComboBox();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.btn_Delete = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.dgv_Data = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.btn_cong1 = new System.Windows.Forms.Button();
            this.btn_cong2 = new System.Windows.Forms.Button();
            this.btn_tru1 = new System.Windows.Forms.Button();
            this.btn_tru2 = new System.Windows.Forms.Button();
            this.group.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Data)).BeginInit();
            this.SuspendLayout();
            // 
            // group
            // 
            this.group.Controls.Add(this.label6);
            this.group.Controls.Add(this.textBox4);
            this.group.Controls.Add(this.label4);
            this.group.Controls.Add(this.textBox2);
            this.group.Controls.Add(this.label5);
            this.group.Controls.Add(this.textBox3);
            this.group.Controls.Add(this.label3);
            this.group.Controls.Add(this.textBox1);
            this.group.Controls.Add(this.label2);
            this.group.Controls.Add(this.comboBox2);
            this.group.Controls.Add(this.label1);
            this.group.Controls.Add(this.comboBox1);
            this.group.Controls.Add(this.label29);
            this.group.Controls.Add(this.label20);
            this.group.Controls.Add(this.txt_ghichu);
            this.group.Controls.Add(this.txt_sl_nhap);
            this.group.Controls.Add(this.label17);
            this.group.Controls.Add(this.txt_solot);
            this.group.Controls.Add(this.cmb_mahh);
            this.group.Controls.Add(this.cmb_tenhh);
            this.group.Controls.Add(this.txt_excelmau);
            this.group.Controls.Add(this.btn_Import);
            this.group.Controls.Add(this.label19);
            this.group.Controls.Add(this.msk_ngayPNK);
            this.group.Controls.Add(this.btn_Save);
            this.group.Controls.Add(this.cmb_ncc);
            this.group.Controls.Add(this.btn_Exit);
            this.group.Controls.Add(this.btn_Delete);
            this.group.Controls.Add(this.label26);
            this.group.Controls.Add(this.label27);
            this.group.Controls.Add(this.textBox6);
            this.group.Controls.Add(this.label28);
            this.group.Location = new System.Drawing.Point(3, 435);
            this.group.Name = "group";
            this.group.Size = new System.Drawing.Size(951, 207);
            this.group.TabIndex = 239;
            this.group.TabStop = false;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Blue;
            this.label29.Location = new System.Drawing.Point(360, 79);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(59, 19);
            this.label29.TabIndex = 243;
            this.label29.Text = "SL nhập";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Blue;
            this.label20.Location = new System.Drawing.Point(360, 106);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(57, 19);
            this.label20.TabIndex = 233;
            this.label20.Text = "SL kg 1";
            // 
            // txt_ghichu
            // 
            this.txt_ghichu.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ghichu.Location = new System.Drawing.Point(424, 100);
            this.txt_ghichu.MaxLength = 1000;
            this.txt_ghichu.Name = "txt_ghichu";
            this.txt_ghichu.Size = new System.Drawing.Size(84, 25);
            this.txt_ghichu.TabIndex = 14;
            // 
            // txt_sl_nhap
            // 
            this.txt_sl_nhap.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_sl_nhap.Location = new System.Drawing.Point(424, 72);
            this.txt_sl_nhap.MaxLength = 10;
            this.txt_sl_nhap.Name = "txt_sl_nhap";
            this.txt_sl_nhap.Size = new System.Drawing.Size(84, 25);
            this.txt_sl_nhap.TabIndex = 7;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Blue;
            this.label17.Location = new System.Drawing.Point(8, 169);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(45, 19);
            this.label17.TabIndex = 241;
            this.label17.Text = "Số lot";
            // 
            // txt_solot
            // 
            this.txt_solot.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_solot.Location = new System.Drawing.Point(104, 169);
            this.txt_solot.MaxLength = 50;
            this.txt_solot.Name = "txt_solot";
            this.txt_solot.Size = new System.Drawing.Size(92, 25);
            this.txt_solot.TabIndex = 10;
            // 
            // cmb_mahh
            // 
            this.cmb_mahh.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_mahh.DropDownHeight = 200;
            this.cmb_mahh.DropDownWidth = 100;
            this.cmb_mahh.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_mahh.FormattingEnabled = true;
            this.cmb_mahh.IntegralHeight = false;
            this.cmb_mahh.Location = new System.Drawing.Point(670, 166);
            this.cmb_mahh.Name = "cmb_mahh";
            this.cmb_mahh.Size = new System.Drawing.Size(100, 27);
            this.cmb_mahh.TabIndex = 3;
            // 
            // cmb_tenhh
            // 
            this.cmb_tenhh.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_tenhh.DropDownHeight = 300;
            this.cmb_tenhh.DropDownWidth = 200;
            this.cmb_tenhh.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_tenhh.FormattingEnabled = true;
            this.cmb_tenhh.IntegralHeight = false;
            this.cmb_tenhh.Location = new System.Drawing.Point(105, 135);
            this.cmb_tenhh.Name = "cmb_tenhh";
            this.cmb_tenhh.Size = new System.Drawing.Size(211, 27);
            this.cmb_tenhh.TabIndex = 2;
            // 
            // txt_excelmau
            // 
            this.txt_excelmau.AutoSize = true;
            this.txt_excelmau.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_excelmau.Location = new System.Drawing.Point(789, 44);
            this.txt_excelmau.Name = "txt_excelmau";
            this.txt_excelmau.Size = new System.Drawing.Size(58, 15);
            this.txt_excelmau.TabIndex = 223;
            this.txt_excelmau.TabStop = true;
            this.txt_excelmau.Text = "Excel Mẫu";
            this.txt_excelmau.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // btn_Import
            // 
            this.btn_Import.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Import.ForeColor = System.Drawing.Color.Blue;
            this.btn_Import.Location = new System.Drawing.Point(853, 37);
            this.btn_Import.Name = "btn_Import";
            this.btn_Import.Size = new System.Drawing.Size(75, 27);
            this.btn_Import.TabIndex = 17;
            this.btn_Import.Text = "Import";
            this.btn_Import.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Blue;
            this.label19.Location = new System.Drawing.Point(7, 47);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 20);
            this.label19.TabIndex = 235;
            this.label19.Text = "Ngày";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // msk_ngayPNK
            // 
            this.msk_ngayPNK.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msk_ngayPNK.Location = new System.Drawing.Point(104, 41);
            this.msk_ngayPNK.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.msk_ngayPNK.Mask = "0000/00/00";
            this.msk_ngayPNK.Name = "msk_ngayPNK";
            this.msk_ngayPNK.ReadOnly = true;
            this.msk_ngayPNK.Size = new System.Drawing.Size(103, 26);
            this.msk_ngayPNK.TabIndex = 1;
            this.msk_ngayPNK.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.msk_ngayPNK.ValidatingType = typeof(System.DateTime);
            // 
            // btn_Save
            // 
            this.btn_Save.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Save.ForeColor = System.Drawing.Color.Blue;
            this.btn_Save.Location = new System.Drawing.Point(853, 70);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(75, 27);
            this.btn_Save.TabIndex = 18;
            this.btn_Save.Text = "Lưu";
            this.btn_Save.UseVisualStyleBackColor = true;
            // 
            // cmb_ncc
            // 
            this.cmb_ncc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmb_ncc.DropDownHeight = 300;
            this.cmb_ncc.DropDownWidth = 180;
            this.cmb_ncc.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_ncc.FormattingEnabled = true;
            this.cmb_ncc.IntegralHeight = false;
            this.cmb_ncc.Location = new System.Drawing.Point(576, 32);
            this.cmb_ncc.Name = "cmb_ncc";
            this.cmb_ncc.Size = new System.Drawing.Size(150, 27);
            this.cmb_ncc.TabIndex = 12;
            // 
            // btn_Exit
            // 
            this.btn_Exit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Exit.ForeColor = System.Drawing.Color.Red;
            this.btn_Exit.Location = new System.Drawing.Point(853, 165);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(75, 27);
            this.btn_Exit.TabIndex = 20;
            this.btn_Exit.Text = "Thoát";
            this.btn_Exit.UseVisualStyleBackColor = true;
            // 
            // btn_Delete
            // 
            this.btn_Delete.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Delete.ForeColor = System.Drawing.Color.Red;
            this.btn_Delete.Location = new System.Drawing.Point(853, 103);
            this.btn_Delete.Name = "btn_Delete";
            this.btn_Delete.Size = new System.Drawing.Size(75, 27);
            this.btn_Delete.TabIndex = 19;
            this.btn_Delete.Text = "Xóa";
            this.btn_Delete.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Blue;
            this.label26.Location = new System.Drawing.Point(8, 138);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(90, 19);
            this.label26.TabIndex = 221;
            this.label26.Text = "Tên hàng hóa";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Blue;
            this.label27.Location = new System.Drawing.Point(7, 15);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 19);
            this.label27.TabIndex = 219;
            this.label27.Text = "Số dòng";
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.ForeColor = System.Drawing.Color.Blue;
            this.textBox6.Location = new System.Drawing.Point(105, 9);
            this.textBox6.MaxLength = 30;
            this.textBox6.Name = "textBox6";
            this.textBox6.ReadOnly = true;
            this.textBox6.Size = new System.Drawing.Size(103, 25);
            this.textBox6.TabIndex = 32;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dgv_Data
            // 
            this.dgv_Data.AllowUserToAddRows = false;
            this.dgv_Data.AllowUserToDeleteRows = false;
            this.dgv_Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Data.Location = new System.Drawing.Point(3, 104);
            this.dgv_Data.Name = "dgv_Data";
            this.dgv_Data.RowHeadersVisible = false;
            this.dgv_Data.RowTemplate.Height = 21;
            this.dgv_Data.Size = new System.Drawing.Size(246, 325);
            this.dgv_Data.TabIndex = 240;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(7, 106);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 19);
            this.label1.TabIndex = 245;
            this.label1.Text = "Mã bốc xếp";
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox1.DropDownHeight = 300;
            this.comboBox1.DropDownWidth = 180;
            this.comboBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.IntegralHeight = false;
            this.comboBox1.Location = new System.Drawing.Point(105, 103);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(150, 27);
            this.comboBox1.TabIndex = 244;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(8, 74);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 19);
            this.label2.TabIndex = 247;
            this.label2.Text = "Số phiếu";
            // 
            // comboBox2
            // 
            this.comboBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboBox2.DropDownHeight = 300;
            this.comboBox2.DropDownWidth = 180;
            this.comboBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.IntegralHeight = false;
            this.comboBox2.Location = new System.Drawing.Point(104, 71);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(150, 27);
            this.comboBox2.TabIndex = 246;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Blue;
            this.label28.Location = new System.Drawing.Point(572, 168);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(88, 19);
            this.label28.TabIndex = 217;
            this.label28.Text = "Mã hàng hóa";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(641, 100);
            this.textBox1.MaxLength = 1000;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(87, 25);
            this.textBox1.TabIndex = 248;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(531, 106);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 19);
            this.label3.TabIndex = 249;
            this.label3.Text = "Số người bốc 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Purple;
            this.label4.Location = new System.Drawing.Point(531, 135);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 19);
            this.label4.TabIndex = 253;
            this.label4.Text = "Số người bốc 2";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(641, 129);
            this.textBox2.MaxLength = 1000;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(87, 25);
            this.textBox2.TabIndex = 252;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Purple;
            this.label5.Location = new System.Drawing.Point(360, 135);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 19);
            this.label5.TabIndex = 251;
            this.label5.Text = "SL kg 2";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(424, 129);
            this.textBox3.MaxLength = 1000;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(84, 25);
            this.textBox3.TabIndex = 250;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Blue;
            this.label6.Location = new System.Drawing.Point(531, 74);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(99, 19);
            this.label6.TabIndex = 255;
            this.label6.Text = "Tổng SL người";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(641, 68);
            this.textBox4.MaxLength = 10;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(84, 25);
            this.textBox4.TabIndex = 254;
            // 
            // btn_cong1
            // 
            this.btn_cong1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cong1.ForeColor = System.Drawing.Color.Blue;
            this.btn_cong1.Location = new System.Drawing.Point(255, 104);
            this.btn_cong1.Name = "btn_cong1";
            this.btn_cong1.Size = new System.Drawing.Size(34, 32);
            this.btn_cong1.TabIndex = 242;
            this.btn_cong1.Text = "+";
            this.btn_cong1.UseVisualStyleBackColor = true;
            // 
            // btn_cong2
            // 
            this.btn_cong2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cong2.ForeColor = System.Drawing.Color.Purple;
            this.btn_cong2.Location = new System.Drawing.Point(255, 140);
            this.btn_cong2.Name = "btn_cong2";
            this.btn_cong2.Size = new System.Drawing.Size(34, 32);
            this.btn_cong2.TabIndex = 243;
            this.btn_cong2.Text = "+";
            this.btn_cong2.UseVisualStyleBackColor = true;
            // 
            // btn_tru1
            // 
            this.btn_tru1.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_tru1.ForeColor = System.Drawing.Color.Blue;
            this.btn_tru1.Location = new System.Drawing.Point(293, 104);
            this.btn_tru1.Name = "btn_tru1";
            this.btn_tru1.Size = new System.Drawing.Size(34, 32);
            this.btn_tru1.TabIndex = 244;
            this.btn_tru1.Text = "-";
            this.btn_tru1.UseVisualStyleBackColor = true;
            // 
            // btn_tru2
            // 
            this.btn_tru2.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_tru2.ForeColor = System.Drawing.Color.Purple;
            this.btn_tru2.Location = new System.Drawing.Point(293, 139);
            this.btn_tru2.Name = "btn_tru2";
            this.btn_tru2.Size = new System.Drawing.Size(34, 32);
            this.btn_tru2.TabIndex = 254;
            this.btn_tru2.Text = "-";
            this.btn_tru2.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(964, 648);
            this.Controls.Add(this.btn_tru2);
            this.Controls.Add(this.btn_tru1);
            this.Controls.Add(this.btn_cong2);
            this.Controls.Add(this.btn_cong1);
            this.Controls.Add(this.group);
            this.Controls.Add(this.dgv_Data);
            this.Name = "Form1";
            this.Text = "Form1";
            this.group.ResumeLayout(false);
            this.group.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Data)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox group;
        internal System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox4;
        internal System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        internal System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox3;
        internal System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        internal System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox2;
        internal System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        internal System.Windows.Forms.Label label29;
        internal System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txt_ghichu;
        private System.Windows.Forms.TextBox txt_sl_nhap;
        internal System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_solot;
        private System.Windows.Forms.ComboBox cmb_mahh;
        private System.Windows.Forms.ComboBox cmb_tenhh;
        private System.Windows.Forms.LinkLabel txt_excelmau;
        private System.Windows.Forms.Button btn_Import;
        internal System.Windows.Forms.Label label19;
        internal System.Windows.Forms.MaskedTextBox msk_ngayPNK;
        private System.Windows.Forms.Button btn_Save;
        private System.Windows.Forms.ComboBox cmb_ncc;
        private System.Windows.Forms.Button btn_Exit;
        private System.Windows.Forms.Button btn_Delete;
        internal System.Windows.Forms.Label label26;
        internal System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox6;
        internal System.Windows.Forms.Label label28;
        private System.Windows.Forms.DataGridView dgv_Data;
        private System.Windows.Forms.Button btn_cong1;
        private System.Windows.Forms.Button btn_cong2;
        private System.Windows.Forms.Button btn_tru1;
        private System.Windows.Forms.Button btn_tru2;
    }
}

